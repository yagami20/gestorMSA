@extends ('layouts.admin')
@section ('content')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="{{asset('GestorMSA/Almacen')}}">Almacen</a>/
                <a href="{{asset('GestorMSA/Graficos3D')}}">Graficos 3D</a>/Editar
            </h5>
			<h3>Editar datos grafico 3D: {{$graf3d->tipoSW}}</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

	
			


<form method="POST" action="/GestorMSA/Graficos3D/{{$graf3d->id}}" enctype="multipart/form-data">
    @method('PUT')  
    @csrf
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    
                       

                        <div class="form-group row">
                            <label for="tipoSW" class="col-md-4 col-form-label text-md-right">{{ __('Tipo de Software de Creación') }}</label>

                            <div class="col-md-6">
                                <input id="tipoSW" type="text" placeholder="Nombre Apellido" class="form-control{{ $errors->has('tipoSW') ? ' is-invalid' : '' }}" name="tipoSW" value="{{$graf3d->tipoSW}}" required autofocus>

                                @if ($errors->has('tipoSW'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('tipoSW') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="Autorgraf3D" class="col-md-4 col-form-label text-md-right">{{ __('Autor/es') }}</label>

                            <div class="col-md-6">
                                <input id="Autorgraf3D" type="text" placeholder="Nombre Apellido" class="form-control{{ $errors->has('Autorgraf3D') ? ' is-invalid' : '' }}" name="Autorgraf3D" value="{{$graf3d->Autorgraf3D}}" required autofocus>

                                @if ($errors->has('Autorgraf3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('Autorgraf3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="Desgraf3D" class="col-md-4 col-form-label text-md-right">{{ __('Descripción del S.W.') }}</label>

                            <div class="col-md-6">
                                <input id="Desgraf3D" type="text" placeholder="Descripción" class="form-control{{ $errors->has('Desgraf3D') ? ' is-invalid' : '' }}" name="Desgraf3D" value="{{$graf3d->Desgraf3D}}" required autofocus>

                                @if ($errors->has('Desgraf3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('Desgraf3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaCreacion" class="col-md-4 col-form-label text-md-right">{{ __('Fecha Modificación') }}</label>

                            <div class="col-md-6">
                                <input id="fechaCreacion" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('fechaCreacion') ? ' is-invalid' : '' }}" name="fechaCreacion" value="{{$graf3d->fechaCreacion}}" required autofocus>

                                @if ($errors->has('fechaCreacion'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fechaCreacion') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="obj3D" class="col-md-4 col-form-label text-md-right">{{ __('Agregar Objeto:') }}</label>

                            <div class="col-md-6">
                                <input id="obj3D" type="file" name="obj3D" value="{{ old('obj3D') }}" required autofocus>

                                @if ($errors->has('obj3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('obj3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="Docgraf3D" class="col-md-4 col-form-label text-md-right">{{ __('Agregar Documento Objeto') }}</label>

                            <div class="col-md-6">
                                <input id="Docgraf3D" type="file" name="Docgraf3D" value="{{ old('Docgraf3D') }}" required autofocus>

                                @if ($errors->has('Docgraf3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('Docgraf3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->                        
                        <div class="form-group row">
                            <label for="observacion" class="col-md-4 col-form-label text-md-right">{{ __('Observación de archivo') }}</label>

                            <div class="col-md-6">
                                <input id="observacion" type="text" placeholder="Nombre Apellido" class="form-control{{ $errors->has('observacion') ? ' is-invalid' : '' }}" name="observacion" value="{{$graf3d->observacion}}" required autofocus>

                                @if ($errors->has('observacion'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('observacion') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="tipoObj" class="col-md-4 col-form-label text-md-right">{{ __('Tipo de objeto') }}</label>

                            <div class="col-md-6">
                                <!-- <div class="col-sm-4"> -->
                                              <select name="tipoObj" class="form-control">
                                                <option value="1">Objeto Json</option>
                                                <option value="2">Objeto Obj</option>
                                                <option value="4">Objeto Stl</option>
                                                <option value="5">Objeto Dae</option>
                                                <option value="6">Objeto Ply</option>
                                                <option value="7">Objeto Gltf</option>
                                            </select>
                                            <!-- </div> -->

                                @if ($errors->has('tipoObj'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('tipoObj') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        

                        <!--fin ndatos  -->
                        <!--new datos  -->
                        <!--estado  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    {{ __('Enviar') }}
                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
@endsection