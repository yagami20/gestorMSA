@extends ('layouts.admin')
@section ('content')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="{{asset('GestorMSA/Almacen')}}">Almacen</a>/
                <a href="{{asset('GestorMSA/Aplicaciones')}}">Aplicaciones</a>/Crear
            </h5>
			<h3>Nueva Aplicacion:</h3><br>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>
			{!!Form::open(array('url'=>'GestorMSA/Aplicaciones','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			{{Form::token()}} 

		<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="{{ route('register') }}" aria-label="{{ __('Register') }}"> -->
                        @csrf

                        <div class="form-group row">
                            <label for="tipoSW" class="col-md-4 col-form-label text-md-right">{{ __('Nombre del S.W.') }}</label>

                            <div class="col-md-6">
                                <input id="tipoSW" type="text" placeholder="Simulador #..." class="form-control{{ $errors->has('tipoSW') ? ' is-invalid' : '' }}" name="tipoSW" value="{{ old('tipoSW') }}" required autofocus>

                                @if ($errors->has('tipoSW'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('tipoSW') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right">{{ __('Descripción:') }}</label>

                            <div class="col-md-6">
                                <input id="DesApp" type="text" placeholder="Descripción #..." class="form-control{{ $errors->has('DesApp') ? ' is-invalid' : '' }}" name="DesApp" value="{{ old('DesApp') }}" required autofocus>

                                @if ($errors->has('DesApp'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('DesApp') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right">{{ __('Autor/es:') }}</label>

                            <div class="col-md-6">
                                <input id="AutorApp" type="text" placeholder="Persona1, Persona2 #..." class="form-control{{ $errors->has('AutorApp') ? ' is-invalid' : '' }}" name="AutorApp" value="{{ old('AutorApp') }}" required autofocus>

                                @if ($errors->has('AutorApp'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('AutorApp') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaReproduc" class="col-md-4 col-form-label text-md-right">{{ __('Fecha creación S.W.') }}</label>

                            <div class="col-md-6">
                                <input id="fechaReproduc" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('fechaReproduc') ? ' is-invalid' : '' }}" name="fechaReproduc" value="{{ old('fechaReproduc') }}" required autofocus>

                                @if ($errors->has('fechaReproduc'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fechaReproduc') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right">{{ __('Cargar Foto:') }}</label>

                            <div class="col-md-6">
                                <input id="fotoApp" type="file" name="fotoApp" value="{{ old('fotoApp') }}" required autofocus>

                                @if ($errors->has('fotoApp'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fotoApp') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        
                        <div class="form-group row">
                            <label for="examinar" class="col-md-4 col-form-label text-md-right">{{ __('Importar:') }}</label>

                            <div class="col-md-6">
                                <input id="examinar" type="file" name="examinar" value="{{ old('examinar') }}" required autofocus>

                                @if ($errors->has('examinar'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('examinar') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        
                        

                        <!--fin ndatos  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    {{ __('Ingresar') }}
                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
			
			


			{!!Form::close()!!}

		
@endsection