@extends('nav')

@section('content')
<div class="row section-head">
         <div class="col full" align="justify">
            <p class="desc" align="justify" >             
              <h2> MÓDULO: Europa en Auto</h2> 
                  <hr></br>             
                  <p>
                   <b>
                     Autos y camiones se desplazaran con la técnica "car sytem" los mismos que recorrerán varias vías representativas de Europa. El punto de partida será Madrid-España, recorrerá Francia y llegara a la ciudad de Hamburgo en Alemania.
                   </b>
                    <center>
                  <img style="width: 320px; height: 180px;" src="images/proyecto tren/europa en auto/ea1.jpg">
                </center>
                   <h5 style="color: darkcyan">MÓDULO LUCES</h5>
                     El sistema de la maqueta interactiva, podrá controlar las luces de todos los módulos, para simular la noche y decoración de las ciudades. <br>
            </p>              
                <center>
                  <img style="width: 320px; height: 180px;" src="images/proyecto tren/europa en auto/ea2.jpg">
                </center>
             <p>
               <h5 style="color: darkcyan">MÓDULO PAISAJES</h5>
               En el sistema podrá intercambiar de manera controlada diferentes escenarios de las vías. Por ejemplo, al activar el auto o bus se podrá apreciar paisajes de los Alpes combinado con paisajes de la "campiña francesa".
             </p>   
               <center>
                  <img style="width: 320px; height: 180px;" src="images/proyecto tren/europa en auto/ea3.jpg">
                </center>
              <p>
               <h5 style="color: darkcyan">CAR SYSTEM</h5>
               Este sistema permite incluir en un modelo de transporte, pequeños motores y servos los mismos que son controlados mediante un seguimiento de linea metálica, la misma que viene incrustada en la vía.
             </p>                  
                <center>
                  <img style="width: 320px; height: 180px;" src="images/proyecto tren/europa en auto/ea4.jpg">
                </center><br>
          <button class="regresar">
            <a style="color: white" href="{{asset('/#proyectos')}}">Volver a proyectos</a>
          </button>
  </div>
</div>
@endsection
