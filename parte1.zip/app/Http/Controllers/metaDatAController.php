<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;

use App\aplicacion;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use App\Http\Requests\AplicacionFormRequest;
use phpCAS;

use DB; 
//

class metaDatAController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //$request->user()->authorizeRoles(['admin']);
        //dd($request->get('buscarAdm'));
        $band='aqui';
        
        $codApp='FIEAPPG';
        $codarchP='FIEARCHPL';
        $codg3D='FIEOBJ3D';//
        $codKit='FIEKIT';//
        $codNot='FIENOTIFMSA';//
        $codPat='FIEPAPP';//
        $codTarj='FIETAPP';//

        if ($request)
        {
            $query=trim($request->get('buscarAdm')); //determinr texto de busqueda
            if(strncasecmp($query, $codApp, 7) === 0){
                $porciones = explode("FIEAPPG", $query);
                //dd($porciones[1]);
                $band='1';
                $apg=DB::table('aplicacions as tbU')
                ->select('tbU.id','tbU.tipoSW','tbU.fechaReproduc','tbU.examinar', 'tbU.fotoApp','tbU.DesApp','tbU.AutorApp')
                    ->where('tbU.id','=',$porciones[1])
                    ->orderBy('tbU.id','desc')
                    ->paginate(7);
                    //dd($apg);
                return view('GestorMSA.BusquedaA.index',["apg"=>$apg,"band"=>$band,"buscarAdm"=>$query]);
            }
            if(strncasecmp($query, $codarchP, 9) === 0){
                $porciones = explode("FIEARCHPL", $query);
                //dd($porciones[1]);
                $band='2';
                //dd($band);
                $apg=DB::table('arch_planos as tbU')
                ->select('tbU.id','tbU.TipoArchivo','tbU.DocArchP','tbU.ImgArchP','tbU.AutorArchP','tbU.fechaGener','tbU.objPlano', 'tbU.observacion','tbU.tipoObjP','tbU.DesArchP')
                ->where('tbU.id','=',$porciones[1])
                ->orderBy('tbU.id','desc')
                ->paginate(7);
                //dd($apg);
                return view('GestorMSA.BusquedaA.index',["apg"=>$apg,"band"=>$band,"buscarAdm"=>$query]);
            }
            if(strncasecmp($query, $codg3D, 8) === 0){
                $porciones = explode("FIEOBJ3D", $query);
                //dd($porciones[1]);
                $band='3';
                //dd($band);
                $apg=DB::table('grafico3ds as tbU')
                ->select('tbU.id','tbU.fechaCreacion','tbU.Docgraf3D','tbU.obj3D','tbU.Autorgraf3D','tbU.observacion', 'tbU.tipoSW','tbU.tipoObj','tbU.Desgraf3D')
                ->where('tbU.id','=',$porciones[1])
                ->orderBy('tbU.id','desc')
                ->paginate(7);
                //dd($apg);
                return view('GestorMSA.BusquedaA.index',["apg"=>$apg,"band"=>$band,"buscarAdm"=>$query]);
            }
            if(strncasecmp($query, $codKit, 6) === 0){
                $porciones = explode("FIEKIT", $query);
                //dd($porciones[1]);
                $band='4';
                //dd($band);
                $apg=DB::table('kit_steams as tbSI')
                ->join('contenido_kits as tbI', 'tbSI.idContenido','=','tbI.id')
                ->join('caja_contenidos as tbSC','tbI.id','=','tbSC.idContenido')
                ->join('cajas as tbC','tbSC.idCaja','=','tbC.id')
                ->select('tbSI.id','tbSC.id as idCajCont','tbSI.aplicabilidad as App','tbSI.AutorKit as Autor','tbSI.portadakit as Portada','tbSI.fechaKit as fecha',
                    'tbSI.planos as plano', 
                    'tbSI.email as correo','tbI.piezaArmar as pieza','tbI.instrucciones as instruc',
                    'tbI.tutoDigital as tutorial','tbI.enlaceWeb as enlace',
                    'tbI.tipoMateria as material','tbC.nombreC as nombreCaja',
                    'tbC.informacion as info','tbC.codQR as QR')
                ->where('tbSI.id','=',$porciones[1])
                ->orderBy('tbSI.id','desc')
                ->paginate(7);
                //dd($apg);
                return view('GestorMSA.BusquedaA.index',["apg"=>$apg,"band"=>$band,"buscarAdm"=>$query]);
            }
            if(strncasecmp($query, $codNot, 11) === 0){
                $porciones = explode("FIENOTIFMSA", $query);
                //dd($porciones[1]);
                $band='5';
                //dd($band);
                $apg=DB::table('notificacion_ps as tbU')
                ->select('tbU.id','tbU.titulo','tbU.descripcion','tbU.foto','tbU.docNotif','tbU.fechaNotf')
                
                ->where('tbU.id','=',$porciones[1])

                
                ->orderBy('tbU.id','asc')

                ->paginate(7);
                //dd($apg);
                return view('GestorMSA.BusquedaA.index',["apg"=>$apg,"band"=>$band,"buscarAdm"=>$query]);
            }
            if(strncasecmp($query, $codPat, 7) === 0){
                $porciones = explode("FIEPAPP", $query);
                //dd($porciones[1]);
                $band='6';
                //dd($band);
                $apg=DB::table('patentes_pr_ps as tbU')
                ->select('tbU.id','tbU.TituloPatent','tbU.ClasePatent','tbU.CertifPatent','tbU.SolicPatent','tbU.ComprovPatent','tbU.AppPatent','tbU.logoApp','tbU.AutorsPatent','tbU.fechaPatent','tbU.DocPatent')
                
                ->where('tbU.id','=',$porciones[1])

                
                ->orderBy('tbU.id','asc')

                ->paginate(7);
                //dd($apg);
                return view('GestorMSA.BusquedaA.index',["apg"=>$apg,"band"=>$band,"buscarAdm"=>$query]);
            }
            if(strncasecmp($query, $codTarj, 7) === 0){
                $porciones = explode("FIETAPP", $query);
                //dd($porciones[1]);
                $band='7';
                //dd($band);
                $apg=DB::table('tarjetas_p_ps as tbU')
                ->select('tbU.id','tbU.DesTarjet','tbU.AutorTarj','tbU.QRTarjet','tbU.NombTarj','tbU.fotoApp','tbU.examinar','tbU.fechaCreacT')
                
                ->where('tbU.id','=',$porciones[1])

                
                ->orderBy('tbU.id','desc')

                ->paginate(7);
                //dd($apg);
                return view('GestorMSA.BusquedaA.index',["apg"=>$apg,"band"=>$band,"buscarAdm"=>$query]);
            }
            /* */
            $band='8';
            $apg=DB::table('productos as tbProd')
            ->join('users as tbU', 'tbU.id','=','tbProd.idUser')
            ->join('aplicacions as tbApp', 'tbApp.id','=','tbProd.idApp')
            ->join('arch_planos as tbArch', 'tbArch.id','=','tbProd.idarchPlano')
            ->join('patentes_pr_ps as tbPapp', 'tbPapp.id','=','tbProd.idPatent')
            ->join('tarjetas_p_ps as tbTarjpp', 'tbTarjpp.id','=','tbProd.idTarj')
            ->join('grafico3ds as tbG3d', 'tbG3d.id','=','tbProd.idGraf3D')
            ->join('kit_steams as tbKit', 'tbKit.id','=','tbProd.idKit')
            /* */
            ->join('contenido_kits as tbCK', 'tbKit.idContenido','=','tbCK.id')
            ->join('cajas as tbC','tbCK.idCaja','=','tbC.id')
            /*select */
            ->select('tbProd.id','tbProd.idGraf3D','tbProd.idarchPlano','tbProd.idPatent','tbProd.idTarj','tbProd.idKit','tbProd.idApp','tbProd.nombreP','tbU.name', 
                'tbApp.tipoSW as TitApp','tbApp.fechaReproduc','tbApp.DesApp','tbApp.AutorApp',
                'tbArch.TipoArchivo','tbArch.DesArchP','tbArch.AutorArchP','tbArch.fechaGener','tbArch.observacion',
                'tbPapp.TituloPatent','tbPapp.AutorsPatent','tbPapp.fechaPatent','tbPapp.ClasePatent',
                'tbTarjpp.NombTarj','tbTarjpp.DesTarjet','tbTarjpp.AutorTarj','tbTarjpp.fechaCreacT',
                'tbG3d.tipoSW','tbG3d.observacion','tbG3d.Autorgraf3D','tbG3d.Desgraf3D','tbG3d.fechaCreacion',
                'tbKit.AutorKit','tbKit.email','tbKit.fechaKit','tbCK.enlaceWeb','tbCK.tipoMateria','tbC.nombreC')
            /*condiciones */
            ->where('tbProd.nombreP','LIKE','%'.$query.'%')
            ->orWhere('tbU.name','LIKE','%'.$query.'%')
            ->orWhere('tbApp.tipoSW','LIKE','%'.$query.'%')
            ->orWhere('tbApp.DesApp','LIKE','%'.$query.'%')
            ->orWhere('tbApp.AutorApp','LIKE','%'.$query.'%')
            ->orWhere('tbArch.TipoArchivo','LIKE','%'.$query.'%')
            ->orWhere('tbArch.DesArchP','LIKE','%'.$query.'%')
            ->orWhere('tbArch.AutorArchP','LIKE','%'.$query.'%')
            ->orWhere('tbArch.observacion','LIKE','%'.$query.'%')
            ->orWhere('tbPapp.TituloPatent','LIKE','%'.$query.'%')
            ->orWhere('tbPapp.AutorsPatent','LIKE','%'.$query.'%')
            ->orWhere('tbPapp.ClasePatent','LIKE','%'.$query.'%')
            ->orWhere('tbTarjpp.NombTarj','LIKE','%'.$query.'%')
            ->orWhere('tbTarjpp.DesTarjet','LIKE','%'.$query.'%')
            ->orWhere('tbTarjpp.AutorTarj','LIKE','%'.$query.'%')
            ->orWhere('tbG3d.tipoSW','LIKE','%'.$query.'%')
            ->orWhere('tbG3d.observacion','LIKE','%'.$query.'%')
            ->orWhere('tbG3d.Autorgraf3D','LIKE','%'.$query.'%')
            ->orWhere('tbG3d.Desgraf3D','LIKE','%'.$query.'%')
            ->orWhere('tbKit.AutorKit','LIKE','%'.$query.'%')
            ->orWhere('tbKit.email','LIKE','%'.$query.'%')
            ->orWhere('tbCK.enlaceWeb','LIKE','%'.$query.'%')
            ->orWhere('tbCK.tipoMateria','LIKE','%'.$query.'%')
            ->orWhere('tbC.nombreC','LIKE','%'.$query.'%')
            ->orWhere('tbPapp.fechaPatent','LIKE','%'.$query.'%')
            ->orwhere('tbApp.fechaReproduc','LIKE','%'.$query.'%')
            ->orwhere('tbArch.fechaGener','LIKE','%'.$query.'%')
            ->orwhere('tbTarjpp.fechaCreacT','LIKE','%'.$query.'%')
            ->orwhere('tbG3d.fechaCreacion','LIKE','%'.$query.'%')
            ->orwhere('tbKit.fechaKit','LIKE','%'.$query.'%')
            ->orderBy('tbProd.id','desc')
            /*paginar */
            ->paginate(7);
            //dd($query);
            return view('GestorMSA.BusquedaA.index',["apg"=>$apg,"band"=>$band,"buscarAdm"=>$query]);

        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
