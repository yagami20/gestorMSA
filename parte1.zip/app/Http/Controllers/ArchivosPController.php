<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;

use App\archPlano;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use App\Http\Requests\archPFormRequest;
use phpCAS;

use DB;  
//

class ArchivosPController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $archP=DB::table('arch_planos as tbU')
            ->select('tbU.id','tbU.TipoArchivo','tbU.DocArchP','tbU.ImgArchP','tbU.AutorArchP','tbU.fechaGener','tbU.objPlano', 'tbU.observacion','tbU.tipoObjP','tbU.DesArchP')
            ->where('tbU.TipoArchivo','LIKE','%'.$query.'%')
            ->orwhere('tbU.fechaGener','LIKE','%'.$query.'%')
            ->orderBy('tbU.id','desc')
            ->paginate(7);
            return view('GestorMSA.archPlanos.index',["archP"=>$archP,"searchText"=>$query]);

        }
    }
    public function create(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        return view ("GestorMSA.archPlanos.create");
    }

    
public function store (archPFormRequest $request)
    {
        $archP=new archPlano;

        $archP->TipoArchivo=$request->get('TipoArchivo');

        $archP->DesArchP=$request->get('DesArchP');

        $archP->AutorArchP=$request->get('AutorArchP');

        $archP->fechaGener=$request->get('fechaGener');

        if (Input::hasFile('objPlano')){
         $file1=Input::file('objPlano');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/documentos/archPlanos/',$nameF1);
         $archP->objPlano=$nameF1;
        }

        if (Input::hasFile('DocArchP')){
         $file2=Input::file('DocArchP');
         $namef2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/archPlanos/document/',$namef2);
         $archP->DocArchP=$namef2;
        }

        if (Input::hasFile('ImgArchP')){
         $file3=Input::file('ImgArchP');
         $nameF3=time().$file3->getClientOriginalName();
         $file3->move(public_path().'/imagenes/archPlanos/',$nameF3);
         $archP->ImgArchP=$nameF3;
        }

        $archP->observacion=$request->get('observacion');

        $archP->tipoObjP=$request->get('tipoObjP');
        
        $archP->save();
        return Redirect::to('GestorMSA/archPlanos');
    }


    
public function show ($id)
    {
        return view("GestorMSA.archPlanos.show"); 
    }

    
public function edit(Request $request,$id)
    {
        $request->user()->authorizeRoles(['admin']);
        $archP=archPlano::findOrFail($id);
        return view("GestorMSA.archPlanos.edit",["archP"=>$archP]);
    }

    
public function update(archPFormRequest $request, $id)
    {
        $archP=archPlano::findOrFail($id);

        $archP->TipoArchivo=$request->get('TipoArchivo');

        $archP->DesArchP=$request->get('DesArchP');

        $archP->AutorArchP=$request->get('AutorArchP');

        $archP->fechaGener=$request->get('fechaGener');

        if (Input::hasFile('objPlano')){
         $file1=Input::file('objPlano');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/documentos/archPlanos/',$nameF1);
         $archP->objPlano=$nameF1;
        }

        if (Input::hasFile('DocArchP')){
         $file2=Input::file('DocArchP');
         $namef2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/archPlanos/document/',$namef2);
         $archP->DocArchP=$namef2;
        }

        if (Input::hasFile('ImgArchP')){
         $file3=Input::file('ImgArchP');
         $nameF3=time().$file3->getClientOriginalName();
         $file3->move(public_path().'/imagenes/archPlanos/',$nameF3);
         $archP->ImgArchP=$nameF3;
        }

        $archP->observacion=$request->get('observacion');

        $archP->tipoObjP=$request->get('tipoObjP');

        $archP->save();
        // dd($apg);
        return Redirect::to('GestorMSA/archPlanos');
    }

    

    public function destroy($id)
    {
        $archP=archPlano::findOrFail($id);
        $archP->delete();
        return Redirect::to('GestorMSA/archPlanos');
    }

    public function download($objPlano)
    {
        $pathtoFile = public_path().'/documentos/archPlanos/'.$objPlano;
            return response()->download($pathtoFile);
    }
}
