<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-foto-{{$usd->id}}">
{{Form::Open(array('action'=>array('archPControllerU@download',$usd->id),'method'=>'delete'))}}
<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">X</span>
			
		</button>
		<h4 class="modal-title">Ver Archivo</h4>
	</div>
	<div class="modal-body">
		
		
				<!--  -->
				<div class="box-body box-profile">
                      <p class="text-muted text-center">Archivo Plano</p>
                      <p class="text-muted text-center"><img src="{{asset('/imagenes/archPlanos/'.$usd->ImgArchP)}}" style="width: 350px; height: 280px" class="img-thumbnail"></p> 
                      <p class="text-muted text-center">Codigo: FIEAPPG{{$usd->id}}</p>
                      <p class="text-muted text-center">Nombre: {{$usd->TipoArchivo}}</p>
                      <p class="text-muted text-center">Autor/es: {{$usd->AutorArchP}}</p>
                      <p class="text-muted text-center">Fecha Generación: {{$usd->fechaGener}}</p>
                      <p class="text-muted text-center">Descripción: {{$usd->DesArchP}}</p>
                      <p class="text-muted text-center">Observación: {{$usd->observacion}}</p>
                      <a href="{{URL::action('archPControllerU@download',$usd->objPlano)}}"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Descargar</button></a>
                  </div>
				<!--  -->
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
		
	</div>

	</div>
</div>
{{Form::Close()}}	

</div>