<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-video-<?php echo e($usd->id); ?>">
<?php echo e(Form::Open(array('action'=>array('kitSTEAMaController@Download',$usd->id),'method'=>'delete'))); ?>

<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">X</span>
			
		</button>
		<h4 class="modal-title">Ver Archivo</h4>
	</div>
	<div class="modal-body">
		
		
				<!--  -->
				<div class="box-body box-profile">
                    <video width="100%" height="50%" controls>
       					<source src="/documentos/kitSTEAM/tutKit/extract/<?=  $usd->tutorial;   ?>" type="video/mp4">
       					Your browser does not support the video tag.
   					</video>

                  </div>
                  <a href="<?php echo e(URL::action('kitSTEAMaController@downloadVideo',$usd->tutorial)); ?>"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Video</button></a>
				<!--  -->
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
		
	</div>

	</div>
</div>
<?php echo e(Form::Close()); ?>	

</div>