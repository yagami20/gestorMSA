<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProyectosController extends Controller
{
    //
    public function __construct()
    {
        // $this->middleware('auth');
    }
    public function aeroIndex()
    {
    	return view('aeromodelismo');
    }
    public function adminIndex()
    {
        return view('layouts.admin');
    }
    
    public function trenDulzuraIndex()
    {
    	return view('trendulzura');
    }
    
    public function aeropuertoIndex()
    {
    	return view('aeropuerto');
    }
    
    public function buqueGuayasIndex()
    {
    	return view('buque');
    }
    
    public function europaAutoIndex()
    {
    	return view('europaAuto');
    }

	public function juguetesEducativosIndex()
    {
    	return view('juegueteseducativos');
    }
    
    public function trenInteractivoIndex()
    {
    	return view('treninteractivo');
    }

    public function fieEdifIndex()
    {
        return view('fie3d');
    }

    public function volverIndex()
    {
    	return view('/#proyectos');
    }

    public function perfilIndex()
    {
        return view('layouts.perfil');
    }
}
