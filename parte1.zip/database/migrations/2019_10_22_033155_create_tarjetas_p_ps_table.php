<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTarjetasPPsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tarjetas_p_ps', function (Blueprint $table) {
            $table->increments('id');
            $table->string('DesTarjet');
            $table->string('AutorTarj');
            $table->string('QRTarjet');
            $table->string('NombTarj');
            $table->date('fechaCreacT');
            $table->string('fotoApp');
            $table->string('examinar');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tarjetas_p_ps');
    }
}
