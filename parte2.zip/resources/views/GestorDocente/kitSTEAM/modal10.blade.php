<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-DocObserv-{{$usd->id}}">
{{Form::Open(array('action'=>array('observacionDController@download',$usd->id),'method'=>'delete'))}}
<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">X</span>
			
		</button>
		<h4 class="modal-title">Ver Archivo</h4>
	</div>
	<div class="modal-body">
		
		
				<!--  -->
				<div class="box-body box-profile">
                      <p class="text-muted text-center">{{$usd->nombreA}}</p>
                      <p><iframe src="/documentos/docObserv/<?=  $usd->DocObserv;   ?>" height="480px" width="450px" > archivo</iframe></p>  
                  </div>
				<!--  -->
				@if($usd->idUser!= Auth::user()->id)
                    <a href="{{URL::action('observacionDController@edit',$usd->idProd)}}"><button type="button" class="btn btn-outline-success"><i class="fa fa-edit"></i> Add. Observ.</button></a>
                    @endif
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
		
	</div>

	</div>
</div>
{{Form::Close()}}	

</div>