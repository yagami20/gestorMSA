<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data" aria-label="<?php echo e(__('Register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" placeholder="Nombre Apellido" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="cedula" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cédula')); ?></label>

                            <div class="col-md-6">
                                <input id="cedula" type="text" placeholder="0123456789" class="form-control<?php echo e($errors->has('cedula') ? ' is-invalid' : ''); ?>" name="cedula" value="<?php echo e(old('cedula')); ?>" required autofocus>

                                <?php if($errors->has('cedula')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('cedula')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="genero" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Género')); ?></label>

                            <div class="col-md-6">
                                <select name="genero" class="form-control">
                                                <option value="M">Masculino</option>
                                                <option value="F" >Femenino</option>
                                              </select>

                                <?php if($errors->has('genero')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('genero')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaNac" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha Nac.')); ?></label>

                            <div class="col-md-6">
                                <input id="fechaNac" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control<?php echo e($errors->has('fechaNac') ? ' is-invalid' : ''); ?>" name="fechaNac" value="<?php echo e(old('fechaNac')); ?>" required autofocus>

                                <?php if($errors->has('fechaNac')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fechaNac')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Correo Electrónico')); ?></label>

                            <div class="col-md-6">
                                <input id="email" placeholder="nombre@correo.com" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="direccion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Dirección')); ?></label>

                            <div class="col-md-6">
                                <input id="direccion" type="text" placeholder="Direccion" class="form-control<?php echo e($errors->has('direccion') ? ' is-invalid' : ''); ?>" name="direccion" value="<?php echo e(old('direccion')); ?>" required autofocus>

                                <?php if($errors->has('direccion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('direccion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="pais" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pais')); ?></label>

                            <div class="col-md-6">
                                <input id="pais" type="text" placeholder="Pais" class="form-control<?php echo e($errors->has('pais') ? ' is-invalid' : ''); ?>" name="pais" value="<?php echo e(old('pais')); ?>" required autofocus>

                                <?php if($errors->has('pais')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('pais')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="ciudad" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ciudad')); ?></label>

                            <div class="col-md-6">
                                <input id="ciudad" type="text" placeholder="Ciudad" class="form-control<?php echo e($errors->has('ciudad') ? ' is-invalid' : ''); ?>" name="ciudad" value="<?php echo e(old('ciudad')); ?>" required autofocus>

                                <?php if($errors->has('ciudad')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('ciudad')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        <div class="form-group row">
                            <label for="foto" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Foto')); ?></label>

                            <div class="col-md-6">
                                <input id="foto" type="file" name="foto" value="<?php echo e(old('foto')); ?>" required autofocus>

                                <?php if($errors->has('foto')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('foto')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        

                        <!--fin ndatos  -->

                        

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm. Contraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>
                        <!--new datos  -->
                        <!--estado  -->
                        <div class="form-group row">
                                      <!-- <label for="estado" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Estado')); ?></label> -->
                                      <div class="col-md-6">
                                      <!-- <label class="switch"> -->
                                            <!-- <input type="checkbox" name="estado" required value="1" readonly="readonly" /> -->
                                            <input type="hidden" name="estado" required value="0" readonly="readonly" />
                                            <!-- <div class="switch-btn"></div> -->
                                          <!-- </label> -->
                                        </div>                 
                        </div>
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>