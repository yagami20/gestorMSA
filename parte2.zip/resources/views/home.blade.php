@extends('layouts.admin')
<script src="{{ asset('js/app.js') }}" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>
@section('content')
<a href="{{asset('GestorMSA/Graficos3D')}}"><button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">atras X</span>
			
		</button></a>
<!-- <archvista-component></archvista-component> -->
<div id="app">
    <model-stl src="documentos/arch3D/extract/barco.stl"></model-stl>
    
  </div>
<script>
  new Vue({ el: '#app' });
</script>

@endsection
