<!DOCTYPE html>
<html lang="en">
<head>

   <!--- Basic Page Needs
   ================================================== -->
    <meta charset="utf-8">
    <title>M.S.A-3D</title>
    <meta name="description" content="">
    <meta name="author" content="">
   <!-- Mobile Specific Metas
  ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- CSS
   ================================================== -->
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/proyectos.css">
   <!-- Favicons
    ================================================== -->
    <link rel="shortcut icon" href="logomenu.ico" >
</head>

<body data-spy="scroll" data-target="#nav-wrap">
	
   <!-- Header
   ================================================== -->
   <header class="mobile">
      <div class="row">
         <div class="col full">
            <div class="logo" style=" position: relative;" >                    
                  <a href="{{ url('/') }}"><img alt="" src="{{asset('images/logomenu2.ico')}}" style="width: 50px; height: 40px"></a>
            </div>

            <nav id="nav-wrap"> 
                <a class="mobile-btn" href="#nav-wrap" title="Show navigation">Mostrar navegación </a>
                <a class="mobile-btn" href="#" title="Hide navigation">Ocultar navegación</a>
                   <ul id="nav" class="nav">
                       <li><a href="{{asset('/fie')}}">Inicio</a></li>
                       <li><a href="{{asset('/NotificFie')}}">Notificaciones</a></li>
                       <li><a href="{{asset('/DescargaFie')}}">Archivos Descargas</a></li>
                       @if (Route::has('login'))
                        @auth
                              <li><a href="{{ url('/GestorP') }}">MSA3D</a></li>
                        @else
                            <li><a href="{{ route('login') }}">Login</a></li>
                        
                        @endauth
                      
                        @endif
                   </ul>
            </nav>
         </div> 
      </div> 
   </header> <!-- Header End -->


     <!-- Sección servicios
   ================================================== -->
<section id="servicios">
  @yield('content')
</section>
   
   <!-- footer
   ================================================== -->
   <footer>
      <div class="row">
         <div class="col g-7">
            <ul class="copyright">
               <li>&copy; 2014 Kreative</li>
               <li>Design by <a href="http://www.styleshout.com/" title="Styleshout">Styleshout</a></li>
            </ul>
         </div>

         <div class="col g-5 pull-right">
            <ul class="social-links">
               <li><a href="#"><i class="icon-facebook"></i></a></li>
               <li><a href="#"><i class="icon-twitter"></i></a></li>
               <li><a href="#"><i class="icon-google-plus-sign"></i></a></li>
               <li><a href="#"><i class="icon-skype"></i></a></li>         
            </ul>
         </div>
      </div>
   </footer> <!-- Footer End-->

   <!-- Java Script
   ================================================== -->
   <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
   <script>window.jQuery || document.write('<script src="js/jquery-1.10.2.min.js"><\/script>')</script>
   <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
   <script src="js/scrollspy.js"></script>
   <script src="js/jquery.flexslider.js"></script>
   <script src="js/jquery.reveal.js"></script>
   <script src="http://maps.google.com/maps/api/js?sensor=true" type="text/javascript"></script>
   <script src="js/gmaps.js"></script>
   <script src="js/init.js"></script>
   <script src="js/smoothscrolling.js"></script>
  </body>
</html>