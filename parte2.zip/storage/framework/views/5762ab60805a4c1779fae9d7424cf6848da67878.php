<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(URL::action('graficosUController@download',$graf3d->obj3D)); ?>"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Descargar</button></a>
<a href="<?php echo e(asset('GestorUsuario/Graficos3D')); ?>"><button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">atras X</span>
			
		</button></a>
<!-- <archvista-component></archvista-component> -->
<div id="app">
        <model-three src="/documentos/arch3D/extract/<?=  $graf3d->obj3D;   ?>"></model-three>
    </div>
<script>
  new Vue({ el: '#app' });
</script>

<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>