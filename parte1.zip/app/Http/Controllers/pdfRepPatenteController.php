<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//parte llamado

use App\patentesPrP;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\PatentesFormRequest;
use App\Http\Requests\busquedaAppFormRequest;
use phpCAS;

use DB;
use Fpdf;

class pdfRepPatenteController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index(Request $request)
    {
        $request->user()->authorizeRoles(['admin']);
        
        $apg=DB::table('patentes_pr_ps as tbU')
            ->select('tbU.id','tbU.TituloPatent','tbU.ClasePatent','tbU.CertifPatent','tbU.SolicPatent','tbU.ComprovPatent','tbU.AppPatent','tbU.logoApp','tbU.AutorsPatent','tbU.fechaPatent','tbU.DocPatent')
            ->orderBy('tbU.id','desc')
            ->paginate(7);
        return view ('GestorMSA.Reportes.patente.index',["apg"=>$apg]);
    }

    public function show ($id)
    {        
        return view("GestorMSA.Reportes.patente.show"); 
    }

   public function create(Request $request)
    {
        $request->user()->authorizeRoles(['admin']);
        
            $apg=DB::table('patentes_pr_ps as tbU')
            ->select('tbU.TituloPatent','tbU.fechaPatent','tbU.AutorsPatent','tbU.AppPatent')
            ->where('tbU.id','!=',1)
            ->orderBy('tbU.id','desc')
            ->paginate(20);
            $this->bfecha($apg);
    }

public function update(busquedaAppFormRequest $request, $id)
    {

    }


    //
    public function bfecha ($apg)
    {

            Fpdf::AddPage();
            Fpdf::Image('ENCABEZ.JPG',20,20,-100);
            Fpdf::Ln(50);
            Fpdf::SetFont('Arial','B',14);
            Fpdf::Write(5,'Reporte Patente ');
            Fpdf::Ln(10);
            Fpdf::Cell(40,6,'Nombre Patente',1,0,'C');
            Fpdf::Cell(30,6,'Fecha',1,0,'C');
            Fpdf::Cell(70,6,'Autor/es',1,0,'C');
            Fpdf::Cell(75,6,'Documento',1,1,'C');
            Fpdf::SetFont('Arial','',10);

        	foreach($apg as $row)
		    {
		    	$j=0;
		        foreach($row as $col){
                 	if($j==2){
                	Fpdf::Cell(70,6,$col,1); 	
                 	}
                 	else{
                 		if($j==1){
                 			Fpdf::Cell(30,6,$col,1,0,'C');
                 		}
                 		else{
                 			if($j==3){
                 				Fpdf::Cell(75,6,$col,1);
                 			}
                 			else{
                 				Fpdf::Cell(40,6,$col,1);	
                 			}
                 			
                 		}
                 		
                 	}
		            
		            $j++;
		            }
		        Fpdf::Ln();
		    }
            
            Fpdf::Output();
            exit;
    }
    public function destroy(busquedaAppFormRequest $request,$id)
    {
        $fecha1=trim($request->get('FechaInicio')); //determinr texto de busqueda

            $fecha2=trim($request->get('FechaFin')); //determinr texto de busqueda
            $f1=date("Y-m-d", strtotime($request->get('FechaInicio')));
            $f2=date("Y-m-d", strtotime($request->get('FechaFin')));
            $fechaI=DB::table('patentes_pr_ps as tbI')
            ->whereBetween('tbI.fechaPatent',[$f1,$f2])
            ->get();
            if($fechaI)
                {
                    $oficioI=DB::table('patentes_pr_ps as tbU')
            		->select('tbU.TituloPatent','tbU.fechaPatent','tbU.AutorsPatent','tbU.AppPatent')
                        ->whereBetween('tbU.fechaPatent',[$f1,$f2])
                        ->where('tbU.id','!=',1)
                        ->get();
                    // if($oficioI->idOficioI<>'1')
                    // {
                        $this->bfecha($oficioI);
                //fin id
                    // }
            //fin prim if
                }
    }
}
