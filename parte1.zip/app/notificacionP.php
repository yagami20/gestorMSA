<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class notificacionP extends Model
{
    //
    protected $table='notificacion_ps';

    protected $primaryKey='id'; 
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'titulo', 

        'descripcion',

        'foto',

        'docNotif',
    	
        'fechaNotf'
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ];
}
