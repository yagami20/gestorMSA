<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use phpCAS;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    protected function configCas(){

    	$casservername = 'seguridad.espoch.edu.ec';
        $casport = 443;
        $casbaseuri = '/cas';
        $caslogouturl = '/logout?service=';
        $casprotocol = 'https://';
        phpCAS::client(CAS_VERSION_3_0, $casservername, $casport, $casbaseuri);
        phpCAS::setNoCasServerValidation();
    }
}
