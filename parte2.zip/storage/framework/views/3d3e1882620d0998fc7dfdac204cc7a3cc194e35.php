<?php echo Form::open(array('url'=>'GestorMSA/Reportes/aplicacion', 'method'=>'GET','autocomplete'=>'off','role'=>'search')); ?>


<div class="form-group">
	
	<!--  -->
	<div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Fecha Inicio</th>
                  <th>Fecha Fin</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr> 
                <td>
                  <input type="text" class="form-control" name="FechaInicio" placeholder="AA-MM-DD..."value="<?php echo e($FechaInicio); ?>">
              	</td>
                <td>
                <input type="text" class="form-control" name="FechaFin" placeholder="AA-MM-DD..." value="<?php echo e($FechaFin); ?>">
            	</td>
            	<td>
            		
            		
            		<button type="submit" class="btn btn-primary" target="blank">Generar </button>
            	</td>
                </tr>           
              </table>
            </div>
	<!--  -->
		
	
</div>
<?php echo e(Form::close()); ?>

