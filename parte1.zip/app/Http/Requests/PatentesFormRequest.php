<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PatentesFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'TituloPatent' => 'required|string|max:255', 
            'ClasePatent'=>'required|string|max:255',
            'AutorsPatent'=>'required|string|max:255',
            'fechaPatent'=>'required|max:10',
            'DocPatent'=>'mimes:rar,zip,pdf',
            'logoApp'=>'mimes:jpeg,bmp,jpg,png',
            'AppPatent'=>'mimes:rar,zip,pdf',
            'ComprovPatent'=>'mimes:jpeg,bmp,jpg,png',
            'SolicPatent'=>'mimes:pdf',
            'CertifPatent'=>'mimes:pdf'
        ];
    }
}
