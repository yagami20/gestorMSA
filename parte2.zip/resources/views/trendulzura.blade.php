@extends('nav')

@section('content')
<div class="row section-head">
         <div class="col full" align="justify">
            <p class="desc" >             
              <h2> EL TREN DE LA DULZURA</h2> </br>
                  <hr>
                  <dd>
                      <h3 style="color: #11ABB0">
                          OBJETIVOS
                      </h3>
                  </dd>         
                  <dd>
                      Existen varias categorías para diferencias los tipos y clases de aviones a construir:
                      <ul>
                        <li>➤ Diseñar un modelo 3D con Sketchup y Blender.</li>
                        <li>➤ Diseñar los planos del modelo con Adobe Illustrator.</li>
                        <li>➤ Construir el modelo con la técnica de corte CNC-láser.</li>
                        <li>➤ Incluir sistemas de control en el modelo para accionar el modelo e interactuar con el sistema.</li>
                        <li>➤ Incluir fondos y sistemas multimedia  con los paisajes de la costa.</li>
                        <li>➤ Investigar el proceso lúdico de enseñanza a nivel superior.</li>
                        <li>➤ Documentar todo el proceso basado en técnica de Ingeniería de Software.</li>
                      </ul>
                  </dd>                    
            </p>  
              
                <center>
                  <img style="width: 350px; height: 180px;" src="images/proyecto tren/tren1.jpg">
                </center> <br>
                <center>
                  <img style="width: 350px; height: 180px;" src="images/proyecto tren/tren2.jpg">
                </center><br>

                <center>
                  <img style="width: 350px; height: 180px;" src="images/proyecto tren/tren3.png">
                </center><br>
                <center>
                  <img style="width: 350px; height: 220px;" src="images/proyecto tren/tren4.png">
                </center><br>

                <center>
                  <img style="width: 350px; height: 180px;" src="images/proyecto tren/tren5.jpg">
                </center>

               <center>
                  <b><p style="color: darkcyan">Modelos Físicos en construcción. Escala 1: 87 (HO)</p></b>
              </center>
          <button class="regresar">
            <a style="color: white" href="{{asset('/#proyectos')}}">Volver a proyectos</a>
          </button>
  </div>
</div>
@endsection
