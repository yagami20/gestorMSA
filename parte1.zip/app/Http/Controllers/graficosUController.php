<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;

use App\grafico3d;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use App\Http\Requests\graficos3dFormRequest;
use phpCAS;
use ZipArchive;

use DB;
//

class graficosUController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth'); 
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $request->user()->authorizeRoles('user');
        if ($request)
        {
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $graf3d=DB::table('grafico3ds as tbU')
            ->select('tbU.id','tbU.fechaCreacion','tbU.Docgraf3D','tbU.obj3D','tbU.Autorgraf3D','tbU.observacion', 'tbU.tipoSW','tbU.tipoObj','tbU.Desgraf3D')
            ->where('tbU.tipoSW','LIKE','%'.$query.'%')
            ->where('tbU.Autorgraf3D','LIKE','%'.$query.'%')
            ->where('tbU.obj3D','LIKE','%'.$query.'%')
            ->where('tbU.observacion','LIKE','%'.$query.'%')
            ->orwhere('tbU.fechaCreacion','LIKE','%'.$query.'%')
            ->orderBy('tbU.id','desc')
            ->paginate(7);
            return view('GestorUsuario.Graficos3D.index',["graf3d"=>$graf3d,"searchText"=>$query]);

        }
        
    }

    public function show ($id)
    {
        return view("GestorUsuario.Graficos3D.show");
    }

    public function download($obj3D)
    {
        $pathtoFile = public_path().'/documentos/arch3D/extract/'.$obj3D;
            return response()->download($pathtoFile);
    }

    public function verObj(Request $request,$id)
    {
        $request->user()->authorizeRoles(['user']);
        $graf3d=grafico3d::findOrFail($id);
        if ($graf3d->tipoObj=='1')
        {
            return view('GestorUsuario.Graficos3D.vistaJson',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='2')
        {
            return view('GestorUsuario.Graficos3D.vistaObj',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='4')
        {
            return view('GestorUsuario.Graficos3D.vistaStl',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='5')
        {
            return view('GestorUsuario.Graficos3D.vistaDae',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='6')
        {
            return view('GestorUsuario.Graficos3D.vistaPly',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='7')
        {
            return view('GestorUsuario.Graficos3D.vistaGltf',["graf3d"=>$graf3d]);
        }
        
    }
}
