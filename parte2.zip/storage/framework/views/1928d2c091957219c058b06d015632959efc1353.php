<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="<?php echo e(asset('GestorMSA/Almacen')); ?>">Almacen</a>/
                <a href="<?php echo e(asset('GestorMSA/kitSTEAM')); ?>">Kit STEAM</a>/Crear
            </h5>
            <h3>Nuevo Kit STEAM:</h3><br>
            <?php if(count($errors)>0): ?>
            <div class="alert alert-danger">
                <ul>
                <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
    </div>
</div>
            <?php echo Form::open(array('url'=>'GestorMSA/kitSTEAM','method'=>'POST','autocomplete'=>'off','files'=>'true')); ?>

            <?php echo e(Form::token()); ?> 

        <div class="container">
    <div class="row justify-content-center"> 
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="nombreC" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre Caja ')); ?></label>

                            <div class="col-md-6">
                                <input id="nombreC" type="text" placeholder="Simulador #..." class="form-control<?php echo e($errors->has('nombreC') ? ' is-invalid' : ''); ?>" name="nombreC" value="<?php echo e(old('nombreC')); ?>" required autofocus>

                                <?php if($errors->has('nombreC')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('nombreC')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="AutorKit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Autor/es ')); ?></label>

                            <div class="col-md-6">
                                <input id="AutorKit" type="text" placeholder="Autor1, Autor2 #..." class="form-control<?php echo e($errors->has('AutorKit') ? ' is-invalid' : ''); ?>" name="AutorKit" value="<?php echo e(old('AutorKit')); ?>" required autofocus>

                                <?php if($errors->has('AutorKit')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('AutorKit')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="tipoMateria" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipo Material ')); ?></label>

                            <div class="col-md-6">
                                <input id="tipoMateria" type="text" placeholder="hilo PLC..." class="form-control<?php echo e($errors->has('tipoMateria') ? ' is-invalid' : ''); ?>" name="tipoMateria" value="<?php echo e(old('tipoMateria')); ?>" required autofocus>

                                <?php if($errors->has('tipoMateria')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('tipoMateria')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Enlace web:')); ?></label>

                            <div class="col-md-6">
                                <input id="enlaceWeb" type="text" placeholder="www.kitSTEAM.blogspot.com..." class="form-control<?php echo e($errors->has('enlaceWeb') ? ' is-invalid' : ''); ?>" name="enlaceWeb" value="<?php echo e(old('enlaceWeb')); ?>" required autofocus>

                                <?php if($errors->has('enlaceWeb')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('enlaceWeb')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Correo Creador:')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="text" placeholder="autor@..." class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaKit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha de registro')); ?></label>

                            <div class="col-md-6">
                                <input id="fechaKit" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control<?php echo e($errors->has('fechaKit') ? ' is-invalid' : ''); ?>" name="fechaKit" value="<?php echo e(old('fechaKit')); ?>" required autofocus>

                                <?php if($errors->has('fechaKit')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fechaKit')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="portadakit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cargar Foto Portada:')); ?></label>

                            <div class="col-md-6">
                                <input id="portadakit" type="file" name="portadakit" value="<?php echo e(old('portadakit')); ?>" required autofocus>

                                <?php if($errors->has('portadakit')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('portadakit')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="aplicabilidad" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cargar Documento Aplicabilidad:')); ?></label>

                            <div class="col-md-6">
                                <input id="aplicabilidad" type="file" name="aplicabilidad" value="<?php echo e(old('aplicabilidad')); ?>" required autofocus>

                                <?php if($errors->has('aplicabilidad')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('aplicabilidad')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="planos" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cargar archivo Planos:')); ?></label>

                            <div class="col-md-6">
                                <input id="planos" type="file" name="planos" value="<?php echo e(old('planos')); ?>" required autofocus>

                                <?php if($errors->has('planos')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('planos')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="piezaArmar" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Importar Documento pieza Armar:')); ?></label>

                            <div class="col-md-6">
                                <input id="piezaArmar" type="file" name="piezaArmar" value="<?php echo e(old('piezaArmar')); ?>" required autofocus>

                                <?php if($errors->has('piezaArmar')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('piezaArmar')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="instrucciones" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cargar Documento instrucciones ')); ?></label>

                            <div class="col-md-6">
                                <input id="instrucciones" type="file" name="instrucciones" value="<?php echo e(old('instrucciones')); ?>" required autofocus>

                                <?php if($errors->has('instrucciones')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('instrucciones')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="tutoDigital" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Importar video Comprimido ')); ?></label>

                            <div class="col-md-6">
                                <input id="tutoDigital" type="file" name="tutoDigital" value="<?php echo e(old('tutoDigital')); ?>" required autofocus>

                                <?php if($errors->has('tutoDigital')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('tutoDigital')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="informacion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Importar documento de información:')); ?></label>

                            <div class="col-md-6">
                                <input id="informacion" type="file" name="informacion" value="<?php echo e(old('informacion')); ?>" required autofocus>

                                <?php if($errors->has('informacion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('informacion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="codQR" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Importar foto QR:')); ?></label>

                            <div class="col-md-6">
                                <input id="codQR" type="file" name="codQR" value="<?php echo e(old('codQR')); ?>" required autofocus>

                                <?php if($errors->has('codQR')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('codQR')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
                        

                        <!--fin ndatos  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Ingresar')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
            
            


            <?php echo Form::close(); ?>


        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>