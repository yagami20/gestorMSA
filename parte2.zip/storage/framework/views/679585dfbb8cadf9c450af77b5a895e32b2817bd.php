<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Usuario: <?php echo e($usuario->name); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>

	
			

<form method="POST" action="/GestorMSA/PerfilEdit/<?php echo e($usuario->id); ?>" enctype="multipart/form-data">
	<?php echo method_field('PUT'); ?>
	<?php echo csrf_field(); ?>
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>"> -->
                       

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" placeholder="Nombre Apellido" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($usuario->name); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="cedula" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cédula')); ?></label>

                            <div class="col-md-6">
                                <input id="cedula" type="text" placeholder="0123456789" class="form-control<?php echo e($errors->has('cedula') ? ' is-invalid' : ''); ?>" name="cedula" value="<?php echo e($usuario->cedula); ?>" required autofocus>

                                <?php if($errors->has('cedula')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('cedula')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="genero" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Género')); ?></label>

                            <div class="col-md-6">
                                <!-- <div class="col-sm-4"> -->
                                              <select name="genero" class="form-control">
                                                
												<option value="M"selected>Masculino</option>
												
												<option value="F" >Femenino</option>
												
                                                
                                                 
                                              </select>
                                            <!-- </div> -->

                                <?php if($errors->has('genero')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('genero')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                       <!--  <div class="form-group">
                                            <label for="inputGenero" class="col-sm-offset-2 col-sm-3 control-label">Género</label>
                                            <div class="col-sm-4">
                                              <select>
                                                <option value="Masculino">M</option>
                                                <option value="Femenino" >F</option>
                                              </select>
                                            </div>
                                        </div> -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaNac" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha Nac.')); ?></label>

                            <div class="col-md-6">
                                <input id="fechaNac" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control<?php echo e($errors->has('fechaNac') ? ' is-invalid' : ''); ?>" name="fechaNac" value="<?php echo e($usuario->fechaNac); ?>" required autofocus>

                                <?php if($errors->has('fechaNac')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fechaNac')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        
                        <div class="form-group row">
                            <label for="direccion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Dirección')); ?></label>

                            <div class="col-md-6">
                                <input id="direccion" type="text" placeholder="Direccion" class="form-control<?php echo e($errors->has('direccion') ? ' is-invalid' : ''); ?>" name="direccion" value="<?php echo e($usuario->direccion); ?>" required autofocus>

                                <?php if($errors->has('direccion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('direccion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="pais" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pais')); ?></label>

                            <div class="col-md-6">
                                <input id="pais" type="text" placeholder="Pais" class="form-control<?php echo e($errors->has('pais') ? ' is-invalid' : ''); ?>" name="pais" value="<?php echo e($usuario->pais); ?>" required autofocus>

                                <?php if($errors->has('pais')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('pais')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="ciudad" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ciudad')); ?></label>

                            <div class="col-md-6">
                                <input id="ciudad" type="text" placeholder="Ciudad" class="form-control<?php echo e($errors->has('ciudad') ? ' is-invalid' : ''); ?>" name="ciudad" value="<?php echo e($usuario->ciudad); ?>" required autofocus>

                                <?php if($errors->has('ciudad')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('ciudad')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        <div class="form-group row">
                            <label for="foto" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Foto')); ?></label>

                            <div class="col-md-6">
                                <input id="foto" type="file" name="foto" value="<?php echo e(old('foto')); ?>" required autofocus>

                                <?php if($errors->has('foto')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('foto')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        

                        <!--fin ndatos  -->

                        

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm. Contraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>
                        <!--new datos  -->
                        <!--estado  -->
                        <input type="hidden" name="estado" required value="1" readonly="readonly" />
                                            
                        <!--  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Enviar')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>