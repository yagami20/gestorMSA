<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;

use App\kitSteam;
use App\caja;
use App\cajaContenido;
use App\contenidoKit;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use App\Http\Requests\kitSteamFormRequest;
use phpCAS;
use ZipArchive;

use DB;

class kitSTEAMaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        //
        $request->user()->authorizeRoles('admin');
        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $kit=DB::table('kit_steams as tbSI')
            ->join('contenido_kits as tbI', 'tbSI.idContenido','=','tbI.id')
            ->join('caja_contenidos as tbSC','tbI.id','=','tbSC.idContenido')
            ->join('cajas as tbC','tbSC.idCaja','=','tbC.id')
            ->select('tbSI.id','tbSC.id as idCajCont','tbSI.aplicabilidad as App','tbSI.AutorKit as Autor','tbSI.portadakit as Portada','tbSI.fechaKit as fecha',
                'tbSI.planos as plano', 
                'tbSI.email as correo','tbI.piezaArmar as pieza','tbI.instrucciones as instruc',
                'tbI.tutoDigital as tutorial','tbI.enlaceWeb as enlace',
                'tbI.tipoMateria as material','tbC.nombreC as nombreCaja',
                'tbC.informacion as info','tbC.codQR as QR')
            ->where('tbC.informacion','LIKE','%'.$query.'%') 
            ->where('tbC.nombreC','LIKE','%'.$query.'%')
            ->orwhere('tbSI.aplicabilidad','LIKE','%'.$query.'%')
            ->orwhere('tbSI.email','LIKE','%'.$query.'%')
            ->orderBy('tbSI.id','desc')
            ->paginate(7); 
            return view('GestorMSA.kitSTEAM.index',["kit"=>$kit,"searchText"=>$query]); 

        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        //
        $request->user()->authorizeRoles('admin');
        return view ("GestorMSA.kitSTEAM.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(kitSteamFormRequest $request)
    {
        //
        $apg=new caja;

        $apg->nombreC=$request->get('nombreC');

        if (Input::hasFile('informacion')){
         $file=Input::file('informacion');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/kitSTEAM/infoKit/',$nameF);
         $apg->informacion=$nameF;
        }

        if (Input::hasFile('codQR')){
         $file1=Input::file('codQR');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/kitSTEAM/QRkit/',$nameF1);
         $apg->codQR=$nameF1;
        }

        $apg->save();
        $this->addcontenidoKit($apg->id,$request);
        return Redirect::to('GestorMSA/kitSTEAM');

        /* */        
    }
    public function addcontenidoKit ($idCaja,$request)
    {

        $fecha= new contenidoKit;//llamar

        if (Input::hasFile('piezaArmar')){
         $file=Input::file('piezaArmar');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/kitSTEAM/piezaKit/',$nameF);
         $fecha->piezaArmar=$nameF;
        }

        if (Input::hasFile('instrucciones')){
         $file1=Input::file('instrucciones');
         $namef1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/documentos/kitSTEAM/instruccKit/',$namef1);
         $fecha->instrucciones=$namef1;
        }

        if (Input::hasFile('tutoDigital')){
         $file2=Input::file('tutoDigital');
         $namef2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/kitSTEAM/tutKit/',$namef2);
         $fecha->tutoDigital=$namef2;
        }

        $fecha->enlaceWeb=$request->get('enlaceWeb');

        $fecha->tipoMateria=$request->get('tipoMateria');

        $fecha->idCaja=$idCaja;

        $fecha->save();
        $this->descomprimir($fecha->tutoDigital,$fecha->id);
        $this->addcajaContenido($request,$fecha->id,$idCaja);
        /* */
        
                
        return Redirect::to('GestorMSA/kitSTEAM');

    }

    public function addcajaContenido ($request,$idContenido,$idCaja)
    {

        $fechaS= new cajaContenido;//llamar
        $fechaS->idContenido=$idContenido;
        $fechaS->idCaja=$idCaja;
        $fechaS->save();
        $this->addKit($request,$idContenido);
                
        return Redirect::to('GestorMSA/kitSTEAM');

    }

    public function addKit ($request,$idContenido)
    {
        $archIn= new kitSteam;

        if (Input::hasFile('aplicabilidad')){
         $file=Input::file('aplicabilidad');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/kitSTEAM/aplicKit/',$nameF);
         $archIn->aplicabilidad=$nameF;
        }

        if (Input::hasFile('planos')){
         $file1=Input::file('planos');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/documentos/kitSTEAM/planKit/',$nameF1);
         $archIn->planos=$nameF1;
        }

        if (Input::hasFile('portadakit')){
         $file2=Input::file('portadakit');
         $namef2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/imagenes/kitSTEAM/portadaKit/',$namef2);
         $archIn->portadakit=$namef2;
        }

        $archIn->email=$request->get('email');

        $archIn->AutorKit=$request->get('AutorKit');

        $archIn->fechaKit=$request->get('fechaKit');

        $archIn->idContenido=$idContenido;

        $archIn->save();
        $this->descomprimir2($archIn->planos,$archIn->id);
        return Redirect::to('GestorMSA/kitSTEAM');
        /* */
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        return view("GestorMSA.kitSTEAM.show"); 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        //
        $request->user()->authorizeRoles(['admin']);
        $kit=kitSteam::findOrFail($id);
        $contKit=contenidoKit::findOrFail($kit->idContenido);
        $caja=caja::findOrFail($contKit->idCaja);
        return view("GestorMSA.kitSTEAM.edit",["kit"=>$kit,"contKit"=>$contKit,"caja"=>$caja]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $apg= caja::findOrFail($request->get('idCaja'));

        $apg->nombreC=$request->get('nombreC');

        if (Input::hasFile('informacion')){
         $file=Input::file('informacion');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/kitSTEAM/infoKit/',$nameF);
         $apg->informacion=$nameF;
        }

        if (Input::hasFile('codQR')){
         $file1=Input::file('codQR');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/kitSTEAM/QRkit/',$nameF1);
         $apg->codQR=$nameF1;
        }

        $apg->save();
        $this->modcontenidoKit($apg->id,$request);
        return Redirect::to('GestorMSA/kitSTEAM');
        //return Redirect::to('GestorMSA/kitSTEAM');
    }

    public function modcontenidoKit ($idCaja,$request)
    {

        $fecha= contenidoKit::findOrFail($request->get('idContenido'));//llamar

        if (Input::hasFile('piezaArmar')){
         $file=Input::file('piezaArmar');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/kitSTEAM/piezaKit/',$nameF);
         $fecha->piezaArmar=$nameF;
        }

        if (Input::hasFile('instrucciones')){
         $file1=Input::file('instrucciones');
         $namef1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/documentos/kitSTEAM/instruccKit/',$namef1);
         $fecha->instrucciones=$namef1;
        }

        if (Input::hasFile('tutoDigital')){
         $file2=Input::file('tutoDigital');
         $namef2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/kitSTEAM/tutKit/',$namef2);
         $fecha->tutoDigital=$namef2;
        }

        $fecha->enlaceWeb=$request->get('enlaceWeb');

        $fecha->tipoMateria=$request->get('tipoMateria');

        $fecha->idCaja=$idCaja;

        $fecha->save();
        $this->descomprimir($fecha->tutoDigital,$fecha->id);
        $this->ModKit($request,$fecha->id);
        /* */
        
                
        return Redirect::to('GestorMSA/kitSTEAM');

    }

    public function modContenido ($request,$idContenido,$idCaja)
    {

        $fechaS= new cajaContenido;//llamar
        $fechaS->idContenido=$idContenido;
        $fechaS->idCaja=$idCaja;
        $fechaS->save();
        $this->ModKit($request,$idContenido);
                
        return Redirect::to('GestorMSA/kitSTEAM');

    }

    public function ModKit ($request,$idContenido)
    {
        $archIn= kitSteam::findOrFail($request->get('idKit'));

        if (Input::hasFile('aplicabilidad')){
         $file=Input::file('aplicabilidad');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/kitSTEAM/aplicKit/',$nameF);
         $archIn->aplicabilidad=$nameF;
        }

        if (Input::hasFile('planos')){
         $file1=Input::file('planos');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/documentos/kitSTEAM/planKit/',$nameF1);
         $archIn->planos=$nameF1;
        }

        if (Input::hasFile('portadakit')){
         $file2=Input::file('portadakit');
         $namef2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/imagenes/kitSTEAM/portadaKit/',$namef2);
         $archIn->portadakit=$namef2;
        }

        $archIn->email=$request->get('email');

        $archIn->AutorKit=$request->get('AutorKit');

        $archIn->fechaKit=$request->get('fechaKit');

        $archIn->idContenido=$idContenido;

        $archIn->save();
        $this->descomprimir2($archIn->planos,$archIn->id);
        return Redirect::to('GestorMSA/kitSTEAM');
        /* */
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        //
        $apg=kitSteam::findOrFail($id);
        $idCont=$apg->idContenido;
        $apg->delete();

        $apg1=cajaContenido::findOrFail($request->get('idCajCont'));
        $idCaja=$apg1->idCaja;
        $apg1->delete();

        $this->destroy2($idCont,$idCaja);
        return Redirect::to('GestorMSA/kitSTEAM');
    }

    public function destroy2($idCont,$idCaja)
    {
        //
        $apg=contenidoKit::findOrFail($idCont);
        $apg->delete();

        $apg1=caja::findOrFail($idCaja);
        $apg1->delete();
        return Redirect::to('GestorMSA/kitSTEAM');
    }

    public function Download($QR)
    {
        //
        // if(!$this->downloadFile(public_path().'/documentos/aplicaciones/',$examinar)){
        //     return redirect()->back();
        $pathtoFile = public_path().'/imagenes/kitSTEAM/QRkit/'.$QR;
        return response()->download($pathtoFile);
        
    }

    public function downloadPlano($planos)
    {
        $pathtoFile = public_path().'/documentos/kitSTEAM/planKit/extract/'.$planos;
            return response()->download($pathtoFile);
    }

    public function downloadVideo($tutoDigital)
    {
        $pathtoFile = public_path().'/documentos/kitSTEAM/tutKit/'.$tutoDigital;
            return response()->download($pathtoFile);
    }
    public function descomprimir($tutoDigital,$id){
        $zip = new ZipArchive(); $i=0;
        /* */
        $graf3d=contenidoKit::findOrFail($id);

        
        /* */
        $zip->open('documentos/kitSTEAM/tutKit/'.$tutoDigital, ZipArchive::CREATE);
        $zip->extractTo('documentos/kitSTEAM/tutKit/extract/');
        $graf3d->tutoDigital=$zip->getNameIndex($i);//
        $zip->close();
        $graf3d->save();
    }

    public function descomprimir2($planos,$id){
        $zip = new ZipArchive(); $i=0;
        /* */
        $graf3d=kitSteam::findOrFail($id);

        
        /* */
        $zip->open('documentos/kitSTEAM/planKit/'.$planos, ZipArchive::CREATE);
        $zip->extractTo('documentos/kitSTEAM/planKit/extract/');
        $graf3d->planos=$zip->getNameIndex($i);//
        $zip->close();
        $graf3d->save();
    }
}
