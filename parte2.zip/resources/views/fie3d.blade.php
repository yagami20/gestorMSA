@extends('nav')

@section('content')
<div class="row section-head">
         <div class="col full" align="justify">
            <p class="desc" align="justify" >             
              <h2> MÓDULO: Diseño Objetos 3D</h2> 
                  <hr></br>             
                  <p>
                   <b>
                     Este módulo presenta al edificio de la facultad de Informática y Electrónica, tanto a nivel de diseño 3D como en varios modelos a construir en material de madera y plastico, con detalles propios de replicas de colección.
                   </b><br>
                    Como resultado del proyecto de investigación sobre simuladores, se realizó la simulación del edificio en formato 3D. Algunas de las actividades comprendieron:
                    <br>
                    Existen varias categorías para diferencias los tipos y clases de edificaciones a construir
                 
                  <ul>
                    <li>➤ Dibujo del Edificio en 3D (Sketchup /Blender / 3D-Max).</li>
                    <li>➤ Animaciones del Edificio (Ventanas, Techos) con programas de animación 3D (Flash /Blender/ Unity).</li>
                    <!-- <li>➤ Interacción con elementos dinámicos del barco, por ejemplo las maniobras de labor(Flash / Maya / Unity).</li> -->
                    <li>➤ Construcción de la Maqueta física en varias técnicas:</li>
                      <ul>
                        <li>Maqueta en cartulina (técnica del Papercraft).</li>
                        <li>Maqueta en balsa (técnica de Modelismo Naval).</li>
                      </ul>
                    <li>➤ Incorporación de ayuda en línea.</li>
                    <li>➤ Demos con vídeos.</li>
                    <li>➤ Otros elementos de simulación 3D </li>
                  </ul>                    
            </p>              
                <center>
                  <img style="width: 400px; height: 180px;" src="images/proyecto3d/tarjeta.jpg">
                </center>
                <center>
                  <h5 style="color: #11ABB0"> Fig.1. Bosquejo Tarjeta Pop-Up</h5>
                </center>
            <!-- <p>
                 El simulador toma en cuenta algunos parámetros externos como son;
                  <ul>
                    <li>
                      ➤ Dirección del viento
                    </li>
                    <li>
                      ➤ Intensidad del viento
                    </li>
                    <li>
                      ➤ Día / Noche
                    </li>
                  </ul>
                Se pueden realizar las siguientes operaciones de control:
                <ul>
                  <li>➤ Mover los mástiles trasversales con las velas.</li>
                  <li>➤ Realizar la simulación de la maniobra de labor de los travesaños.</li>
                  <li>➤ Obtener de manera visual tipo semáforo los puntajes de acuerdo a la maniobra realizada.</li> 
                  <li>➤ Obtener un valor numérico tipo calificación.</li>
                </ul>
            </p> -->
                <!-- <center>
                <h5 style="color: #11ABB0" align="justify">
                  TOMAS DE PANTALLAS DEL SIMULADOR DEL BUQUE ESCUELA GUAYAS "MADE IN ESPOCH".
                </h5><br>
                </center> -->

                <!-- <center>
                  <img style="width: 320px; height: 180px;" src="images/proyecto tren/buque/b2.jpg">
                </center><br>
                <center>
                  <img style="width: 320px; height: 180px;" src="images/proyecto tren/buque/b3.jpg"> 
                </center><br>
                <center>
                  <img style="width: 240px; height: 310px;" src="images/proyecto tren/buque/b4.jpg">
                </center> -->              
            <center>
              <h5 style="color: #11ABB0" align="justify">
                EDIFICIO REAL QUE SE PUEDE VISITAR EN LA ESCUELA SUPERIOR POLITECNICA DE CHIMBORAZO EN RIOBAMBA - ECUADOR
              </h5>
            </center>                  
          <center>
            <img style="width: 440px; height: 310px;" src="images/proyecto3d/fie.jpg">
          </center><br>
          <center>
           <img style="width: 400px; height: 240px;" src="images/proyecto3d/fie3.jpg"> 
          </center><br>
          <center>
            <h5 style="color: #11ABB0"> 
              PARTE FRONTAL DEL EDIFICIO
            </h5>
          </center>
          <center>
            <img style="width: 400px; height: 240px;" src="images/proyecto3d/fie2.jpg">
          </center><br>
          <!-- <center>
            <h5 style="color: #11ABB0"> 
              MAQUETA DEL BESGUA EN ESCALA 1:250
            </h5>
          </center>
          <center>
            <img style="width: 400px; height: 240px;" src="images/proyecto tren/buque/b8.jpg">
          </center> -->
          <center>
            <h5 style="color: #11ABB0"> 
              Vista de objeto 3D
            </h5>
          </center><br>
          <center><a href="{{asset('/Fie3DEdif')}}"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-edit"></i> Ver Objeto</button></center></a><br>
          <button class="regresar">
            <a style="color: white" href="{{asset('/#proyectos')}}">Volver a proyectos</a>
          </button>
  </div>
</div>
@endsection
