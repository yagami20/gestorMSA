@extends('nav')

@section('content')
<div class="row section-head">
         <div class="col full" align="justify">
		<p class="desc" >           	
			<h2> AEROMODELISMO </h2> 
			    <hr></br>
			        <h3 style="color: #11ABB0;">
			            1.- INTRODUCCIÓN
			        </h3>
			    </dd>
			    <dd>
			        El aeromodelismo comprende el estudio, diseño y construcción de modelos de aviones, los mismos que pueden fabricados en diferentes materiales como balsa (lo más común), madera, cartón, papel.
			    </dd>  </br>              
			    <dd>
			        <h3 style="color: #11ABB0;">
			            2.- CATEGORÍAS
			        </h3>
			    </dd>
			    <dd>
			        Existen varias categorías para diferencias los tipos y clases de aviones a construir
			        <ul>
			        	<li>➤CATEGORÍA DE VUELO LIBRE</li>
			        	<li>➤CATEGORÍA DE MAQUETAS</li>
			        	<li>➤CATEGORÍA DE RADIO CONTROL</li>
			        </ul>
			    </dd>  
			    <dd>
			    	<h3 style="color: #11ABB0">
			    		3.- CATEGORÍA VUELO LIBRE
			    	</h3>
			    </dd>  
			    <dd>
			        Comprende la construcción de modelos de avión que pueden ser propulsados con la fuerza de la mano, o de algún mecanismo de impulso (elásticos, catapultas, otros).
			    </dd>     
			    <dd>
			    	<h5 style="color: #11ABB0">
			    		<center>PLANOS</center> 
		    		</h5>
			    </dd>     
					<center><img style="width: 400px; height: 180px;" src="images/proyecto tren/aeromodelismo/aeromodelismo1.jpg"></center>
			    <dd>
			    	<center><h5 style="color: #11ABB0">
			    		 MODELO TERMINADO
					</h5></center>
			    </dd>    
			     <center><img style="width: 400px; height: 180px;" src="images/proyecto tren/aeromodelismo/aeromodelismo2.jpg"></center>
		</p>    
		
		<button class="regresar">
			<a style="color: white" href="{{asset('/#proyectos')}}">Volver a proyectos</a>
		</button> 
	</div>
</div>
@stop