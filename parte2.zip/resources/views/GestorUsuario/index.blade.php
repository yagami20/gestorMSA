@extends ('layouts.user')
@section ('content')
							<h3>QUIENES SOMOS</h3>
							
                              <center><img src="{{asset('logo.png')}}"></center>
                              El Grupo de investigación Modelado Simulación y Animación 3D (MSA-3D) se inscribe prioritariamente, en lo relativo a la línea nacional de investigación  “Tecnologías de la Información, Comunicación y Procesos Industriales”. Específicamente el Grupo (MSA-3D) se concentra en diseñar y producir objetos y servicios tridimensionales o 3D para la educación superior e investigación productiva. <p></p>
                              <center><img src="{{asset('i1.jpg')}}"></center>
@endsection