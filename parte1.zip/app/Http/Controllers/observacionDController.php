<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\TarjetasFormRequest;
use App\tarjetasPP;
use App\autor;
use App\kitSteam;
use App\caja;
use App\cajaContenido;
use App\contenidoKit;
use App\producto; 

use DB;
//

class observacionDController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        $request->user()->authorizeRoles(['docent']);
        $prod=producto::findOrFail($id);
        //dd($request->get('band'));
        if ($prod->idKit=='1'){
            $tarjetaspp=tarjetasPP::findOrFail($prod->idTarj);
            $band='1';
            //dd($prod->idTarj);
            return view("GestorDocente.ObservacionD.edit",["tarjetaspp"=>$tarjetaspp,"band"=>$band,"prod"=>$prod]);
        }
        
        //
        if ($prod->idTarj=='1'){
        $kit=kitSteam::findOrFail($prod->idKit);
        $contKit=contenidoKit::findOrFail($kit->idContenido);
        $caja=caja::findOrFail($contKit->idCaja);
        $band='2';
        //dd($prod->idKit);
        return view("GestorDocente.ObservacionD.edit",["caja"=>$caja,"band"=>$band,"prod"=>$prod]);
        }
        //
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $tarjetaspp=new autor;

        $tarjetaspp->nombreA=$request->get('nombreA');
        
        if (Input::hasFile('DocObserv')){
         $file2=Input::file('DocObserv');
         $nameF2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/docObserv/',$nameF2);
         $tarjetaspp->DocObserv=$nameF2; 
        }

        $tarjetaspp->save();

        $this->modProduct($tarjetaspp->id,$request);
        
        if ($request->get('band')=='1'){
            return Redirect::to('GestorDocente/tarjetasPopUp');
        }
        if ($request->get('band')=='2'){
            return Redirect::to('GestorDocente/kitSTEAM');
        }

    }

    public function modProduct ($idAutor,$request)
    {
        $fecha= producto::findOrFail($request->get('idProducto'));
        $fecha->idAutor=$idAutor;

        $fecha->save();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function download($id)
    {
        //
        // if(!$this->downloadFile(public_path().'/documentos/aplicaciones/',$examinar)){
        //     return redirect()->back();
        $pathtoFile = public_path().'/documentos/docTarjPP/'.$examinar;
        return response()->download($pathtoFile);
        
    }
}
