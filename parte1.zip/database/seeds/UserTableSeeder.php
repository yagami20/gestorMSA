<?php

use Illuminate\Database\Seeder;
use gestorMSA\Role;
use gestorMSA\User;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $role_user = Role::where('name','user')->first();
        $role_admin = Role::where('name','admin')->first();
        $role_docent = Role::where('name','docent')->first();
        
        
        $user=new User();
        $user->name="Juan Perez";
        $user->email="juanP@hotmail.com";
        $user->password=bcrypt('juan123'); 
        $user->cedula = "1721617245";
        $user->direccion = "Av. Milton Reyes y Luis Urdaneta";
        $user->genero = "M";
        $user->fechaNac = "1987-12-1";
        $user->foto = "user.jpg";
        $user->pais = "Ecuador";
        $user->ciudad = "Quito";
        $user->estado = "1";
        $user->save();
        $user->roles()->attach($role_user);

        $user = new User();
        $user->name = "Marlon Mosquera";
        $user->email = "marlonmosquera_2005@hotmail.com";
        $user->password = bcrypt('bartolomeo');
        $user->cedula = "1719615245";
        $user->direccion = "Av. Milton Reyes y Luis Urdaneta";
        $user->genero = "M";
        $user->fechaNac = "1989-12-1";
        $user->foto = "admin.png";
        $user->pais = "Ecuador";
        $user->ciudad = "Quito";
        $user->estado = "1";
        $user->save();
        $user->roles()->attach($role_admin);

        $user=new User();
        $user->name="Docent";
        $user->email="adryvelaz@hotmail.com";
        $user->password=bcrypt('adriV123');
        $user->cedula = "1639621245";
        $user->direccion = "Av. Milton Reyes y Luis Urdaneta";
        $user->genero = "M";
        $user->fechaNac = "1990-12-1";
        $user->foto = "docente.png";
        $user->pais = "Ecuador";
        $user->ciudad = "Quito";
        $user->estado = "1";
        $user->save();
        $user->roles()->attach($role_docent);

    }
}
