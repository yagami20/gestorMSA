<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\TarjetasFormRequest;
use App\tarjetasPP;
use App\producto; 

use DB;
//

class tarjetaPopUpD extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function __construct()
    {
        $this->middleware('auth'); 
    }

    public function index(Request $request)
    {
        //
        $request->user()->authorizeRoles('docent');
        if ($request)
        { 
        
            
            $query=trim($request->get('searchText')); //determinr texto de busqueda

            $prod=DB::table('productos as tbP')
            ->select('tbP.id','tbP.nombreP','tbP.idTarj','tbP.idUser')
            ->orderBy('tbP.id','asc');

            
            $tarjetaspp=DB::table('tarjetas_p_ps as tbSI')
            ->join('productos as tbI', 'tbSI.id','=','tbI.idTarj')
            ->join('autors as tbA', 'tbA.id','=','tbI.idAutor')
            ->select('tbSI.id','tbI.id as idProd','tbI.idAutor as idObserv',
                'tbA.nombreA','tbA.DocObserv',  
                'tbSI.DesTarjet','tbSI.AutorTarj','tbI.idUser',
                'tbSI.QRTarjet','tbSI.NombTarj','tbSI.fotoApp','tbSI.examinar',
                'tbSI.fechaCreacT')
            
            ->where('tbSI.NombTarj','LIKE','%'.$query.'%')
            ->orwhere('tbSI.DesTarjet','LIKE','%'.$query.'%')
            ->orwhere('tbSI.fechaCreacT','LIKE','%'.$query.'%')

            
            ->orderBy('tbSI.id','desc')

            ->paginate(7);

            return view ('GestorDocente.tarjetasPopUp.index',["prod"=>$prod,"tarjetaspp"=>$tarjetaspp,"searchText"=>$query]);
            
        } 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        //
        $request->user()->authorizeRoles('docent');
        return view ("GestorDocente.tarjetasPopUp.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TarjetasFormRequest $request)
    {
        //
        $tarjetaspp=new tarjetasPP;

        $tarjetaspp->NombTarj=$request->get('NombTarj');

        $tarjetaspp->DesTarjet=$request->get('DesTarjet');

        $tarjetaspp->AutorTarj=$request->get('AutorTarj');

        $tarjetaspp->fechaCreacT=$request->get('fechaCreacT');
        
        if (Input::hasFile('fotoApp')){
         $file1=Input::file('fotoApp');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/tarjtPP/img/',$nameF1);
         $tarjetaspp->fotoApp=$nameF1; 
        }

        if (Input::hasFile('examinar')){
         $file2=Input::file('examinar');
         $nameF2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/docTarjPP/',$nameF2);
         $tarjetaspp->examinar=$nameF2; 
        }

        if (Input::hasFile('QRTarjet')){
         $file=Input::file('QRTarjet');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/imagenes/tarjtPP/QRimg/',$nameF);
         $tarjetaspp->QRTarjet=$nameF;
        }

        $tarjetaspp->save();
        $this->addProduct($tarjetaspp->id,$request);

        return Redirect::to('GestorDocente/tarjetasPopUp');
    }

    public function addProduct ($idTarjet,$request)
    {
        $fecha= new producto;//llamar
        $fecha->nombreP=$request->get('NombTarj');
        $fecha->idGraf3D=$request->get('idGraf3D');
        $fecha->idarchPlano=$request->get('idarchPlano');
        $fecha->idApp=$request->get('idApp');
        $fecha->idKit=$request->get('idKit');
        $fecha->idUser=$request->get('idUser');
        $fecha->idTarj=$idTarjet;
        $fecha->idPatent=$request->get('idPatent');
        $fecha->idAutor=$request->get('idAutor');

        $fecha->save();
        // $this->addcajaContenido($request,$fecha->id,$idCaja);
        /* */
        
                
        return Redirect::to('GestorDocente/tarjetasPopUp');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        return view("GestorDocente.tarjetasPopUp.show");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        //
        $request->user()->authorizeRoles(['docent']);
        $prod=producto::findOrFail($id);
        $tarjetaspp=tarjetasPP::findOrFail($prod->idTarj);

        return view("GestorDocente.tarjetasPopUp.edit",["prod"=>$prod,"tarjetaspp"=>$tarjetaspp]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $tarjetaspp=tarjetasPP::findOrFail($id);

        $tarjetaspp->NombTarj=$request->get('NombTarj');

        $tarjetaspp->DesTarjet=$request->get('DesTarjet');

        $tarjetaspp->AutorTarj=$request->get('AutorTarj');

        $tarjetaspp->fechaCreacT=$request->get('fechaCreacT');
        
        if (Input::hasFile('fotoApp')){
         $file1=Input::file('fotoApp');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/tarjtPP/img/',$nameF1);
         $tarjetaspp->fotoApp=$nameF1; 
        }

        if (Input::hasFile('examinar')){
         $file2=Input::file('examinar');
         $nameF2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/docTarjPP/',$nameF2);
         $tarjetaspp->examinar=$nameF2; 
        }

        if (Input::hasFile('QRTarjet')){
         $file=Input::file('QRTarjet');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/imagenes/tarjtPP/QRimg/',$nameF);
         $tarjetaspp->QRTarjet=$nameF;
        }

        $tarjetaspp->save();
        $this->modProduct($tarjetaspp->id,$request);
        // dd($apg);
        return Redirect::to('GestorDocente/tarjetasPopUp');
    }

    public function modProduct ($idTarjet,$request)
    {
        $fecha= producto::findOrFail($request->get('idProducto'));
        $fecha->nombreP=$request->get('NombTarj');

        $fecha->save();
        // $this->addcajaContenido($request,$fecha->id,$idCaja);
        /* */
        
                
        return Redirect::to('GestorDocente/tarjetasPopUp');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $prod=producto::findOrFail($id);
        $idTarj=$prod->idTarj;
        $prod->delete();
        $this->destroy2($idTarj);
        return Redirect::to('GestorDocente/tarjetasPopUp');
    }
    public function destroy2($id)
    {
        //
        $tarjetaspp=tarjetasPP::findOrFail($id);
        $tarjetaspp->delete();
        return Redirect::to('GestorDocente/tarjetasPopUp');
    }

    public function Download($examinar)
    {
        //
        // if(!$this->downloadFile(public_path().'/documentos/aplicaciones/',$examinar)){
        //     return redirect()->back();
        $pathtoFile = public_path().'/documentos/docTarjPP/'.$examinar;
        return response()->download($pathtoFile);
        
    }
}
