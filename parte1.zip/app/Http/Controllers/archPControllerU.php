<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;

use App\archPlano;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use App\Http\Requests\archPFormRequest;
use phpCAS;

use DB;  
//

class archPControllerU extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(Request $request)
    {
        $request->user()->authorizeRoles('user');
        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $archP=DB::table('arch_planos as tbU')
            ->select('tbU.id','tbU.TipoArchivo','tbU.DocArchP','tbU.ImgArchP','tbU.AutorArchP','tbU.fechaGener','tbU.objPlano', 'tbU.observacion','tbU.tipoObjP','tbU.DesArchP')
            ->where('tbU.TipoArchivo','LIKE','%'.$query.'%')
            ->orwhere('tbU.fechaGener','LIKE','%'.$query.'%')
            ->orderBy('tbU.id','desc')
            ->paginate(7);
            return view('GestorUsuario.archPlanos.index',["archP"=>$archP,"searchText"=>$query]);

        }
    }
    public function show ($id)
    {
        return view("GestorUsuario.archPlanos.show"); 
    }
    public function download($objPlano)
    {
        $pathtoFile = public_path().'/documentos/archPlanos/'.$objPlano;
            return response()->download($pathtoFile);
    }
}
