<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;

use App\aplicacion;
use App\producto;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use App\Http\Requests\AplicacionFormRequest;
use App\Http\Requests\UserUpdateFormRequest;
use phpCAS;

use DB;  
//

class AplicacionesDController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $request->user()->authorizeRoles(['docent']);
        if ($request)
        {
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $apg=DB::table('aplicacions as tbU')
            ->join('productos as tbI', 'tbU.id','=','tbI.idApp')
            ->select('tbU.id','tbI.id as idProd','tbI.idUser','tbU.tipoSW','tbU.DesApp','tbU.AutorApp','tbU.fechaReproduc','tbU.examinar', 'tbU.fotoApp')
            ->where('tbU.tipoSW','LIKE','%'.$query.'%')
            ->orwhere('tbU.fechaReproduc','LIKE','%'.$query.'%') 
            ->orderBy('tbU.id','desc')
            ->paginate(7);
            return view('GestorDocente.Aplicaciones.index',["apg"=>$apg,"searchText"=>$query]);

        }
    }
    public function create(Request $request)
    {
        $request->user()->authorizeRoles(['docent']);
        return view ("GestorDocente.Aplicaciones.create");
    }

    
public function store (AplicacionFormRequest $request)
    {
        $apg=new aplicacion;

        $apg->tipoSW=$request->get('tipoSW');

        $apg->DesApp=$request->get('DesApp');

        $apg->AutorApp=$request->get('AutorApp');

        $apg->fechaReproduc=$request->get('fechaReproduc');

        if (Input::hasFile('fotoApp')){
         $file1=Input::file('fotoApp');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/software/',$nameF1);
         $apg->fotoApp=$nameF1;
        }

        if (Input::hasFile('examinar')){
         $file=Input::file('examinar');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/aplicaciones/',$nameF);
         $apg->examinar=$nameF;
        }

        $apg->save();
        $this->addProduct($apg->id,$request);

        return Redirect::to('GestorDocente/AplicacionesD');
    }

    public function addProduct ($idApp,$request)
    {
        $fecha= new producto;//llamar
        $fecha->nombreP=$request->get('tipoSW');
        $fecha->idGraf3D=$request->get('idGraf3D');
        $fecha->idarchPlano=$request->get('idarchPlano');
        $fecha->idApp=$idApp;
        $fecha->idKit=$request->get('idKit');
        $fecha->idUser=$request->get('idUser');
        $fecha->idTarj=$request->get('idTarj');
        $fecha->idPatent=$request->get('idPatent');
        $fecha->idAutor=$request->get('idAutor');

        $fecha->save();
        // $this->addcajaContenido($request,$fecha->id,$idCaja);
        /* */
        
                
        return Redirect::to('GestorDocente/AplicacionesD');

    }


    
public function show ($id)
    {
        return view("GestorDocente.Aplicaciones.show"); 
    }

    
public function edit(Request $request,$id)
    {
        $request->user()->authorizeRoles(['docent']);
        $prod=producto::findOrFail($id);
        $apg=aplicacion::findOrFail($prod->idApp);
        return view("GestorDocente.Aplicaciones.edit",["prod"=>$prod,"apg"=>$apg]);
    }

    
public function update(AplicacionFormRequest $request, $id)
    {
        $apg=aplicacion::findOrFail($id);

        $apg->tipoSW=$request->get('tipoSW');

        $apg->DesApp=$request->get('DesApp');

        $apg->AutorApp=$request->get('AutorApp');

        $apg->fechaReproduc=$request->get('fechaReproduc');

        if (Input::hasFile('fotoApp')){
         $file1=Input::file('fotoApp');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/software/',$nameF1);
         $apg->fotoApp=$nameF1;
        }

        if (Input::hasFile('examinar')){
         $file=Input::file('examinar');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/aplicaciones/',$nameF);
         $apg->examinar=$nameF;
        }

        $apg->save();
        $this->modProduct($apg->id,$request);
        return Redirect::to('GestorDocente/AplicacionesD');
    }

    public function modProduct ($idApp,$request)
    {
        $fecha= producto::findOrFail($request->get('idProducto'));
        $fecha->nombreP=$request->get('tipoSW');

        $fecha->save();
        // $this->addcajaContenido($request,$fecha->id,$idCaja);
        /* */
        
                
        return Redirect::to('GestorDocente/AplicacionesD');

    }

    

public function destroy($id)
    {
        $prod=producto::findOrFail($id);
        $idApp=$prod->idApp;
        $prod->delete();
        $apg=aplicacion::findOrFail($idApp);
        $apg->delete();
        return Redirect::to('GestorDocente/Aplicaciones');
    }
}
