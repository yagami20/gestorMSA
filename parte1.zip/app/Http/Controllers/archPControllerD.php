<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;

use App\archPlano;
use App\producto;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use App\Http\Requests\archPFormRequest;
use phpCAS;

use DB;  
//

class archPControllerD extends Controller
{
    ////
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $request->user()->authorizeRoles('docent');
        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $archP=DB::table('arch_planos as tbU')
            ->join('productos as tbI', 'tbU.id','=','tbI.idarchPlano')
            ->select('tbU.id','tbI.id as idProd','tbI.idUser','tbU.TipoArchivo','tbU.DocArchP','tbU.ImgArchP','tbU.AutorArchP','tbU.fechaGener','tbU.objPlano', 'tbU.observacion','tbU.tipoObjP','tbU.DesArchP')
            ->where('tbU.TipoArchivo','LIKE','%'.$query.'%')
            ->orwhere('tbU.fechaGener','LIKE','%'.$query.'%')
            ->orderBy('tbU.id','desc')
            ->paginate(7);
            return view('GestorDocente.archPlanos.index',["archP"=>$archP,"searchText"=>$query]);

        }
    }
    public function create(Request $request)
    {
        $request->user()->authorizeRoles('docent');
        return view ("GestorDocente.archPlanos.create");
    }

    
public function store (archPFormRequest $request)
    {
        $archP=new archPlano;

        $archP->TipoArchivo=$request->get('TipoArchivo');

        $archP->DesArchP=$request->get('DesArchP');

        $archP->AutorArchP=$request->get('AutorArchP');

        $archP->fechaGener=$request->get('fechaGener');

        if (Input::hasFile('objPlano')){
         $file1=Input::file('objPlano');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/documentos/archPlanos/',$nameF1);
         $archP->objPlano=$nameF1;
        }

        if (Input::hasFile('DocArchP')){
         $file2=Input::file('DocArchP');
         $namef2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/archPlanos/document/',$namef2);
         $archP->DocArchP=$namef2;
        }

        if (Input::hasFile('ImgArchP')){
         $file3=Input::file('ImgArchP');
         $nameF3=time().$file3->getClientOriginalName();
         $file3->move(public_path().'/imagenes/archPlanos/',$nameF3);
         $archP->ImgArchP=$nameF3;
        }

        $archP->observacion=$request->get('observacion');

        $archP->tipoObjP=$request->get('tipoObjP');
        
        $archP->save();
        $this->addProduct($archP->id,$request);
        return Redirect::to('GestorDocente/archPlanos');
    }

    public function addProduct ($idarchPlano,$request)
    {
        $fecha= new producto;//llamar
        $fecha->nombreP=$request->get('TipoArchivo');
        $fecha->idGraf3D=$request->get('idGraf3D');
        $fecha->idarchPlano=$idarchPlano;
        $fecha->idApp=$request->get('idApp');
        $fecha->idKit=$request->get('idKit');
        $fecha->idUser=$request->get('idUser');
        $fecha->idTarj=$request->get('idTarj');
        $fecha->idPatent=$request->get('idPatent');
        $fecha->idAutor=$request->get('idAutor');

        $fecha->save();
        // $this->addcajaContenido($request,$fecha->id,$idCaja);
        /* */
        
                
        return Redirect::to('GestorDocente/archPlanos');

    }


    
public function show ($id)
    {
        return view("GestorDocente.archPlanos.show"); 
    }

    
public function edit(Request $request,$id)
    {
        $request->user()->authorizeRoles(['docent']);
        $prod=producto::findOrFail($id);
        $archP=archPlano::findOrFail($prod->idarchPlano);
        return view("GestorDocente.archPlanos.edit",["prod"=>$prod,"archP"=>$archP]);
    }

    
public function update(archPFormRequest $request, $id)
    {
        $archP=archPlano::findOrFail($id);

        $archP->TipoArchivo=$request->get('TipoArchivo');

        $archP->DesArchP=$request->get('DesArchP');

        $archP->AutorArchP=$request->get('AutorArchP');

        $archP->fechaGener=$request->get('fechaGener');

        if (Input::hasFile('objPlano')){
         $file1=Input::file('objPlano');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/documentos/archPlanos/',$nameF1);
         $archP->objPlano=$nameF1;
        }

        if (Input::hasFile('DocArchP')){
         $file2=Input::file('DocArchP');
         $namef2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/archPlanos/document/',$namef2);
         $archP->DocArchP=$namef2;
        }

        if (Input::hasFile('ImgArchP')){
         $file3=Input::file('ImgArchP');
         $nameF3=time().$file3->getClientOriginalName();
         $file3->move(public_path().'/imagenes/archPlanos/',$nameF3);
         $archP->ImgArchP=$nameF3;
        }

        $archP->observacion=$request->get('observacion');

        $archP->tipoObjP=$request->get('tipoObjP');

        $archP->save();
        $this->modProduct($archP->id,$request);
        // dd($apg);
        return Redirect::to('GestorDocente/archPlanos');
    }

    public function modProduct ($idApp,$request)
    {
        $fecha= producto::findOrFail($request->get('idProducto'));
        $fecha->nombreP=$request->get('TipoArchivo');

        $fecha->save();
        // $this->addcajaContenido($request,$fecha->id,$idCaja);
        /* */
        
                
        return Redirect::to('GestorDocente/archPlanos');

    }

    

    public function destroy($id)
    {
        $prod=producto::findOrFail($id);
        $idArch=$prod->idarchPlano;
        $prod->delete();
        $archP=archPlano::findOrFail($idArch);
        $archP->delete();
        return Redirect::to('GestorDocente/archPlanos');
    }

    public function download($objPlano)
    {
        $pathtoFile = public_path().'/documentos/archPlanos/'.$objPlano;
            return response()->download($pathtoFile);
    }
}
