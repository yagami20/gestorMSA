@extends ('layouts.docente')
@section ('content')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="{{asset('GestorDocente/Almacen')}}">Almacen</a>/
                <a href="{{asset('GestorDocente/Graficos3D')}}">Graficos 3D</a>/Crear
            </h5>
			<h3>Nuevo Objeto 3D</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>
			{!!Form::open(array('url'=>'GestorDocente/Graficos3D','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			{{Form::token()}}

		<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    
                        @csrf

                        <div class="form-group row">
                            <label for="tipoSW" class="col-md-4 col-form-label text-md-right">{{ __('Tipo de Software de Creación') }}</label>

                            <div class="col-md-6">
                                <input id="tipoSW" type="text" title="Nombre que se le da al objeto 3D" placeholder="S.W. de Creación" class="form-control{{ $errors->has('tipoSW') ? ' is-invalid' : '' }}" name="tipoSW" value="{{ old('tipoSW') }}" required autofocus>

                                @if ($errors->has('tipoSW'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('tipoSW') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="Autorgraf3D" class="col-md-4 col-form-label text-md-right">{{ __('Autor/es') }}</label>

                            <div class="col-md-6">
                                <input id="Autorgraf3D" type="text" title="Autor o autores que coperaron en la creación" placeholder="Autor1, Autor2#..." class="form-control{{ $errors->has('Autorgraf3D') ? ' is-invalid' : '' }}" name="Autorgraf3D" value="{{ old('Autorgraf3D') }}" required autofocus>

                                @if ($errors->has('Autorgraf3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('Autorgraf3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="Desgraf3D" class="col-md-4 col-form-label text-md-right">{{ __('Descripción') }}</label>

                            <div class="col-md-6">
                                <input id="Desgraf3D" type="text" title="Breve descripcion del objeto 3D" placeholder="Descripcion de Obj. 3D" class="form-control{{ $errors->has('Desgraf3D') ? ' is-invalid' : '' }}" name="Desgraf3D" value="{{ old('Desgraf3D') }}" required autofocus>

                                @if ($errors->has('Desgraf3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('Desgraf3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaCreacion" class="col-md-4 col-form-label text-md-right">{{ __('Fecha Creación') }}</label>

                            <div class="col-md-6">
                                <input id="fechaCreacion" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('fechaCreacion') ? ' is-invalid' : '' }}" name="fechaCreacion" value="{{ old('fechaCreacion') }}" required autofocus>

                                @if ($errors->has('fechaCreacion'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fechaCreacion') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        
                        <div class="form-group row">
                            <label for="obj3D" class="col-md-4 col-form-label text-md-right">{{ __('Agregar Objeto (extensión: dae,gltf,json,obj,ply,stl y comprimido en zip)') }}</label>

                            <div class="col-md-6">
                                <input id="obj3D" type="file" title="Objeto comprimido en formato zip con todos los archivos que se generaron" name="obj3D" value="{{ old('obj3D') }}" required autofocus>

                                @if ($errors->has('obj3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('obj3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="Docgraf3D" class="col-md-4 col-form-label text-md-right">{{ __('Agregar Documento Objeto (extensión: pdf)') }}</label>

                            <div class="col-md-6">
                                <input id="Docgraf3D" type="file" title="Documento pdf del objeto 3D" name="Docgraf3D" value="{{ old('Docgraf3D') }}" required autofocus>

                                @if ($errors->has('Docgraf3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('Docgraf3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="observacion" class="col-md-4 col-form-label text-md-right">{{ __('Observación de archivo') }}</label>

                            <div class="col-md-6">
                                <input id="observacion" type="text" title="Breve observación del  objeto o comentario importante para su manejo" placeholder="abrir con Sketchup..." class="form-control{{ $errors->has('observacion') ? ' is-invalid' : '' }}" name="observacion" value="{{ old('observacion') }}" required autofocus>

                                @if ($errors->has('observacion'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('observacion') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="tipoObj" class="col-md-4 col-form-label text-md-right">{{ __('Tipo de objeto') }}</label>

                            <div class="col-md-6">
                                <!-- <div class="col-sm-4"> -->
                                              <select name="tipoObj" class="form-control">
                                                {{--  --}}
                                                
                                                {{--  --}}
                                                <option value="1">Objeto Json</option>
                                                <option value="2">Objeto Obj</option>
                                                <option value="4">Objeto Stl</option>
                                                <option value="5">Objeto Dae</option>
                                                <option value="6">Objeto Ply</option>
                                                <option value="7">Objeto Gltf</option>
                                            </select>
                                            <!-- </div> -->

                                @if ($errors->has('tipoObj'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('tipoObj') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--fin ndatos  -->
                        <!--  -->
                       
                                <input type="hidden" name="idUser" value="{{ Auth::user()->id }}">
                         
                        <!--  -->
                      
                                <input type="hidden" name="idPatent" value="1">
                      
                        <!--  -->
                      
                                <input type="hidden" name="idarchPlano" value="1">
                        
                        <!--  -->
                      
                                <input type="hidden" name="idApp" value="1">
                         
                        <!--  -->
                     
                                <input type="hidden" name="idTarj" value="1">
                        
                        <!--  -->
                      
                                <input type="hidden" name="idKit" value="1">
                         
                        <!--  -->
                      
                                <input type="hidden" name="idAutor" value="1">
                        
                        <!--  -->
                        <!--new datos  -->
                        <!--estado  -->
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
{!!Form::close()!!}

		
@endsection