<?php

use Illuminate\Database\Seeder;
use gestorMSA\archPlano;

class archPlanoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $arcp= new archPlano();
        $arcp->TipoArchivo = "N/A";
        $arcp->DesArchP="sin descripcion";
        $arcp->fechaGener = "2019-01-01";
        $arcp->objPlano = "n/a"; 
        $arcp->observacion = "sin Observ";
        $arcp->tipoObjP = "1";
        $arcp->save();
    }
}
