    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<?php $__env->startSection('content'); ?>
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Reporte General Grafico 3D: <a href="graf3d/create"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Generar</button></a>
    <a href="" data-target="#modal-foto-<?php echo e($apg->id='1'); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Buscar</button></a></h3>
    <?php echo $__env->make('GestorDocente.Reportes.graf3d.modal2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <h3>Listado de Grafico 3D</h3> 
	</div> 
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Código</th>
                  <th>tipo S.W.</th>
                  <th>Autor/es</th>
                  <th>fecha Creación</th>
                  <th>observación</th>
                  <th>obj 3D</th>
                  <th>tipo Obj</th>                
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $apg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <td>FIEOBJ3D<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->tipoSW); ?></td>
                  <td><?php echo e($usd->Autorgraf3D); ?></td>
                  <td><?php echo e($usd->fechaCreacion); ?></td>
                  <td><?php echo e($usd->observacion); ?></td>
                  <td><?php echo e($usd->obj3D); ?></td>
                  <td><?php echo e($usd->tipoObj); ?></td>
                  <td>
                    <a href="<?php echo e(URL::action('pdfRepGraf3dDController@verObj',$usd->id)); ?>"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-edit"></i>Obj. 3D</button></a>
                    
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
              </table>
            </div>
            <?php echo e($apg->render()); ?>

          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>