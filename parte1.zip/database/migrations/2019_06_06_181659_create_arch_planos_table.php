<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateArchPlanosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void 
     */
    public function up()
    {
        Schema::create('arch_planos', function (Blueprint $table) {
            $table->increments('id');
            $table->string('TipoArchivo');
            $table->string('DesArchP');
            $table->string('DocArchP');
            $table->string('ImgArchP');
            $table->string('AutorArchP');
            $table->date('fechaGener');
            $table->string('objPlano');
            $table->string('observacion');
            $table->string('tipoObjP',1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('arch_planos');
    }
}
