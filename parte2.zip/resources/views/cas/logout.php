<?php

session_start();
session_destroy();
// header('Location: index.php');
route('/');

/* Decoded: (ejemplo para entender)
https://login.microsoftonline.com/common/oauth2/logout?post_logout_redirect_uri=https://seguridad.espoch.edu.ec/cas/logout?service=http://localhost/gestorMSA/cas/protected

Encoded:
https://login.microsoftonline.com/common/oauth2/logout?post_logout_redirect_uri=https%3A%2F%2Fseguridad.espoch.edu.ec%2Fcas%2Flogout%3Fservice%3Dhttps%3A%2F%2Felearning.espoch.edu.ec%2Findex.php
*/
?>
