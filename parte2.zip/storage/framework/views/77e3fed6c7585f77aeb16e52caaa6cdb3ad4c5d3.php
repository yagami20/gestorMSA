<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-foto-<?php echo e($usd->id); ?>">
<?php echo e(Form::Open(array('action'=>array('UsuariosController@destroy',$usd->id),'method'=>'delete'))); ?>

<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">X</span>
			
		</button>
		<h4 class="modal-title">Ver Perfil</h4>
	</div>
	<div class="modal-body">
		
		
				<!--  -->
				<div class="box-body box-profile">
                      <img class="profile-user-img img-responsive img-circle" src="<?php echo e(asset('imagenes/perfil/'.$usd->foto)); ?>" alt="User profile picture">
                      <h3 class="profile-username text-center"> <?php echo e($usd->name); ?></h3>
                      <p class="text-muted text-center"><?php echo e($usd->email); ?></p>
                      <p class="text-muted text-center"><?php echo e(auth::user()->direccion); ?></p>
                      <p class="text-muted text-center"><?php echo e(auth::user()->fechaNac); ?></p>
                      <p class="text-muted text-center"><?php echo e(auth::user()->ciudad); ?> - <?php echo e(auth::user()->pais); ?></p>
                                  <p class="text-muted text-center">Software Developer</p>
                  </div>
				<!--  -->
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
		
	</div>

	</div>
</div>
<?php echo e(Form::Close()); ?>	

</div>