 @extends('nav')

 @section('content')
<div class="row section-head">
         <div class="col full" align="justify">
            <p class="desc" align="justify" >             
              <h2> JUGUETES EDUCATIVOS - INVESTIGATIVOS</h2> 
                  <hr></br>             
                  <p>
                    Con la idea de promocionar el arte del modelismo y combinar con la educación superior se presenta el proyecto:  JUGUETES EDUCATIVOS - INVESTIGATIVOS, el mismo que ha sido fruto de varios años de trabajo e investigación. <br>

                    Al momento (Enero 2015) este proyecto se ha presentado al Concurso de Juguetes de Yachay, siendo revisado y seleccionado a una segunda ronda. <br>

                    Se propone presentar un set de juguetes en madera de pino. Otro set de locomotoras y vagones modernos de metal a escala y otro set con locomotoras construidas con latas de sodas y con una pista que simule las líneas de tren. Adicionalmente se mostraran aulas virtuales con Ambientes Virtuales de Aprendizaje Lúdico (AVAL). <br>

                    El usuario podrá tener un apoyo  adicional al ingresar al aula virtual “Modelismo Educativo” de la ESPOCH. Podrá compartir sus trabajos,realizar consultas en los foros y al final recibir un diploma otorgado por el Club de Modelismo Riobamba y la ESPOCH.
                  </p>             
<center>
  <div id="intro-slider" class="flexslider" >
      <ul class="slides"  >

         <!-- Slide -->
             <li>
               <div class="row">
                   <div class="col full">
                      <img src="images/proyecto tren/juguetes educativos/jE1.jpg" style=" width: 450px;height: 300px;">
                      <h5 style="color: darkcyan"> Kits de trenes de madera de pino para niños.</h5>
                   </div>
               </div>
             </li>
        <!-- Slide -->
             <li>
               <div class="row">
                   <div class="col full">
                      <img src="images/proyecto tren/juguetes educativos/jE2.jpg" style=" width: 335px;height: 250px;">
                      <h5 style="color: darkcyan"> Locomotora en madera y metal, ideal para colegios.</h5>
                   </div>
               </div>
             </li>
                <!-- Slide -->
             <li>
               <div class="row">
                   <div class="col full">
                      <img src="images/proyecto tren/juguetes educativos/jE3.jpg" >
                      <h5 style="color: darkcyan">Locomotora con material de reciclaje.</h5>
                   </div>
               </div>
             </li>
                <!-- Slide -->
             <li>
               <div class="row">
                   <div class="col full">
                      <img src="images/proyecto tren/juguetes educativos/jE4.jpg" style=" width: 335px;height: 250px;">
                      <h5 style="color: darkcyan"> Locomotora "Made in Ecuador".</h5>
                   </div>
               </div>
             </li>
           </ul>
         </div>
    <!-- Flexslider End-->
</center>
          <button class="regresar">
            <a style="color: white" href="{{asset('/#proyectos')}}">Volver a proyectos</a>
          </button> 
  </div>
</div>
  <!-- Flexslider Start-->
@endsection