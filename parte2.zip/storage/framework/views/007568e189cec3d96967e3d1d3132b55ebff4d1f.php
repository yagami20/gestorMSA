<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-foto-<?php echo e($apg->id='1'); ?>">
<?php echo e(Form::Open(array('action'=>array('AddProducController@destroy',$apg->id='1'),'method'=>'delete'))); ?>

<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">X</span>
			
		</button>
		<h4 class="modal-title">Agregar</h4>
	</div>
	<div class="modal-body">
		
		
				<!--  -->
				<div class="box-body box-profile">
                      
                      <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Seleccionar Producto</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr> 
                <td>
                  <select name="tipoProduct" class="form-control">
                    <option value="1">Aplicacion</option>
                    <option value="2">Archivo Plano</option>
                    <option value="3">Grafico 3D</option>
                    <option value="4">Kit STEAM</option>
                    <option value="5">Patente</option>
                    <option value="6">Tarjeta Pop-Up</option>
                  </select>
              	</td>
                <input type="hidden" name="idUser" value="<?php echo e(Auth::user()->id); ?>">
            	<td>

            		<button type="submit" class="btn btn-outline-success">Agregar <i class="fa fa-search"></i></button>
            	</td>
                </tr>           
              </table>
            </div>
                      
                  </div>
				<!--  -->
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
		
	</div>

	</div>
</div>
<?php echo e(Form::Close()); ?>	

</div>