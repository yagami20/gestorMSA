<?php
require_once ( __DIR__ . '/casconfig.php'); 

$host = $_SERVER['HTTP_HOST'];
$host_upper = strtoupper($host);
$path = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');

$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') ? 'https://' : 'http://';
$baseurl = $protocol . $host . $path . "/";
$urlencoded = urlencode($baseurl . "logout.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <title>php-cas-client-demo</title>
        <meta charset="UTF-8" />
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css" />
    </head>
    <body>
        <div class="container">
            <ul class="nav nav-tabs">
                <li class="active"><a href="index.php">You are on the /index.php page</a></li>
                <li><a href="protected/index.php">Call the /protected/index.php page</a></li>
                <!-- #### change with your own CAS server and your host name #### -->
                <?php
                if (phpCAS::isAuthenticated()) {
                    ?>
                    <li><a href="<?= $casprotocol . $casservername . $casbaseuri . $caslogouturl . $urlencoded; ?>">
                            Call the CAS logout</a></li>
                <?php } ?>
            </ul>
            <h3>
                <?php
                if (phpCAS::isAuthenticated()) {
                    ?>
                    <p>User: <?php echo phpCAS::getUser(); ?></p>             
                </h3>
                <?php
                $attributes = phpCAS::getAttributes();
                echo '<div class="table-responsive-sm">'
                . '<table class="table table-sm table-hover">'
                . '<caption>CAS Attributes</caption>'
                . '<thead>'
                . '<tr>'
                . '<th scope="col">Name</th>'
                . '<th scope="col">Value</th>'
                . '</tr>'
                . '</thead>'
                . '<tbody>';
                foreach ($attributes as $key => $value) {
                    echo '<tr>
                            <td>' . $key . '</td>
                            <td>' . $value . '</td>
                        </tr>';
                }
                echo '</tbody>
                      </table></div>';
                ?>
                <?php
            } else {
                ?>
                <h3><p>Unauthenticated / anonymous user</p></h3>
                <?php
            }
            ?>
        </div>
    </body>
</html>
