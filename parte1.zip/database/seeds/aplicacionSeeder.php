<?php

use Illuminate\Database\Seeder;
use gestorMSA\aplicacion;

class aplicacionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $app= new aplicacion();
        $app->tipoSW = "N/A";
        $app->DesApp="sin descripcion";
        $app->fechaReproduc = "2019-01-01";
        $app->fotoApp = "sin Observ";
        $app->examinar = "sin Observ";
        $app->save();
    }
}
