@extends('nav')
<script src="{{ asset('js/app.js') }}" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>

 {{--  --}}
  <link rel="stylesheet" href="{{asset('css/estilos.css')}}">
  <link rel="stylesheet" href="{{asset('css/bootstrap.css')}}">
  <link href="{{asset('lib/lightbox/css/lightbox.min.css')}}" rel="stylesheet">
  <link rel="stylesheet" href="{{asset('css/view/font-awesome/css/font-awesome.min.css')}}">
  <script src="{{asset('lib/jquery/jquery.min.js')}}"></script>
  <script src="{{asset('lib/jquery/jquery-migrate.min.js')}}"></script>
  <script src="{{asset('lib/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('lib/easing/easing.min.js')}}"></script>
  <script src="{{asset('lib/superfish/hoverIntent.js')}}"></script>
  <script src="{{asset('lib/superfish/superfish.min.js')}}"></script>
  <script src="{{asset('lib/wow/wow.min.js')}}"></script>
  <script src="{{asset('lib/waypoints/waypoints.min.js')}}"></script>
  <script src="{{asset('lib/counterup/counterup.min.js')}}"></script>
  <script src="{{asset('lib/owlcarousel/owl.carousel.min.js')}}"></script>
  <script src="{{asset('lib/isotope/isotope.pkgd.min.js')}}"></script>
  <script src="{{asset('lib/lightbox/js/lightbox.min.js')}}"></script>
  <script src="{{asset('lib/touchSwipe/jquery.touchSwipe.min.js')}}"></script>
 {{--  --}} 
@section('content')
{{-- <div class="row section-head">
         <div class="col full" align="justify"> --}}
            <p class="desc" align="justify" >             
              <center><h2> Notificaciones: Facultad de Informática y Electrónica </h2></center>
              <!--==========================
      			Portfolio Section
    			============================-->
              {{-- inicio notificacion --}}
{{-- <div class="col-lg-9 mb-4"> --}}
	<section id="portfolio"   >
      	{{-- <div class="container">  --}}
      		<div class="row portfolio-container">
      			@forelse($sliders as $slider )
      			<div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
      				<div class="portfolio-wrap">
      					<figure>
			                <img class="d-block img-fluid" src="{{asset('/imagenes/notifImg/'.$slider->foto)}}"  alt="">
			                <a href="{{asset('/imagenes/notifImg/'.$slider->foto)}}" data-lightbox="portfolio" data-title="App 1" class="link-preview" title="Preview"><i class="fa fa-5x fa-eye"></i></a>
			                <a href="{{URL::action('noticiasController@edit',$slider->id)}}" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
              			</figure>
              			<div class="portfolio-info">
			            	<h6 align="left"><a>{{substr($slider->descripcion,0,50).'...'}}</a></h6>
			            </div>
            		</div>
            	</div>
            	@empty
            	@endforelse
            </div>
        {{-- </div> --}}
    </section><!-- #portfolio -->
{{-- </div> --}}
        {{-- Fin notificacion --}}
            
                          
            
          
          
{{--   </div>
</div> --}}
@endsection
