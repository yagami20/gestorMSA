<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;

use App\aplicacion;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use App\Http\Requests\AplicacionFormRequest;
use App\Http\Requests\UserUpdateFormRequest;
use phpCAS;

use DB; 
//

class AplicacionesUController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        $request->user()->authorizeRoles(['user']);
        if ($request)
        {
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $apg=DB::table('aplicacions as tbU')
            ->select('tbU.id','tbU.tipoSW','tbU.DesApp','tbU.AutorApp','tbU.fechaReproduc','tbU.examinar', 'tbU.fotoApp')
            ->where('tbU.tipoSW','LIKE','%'.$query.'%')
            ->orwhere('tbU.fechaReproduc','LIKE','%'.$query.'%')
            ->orderBy('tbU.id','desc')
            ->paginate(7);
            return view('GestorUsuario.Aplicaciones.index',["apg"=>$apg,"searchText"=>$query]);

        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        return view("GestorUsuario.Aplicaciones.show");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($examinar)
    {
        //
        // if(!$this->downloadFile(public_path().'/documentos/aplicaciones/',$examinar)){
        //     return redirect()->back();
        $pathtoFile = public_path().'/documentos/aplicaciones/'.$examinar;
        return response()->download($pathtoFile);
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
    *Codigo para descargar archivos del proyecto
    */
    protected function downloadFile($src){
        if(is_file($src)){
            $finfo=finfo_open(FILEINFO_MIME_TYPE);
            $content_type=finfo_file($finfo, $src);
            finfo_close($finfo);
            $file_name=basename($src).PHP_EOL;
            $size=filesize($src);
            header("Content-Type: $content_type");
            header("Content-Disposition: attachment; filename=$file_name");
            header("Content-Transfer-Encoding: binary");
            header("Content-Length: $size");
            readfile($src);
            return true;
        }
        else{
            return false;
        }
    }

    /**
    *function download
    */
    public function Download($examinar)
    {
        //
        // if(!$this->downloadFile(public_path().'/documentos/aplicaciones/',$examinar)){
        //     return redirect()->back();
        $pathtoFile = public_path().'/documentos/aplicaciones/'.$examinar;
        return response()->download($pathtoFile);
        
    }
    
}
