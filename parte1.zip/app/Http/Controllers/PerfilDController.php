<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;


use App\Http\Requests\UserFormRequest;
use App\Http\Requests\UserUpdateFormRequest;

use App\Http\Requests\PerfilFormRequest;
// use App\jasig\phpcas\source\CAS;
use phpCAS;

use DB; 
//

class PerfilDController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        //
        // $request->user()->authorizeRoles(['docent','user']);
        $usuario=User::findOrFail($id);
        if($request->user()->authorizeRoles('docent')){
        return view("GestorDocente.Perfil.edit",["usuario"=>$usuario]);    
        }
        if($request->user()->authorizeRoles('user')){
            return view("GestorUsuario.Perfil.edit",["usuario"=>$usuario]);
        }
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PerfilFormRequest $request, $id)
    {

        $usuario=User::findOrFail($id);

        $usuario->name=$request->get('name');

        $usuario->password=bcrypt($request->get('password'));

        $usuario->cedula=$request->get('cedula');

        $usuario->direccion=$request->get('direccion');
        
        $usuario->genero=$request->get('genero'); 

        $usuario->fechaNac=$request->get('fechaNac');

        if (Input::hasFile('foto')){
         $file=Input::file('foto');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/imagenes/perfil/',$nameF);
         $usuario->foto=$nameF;
        }

        $usuario->pais=$request->get('pais');

        $usuario->ciudad=$request->get('ciudad');

        $usuario->estado=$request->get('estado');

        $usuario->save();

        if($request->user()->authorizeRoles(['docent'])){
            return Redirect::to('GestorDocente/index');
        }
        if($request->user()->authorizeRoles('user')){
            return Redirect::to('GestorUsuario/index');
        }

        
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
