<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\User;
use App\RoleUserR;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;


use App\Http\Requests\UserFormRequest;
use App\Http\Requests\UserUpdateFormRequest;
// use App\jasig\phpcas\source\CAS;
use phpCAS;

use DB; 
// 

class UsuariosController extends Controller
{
    
    public function __construct()
    {
        // $this->configCas();
        
        // if(phpCAS::forceAuthentication())
        // {
        //     echo "cas";
        // }
        // echo "nocas";
        $this->middleware('auth');

    }


    public function index (Request $request)
    {

    	$request->user()->authorizeRoles('admin');
        if ($request)
    	{
    	
			$query=trim($request->get('searchText')); //determinr texto de busqueda

    		
            $usuario=DB::table('users as tbU')
            ->select('tbU.id','tbU.name','tbU.email','tbU.password','tbU.foto','tbU.cedula','tbU.direccion','tbU.genero','tbU.fechaNac','tbU.pais','tbU.ciudad','tbU.estado')
            
            ->where('tbU.name','LIKE','%'.$query.'%')
            ->orwhere('tbU.email','LIKE','%'.$query.'%')
            ->orwhere('tbU.genero','LIKE','%'.$query.'%')
            ->orwhere('tbU.cedula','LIKE','%'.$query.'%')

    		
            ->orderBy('tbU.id','desc')

    		->paginate(7);

    		return view ('GestorMSA.Usuarios.index',["usuario"=>$usuario,"searchText"=>$query]);
            
    	}
    }


    
public function create(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        return view ("GestorMSA.Usuarios.create");
    }

    
public function store (UserFormRequest $request)
    {

    	$role_user = Role::where('name','user')->first();
        $role_admin = Role::where('name','admin')->first();
        $role_docent = Role::where('name','docent')->first();
        //
        $usuario=new User;

        $usuario->name=$request->get('name');

        $usuario->email=$request->get('email');

    	$usuario->password=bcrypt($request->get('password'));

    	$usuario->cedula=$request->get('cedula');

        $usuario->direccion=$request->get('direccion');
        
        $usuario->genero=$request->get('genero');

    	$usuario->fechaNac=$request->get('fechaNac');

        if (Input::hasFile('foto')){
         $file=Input::file('foto');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/imagenes/perfil/',$nameF);
         $usuario->foto=$nameF;
        }

    	$usuario->pais=$request->get('pais');

    	$usuario->ciudad=$request->get('ciudad');

    	$usuario->estado=$request->get('estado');

    	$usuario->save();
        if($request->get('TI')=='1'){
            $usuario->roles()->attach($role_admin);
        }
        else{
            if($request->get('TI')=='2'){
                $usuario->roles()->attach($role_docent);
            }
            else{
                $usuario->roles()->attach($role_user);
            }
        }

    	return Redirect::to('GestorMSA/Usuarios');


    }


    
// public function show ($id)
//     {

//     	return view("GestorMSA.Usuarios.show",["usuario"=>User::findOrFail($id)]);

//     }
//
    public function show (User $usuario)
    {

        return view("GestorMSA.Usuarios.show",compact('usuario'));

    }
//
    
public function edit(Request $request,$id)
    {

        $request->user()->authorizeRoles(['admin','user']);
        $usuario=User::findOrFail($id);
        return view("GestorMSA.Usuarios.edit",["usuario"=>$usuario]);
        
    }

    
public function update(UserUpdateFormRequest $request, $id)
    {
        $role_user = Role::where('name','user')->first();
        $role_admin = Role::where('name','admin')->first();
        $role_docent = Role::where('name','docent')->first();

    	$usuario=User::findOrFail($id);

    	$usuario->name=$request->get('name');

        $usuario->password=bcrypt($request->get('password'));

        $usuario->cedula=$request->get('cedula');

        $usuario->direccion=$request->get('direccion');
        
        $usuario->genero=$request->get('genero');

        $usuario->fechaNac=$request->get('fechaNac');

        if (Input::hasFile('foto')){
         $file=Input::file('foto');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/imagenes/perfil/',$nameF);
         $usuario->foto=$nameF;
        }

        $usuario->pais=$request->get('pais');

        $usuario->ciudad=$request->get('ciudad');

        $usuario->estado=$request->get('estado');

        $usuario->save();


        $roleV=DB::table('role_user as tbT')
        ->select('tbT.id','tbT.user_id','tbT.role_id')
                ->where('tbT.user_id',$id)
                ->get();
        
        //dd($roleU);
        $si='s'; $n='n';
        if(isset($roleV[0])){
            //dd($si);
            $idR=$roleV[0]->id;
            $roleU=RoleUserR::findOrFail($idR);
            //
            if($request->get('TI')=='1'){
            $roleU->role_id='1';
            $roleU->save();
        }
        else{
            if($request->get('TI')=='2'){
                $roleU->role_id='2';
                $roleU->save(); 
            }
            else{
                $roleU->role_id='3';
                $roleU->save();
            }
        }
            //
        }
        else{
            //dd($n);
            //
                    //
        if($request->get('TI')=='1'){
                $DesT=new RoleUserR;
            $DesT->user_id=$id;
            $DesT->role_id='1';
            $DesT->save();

        }
        else{
            if($request->get('TI')=='2'){
                $DesT=new RoleUserR;
            $DesT->user_id=$id;
            $DesT->role_id='2';
            $DesT->save();
            }
            else{
                $DesT=new RoleUserR;
            $DesT->user_id=$id;
            $DesT->role_id='3';
            $DesT->save();
            }
        }
            //
        }

    	return Redirect::to('GestorMSA/Usuarios');
    	
    }

    

public function destroy($id)
    {

    	$usuario=User::findOrFail($id);

    	$usuario->estado='0';

    	$usuario->update();

    	return Redirect::to('GestorMSA/Usuarios'); 


    }
}
