<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateContenidoKitsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contenido_kits', function (Blueprint $table) {
            $table->increments('id');
            $table->string('piezaArmar');
            $table->string('instrucciones');
            $table->string('tutoDigital');
            $table->string('enlaceWeb');
            $table->string('tipoMateria');
            $table->integer('idCaja')->unsigned();
            $table->foreign('idCaja')->references('id')->on('cajas');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contenido_kits');
    }
}
