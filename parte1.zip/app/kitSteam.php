<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kitSteam extends Model
{
    //
    protected $table='kit_steams';

    protected $primaryKey='id';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'aplicabilidad',

        'AutorKit',  

        'planos', 
    	
        'email', 

        'fechaKit',

        'portadakit',
    	
        'idContenido'
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ];
}
