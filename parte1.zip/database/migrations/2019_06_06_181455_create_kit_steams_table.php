<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateKitSteamsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('kit_steams', function (Blueprint $table) {
            $table->increments('id');
            $table->string('aplicabilidad');
            $table->string('AutorKit');//  
            $table->string('planos');
            $table->string('email');
            $table->date('fechaKit');
            $table->string('portadakit');//foto portada
            $table->integer('idContenido')->unsigned();
            $table->foreign('idContenido')->references('id')->on('contenido_kits');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('kit_steams');
    }
}
