<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;

use App\grafico3d;
use App\producto;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Collection;

use App\Http\Requests\graficos3dFormRequest;
use phpCAS;
use ZipArchive;

use DB;
//

class graficosDController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth'); 
    }

    public function index(Request $request)
    {
        $request->user()->authorizeRoles('docent');
        $idR=1;
        if ($request)
        {
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $graf3d=DB::table('grafico3ds as tbU')
            ->join('productos as tbP','tbU.id','=','tbP.idGraf3D')
            ->select('tbU.id','tbU.fechaCreacion','tbU.Docgraf3D','tbU.obj3D','tbU.Autorgraf3D','tbU.observacion', 'tbU.tipoSW','tbU.tipoObj','tbU.Desgraf3D','tbP.idUser','tbP.id as idProd')
            ->where('tbU.id','!=',$idR)
            ->where('tbP.idGraf3D','<>',$idR)
            ->where('tbU.tipoSW','LIKE','%'.$query.'%')
            ->where('tbU.Autorgraf3D','LIKE','%'.$query.'%')
            ->where('tbU.obj3D','LIKE','%'.$query.'%')
            ->where('tbU.observacion','LIKE','%'.$query.'%')
            ->orwhere('tbU.fechaCreacion','LIKE','%'.$query.'%')
            ->orderBy('tbU.id','desc')
            ->paginate(7);
            return view('GestorDocente.Graficos3D.index',["graf3d"=>$graf3d,"searchText"=>$query]);

        }
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $request->user()->authorizeRoles('docent');
        return view ("GestorDocente.Graficos3D.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store (graficos3dFormRequest $request)
    {
        $graf3d=new grafico3d;

        $graf3d->tipoSW=$request->get('tipoSW');

        $graf3d->Desgraf3D=$request->get('Desgraf3D');

        $graf3d->Autorgraf3D=$request->get('Autorgraf3D');

        $graf3d->fechaCreacion=$request->get('fechaCreacion');
        
        if (Input::hasFile('obj3D')){
         $file1=Input::file('obj3D');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/documentos/arch3D/',$nameF1);
         $graf3d->obj3D=$nameF1;
        }

        if (Input::hasFile('Docgraf3D')){
         $file2=Input::file('Docgraf3D');
         $nameF2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/arch3D/documentos/',$nameF2);
         $graf3d->Docgraf3D=$nameF2;
        }

        $graf3d->observacion=$request->get('observacion');

        $graf3d->tipoObj=$request->get('tipoObj');

        $graf3d->save();

        $this->descomprimir($graf3d->obj3D,$graf3d->id);
        $this->addProduct($graf3d->id,$request);
        return Redirect::to('GestorDocente/Graficos3D');
    }

    public function addProduct ($idGraf3D,$request)
    {
        $fecha= new producto;//llamar
        $fecha->nombreP=$request->get('tipoSW');
        $fecha->idGraf3D=$idGraf3D;
        $fecha->idarchPlano=$request->get('idarchPlano');
        $fecha->idApp=$request->get('idApp');
        $fecha->idKit=$request->get('idKit');
        $fecha->idUser=$request->get('idUser');
        $fecha->idTarj=$request->get('idTarj');
        $fecha->idPatent=$request->get('idPatent');
        $fecha->idAutor=$request->get('idAutor');

        $fecha->save();
        return Redirect::to('GestorDocente/Graficos3D');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show ($id)
    {
        return view("GestorDocente.Graficos3D.show");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        //
        $request->user()->authorizeRoles(['docent']);
        $prod=producto::findOrFail($id);
        $graf3d=grafico3d::findOrFail($prod->idGraf3D);
        return view("GestorDocente.Graficos3D.edit",["prod"=>$prod,"graf3d"=>$graf3d]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(graficos3dFormRequest $request, $id)
    {
        $graf3d=grafico3d::findOrFail($id);

        $graf3d->tipoSW=$request->get('tipoSW');

        $graf3d->Desgraf3D=$request->get('Desgraf3D');

        $graf3d->Autorgraf3D=$request->get('Autorgraf3D');

        $graf3d->fechaCreacion=$request->get('fechaCreacion');
        
        if (Input::hasFile('obj3D')){
         $file1=Input::file('obj3D');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/documentos/arch3D/',$nameF1);
         $graf3d->obj3D=$nameF1;
        }

        if (Input::hasFile('Docgraf3D')){
         $file2=Input::file('Docgraf3D');
         $nameF2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/arch3D/documentos/',$nameF2);
         $graf3d->Docgraf3D=$nameF2;
        }

        $graf3d->observacion=$request->get('observacion');

        $graf3d->tipoObj=$request->get('tipoObj');

        $graf3d->save();

        // $this->descomprimir($graf3d->obj3D);
        $this->descomprimir($graf3d->obj3D,$graf3d->id);
        $this->modProduct($graf3d->id,$request);
        // dd($apg);
        return Redirect::to('GestorDocente/Graficos3D');
    }

    public function modProduct ($idPatent,$request)
    {
        $fecha= producto::findOrFail($request->get('idProducto'));
        $fecha->nombreP=$request->get('tipoSW');

        $fecha->save();
        return Redirect::to('GestorDocente/Graficos3D');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $apg2=producto::findOrFail($request->get('idProd'));
        $idGraf3D=$apg2->idGraf3D;
        $apg2->delete();
        
        $apg=grafico3d::findOrFail($idGraf3D);
        $apg->delete();
        return Redirect::to('GestorDocente/Graficos3D');
    }

    public function download($obj3D)
    {
        $pathtoFile = public_path().'/documentos/arch3D/extract/'.$obj3D;
            return response()->download($pathtoFile);
    }

    public function verObj(Request $request,$id)
    {
        $request->user()->authorizeRoles(['docent']);
        $graf3d=grafico3d::findOrFail($id);
        if ($graf3d->tipoObj=='1')
        {
            return view('GestorDocente.Graficos3D.vistaJson',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='2')
        {
            return view('GestorDocente.Graficos3D.vistaObj',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='4')
        {
            return view('GestorDocente.Graficos3D.vistaStl',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='5')
        {
            return view('GestorDocente.Graficos3D.vistaDae',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='6')
        {
            return view('GestorDocente.Graficos3D.vistaPly',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='7')
        {
            return view('GestorDocente.Graficos3D.vistaGltf',["graf3d"=>$graf3d]);
        }
        // return view("GestorDocente.Graficos3D.edit",["graf3d"=>$graf3d]);
        
    } 

    public function descomprimir($obj3D,$id){
        $zip = new ZipArchive(); $i=0;
        /* */
        $graf3d=grafico3d::findOrFail($id);

        
        /* */
        $zip->open('documentos/arch3D/'.$obj3D, ZipArchive::CREATE);
        $zip->extractTo('documentos/arch3D/extract');
        $graf3d->obj3D=$zip->getNameIndex($i);//
        $zip->close();
        $graf3d->save();
    }
}
