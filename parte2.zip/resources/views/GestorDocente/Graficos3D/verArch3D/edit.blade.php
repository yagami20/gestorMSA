@extends('layouts.admin')
<script src="{{ asset('js/app.js') }}" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>
@section('content')
<a href="{{URL::action('GraficosController@download',$graf3d->obj3D)}}"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Descargar</button></a>
<a href="{{asset('GestorMSA/Graficos3D')}}"><button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">atras X</span>
			
		</button></a>
<!-- <archvista-component></archvista-component> -->
<div id="app">
    <model-obj src="arch3d/ejemplo/tree.obj"></model-obj>
    
  </div>
<script>
  new Vue({ el: '#app' });
</script>

@endsection
