<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="<?php echo e(asset('GestorMSA/Almacen')); ?>">Almacen</a>/
                <a href="<?php echo e(asset('GestorMSA/archPlanos')); ?>">Archivos Planos</a>/Crear
            </h5>
			<h3>Nuevo Archivo Plano</h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>
			<?php echo Form::open(array('url'=>'GestorMSA/archPlanos','method'=>'POST','autocomplete'=>'off','files'=>'true')); ?>

			<?php echo e(Form::token()); ?> 

		<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>"> -->
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="TipoArchivo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre de Archivo')); ?></label>

                            <div class="col-md-6">
                                <input id="TipoArchivo" type="text" placeholder="Ilustrator" class="form-control<?php echo e($errors->has('TipoArchivo') ? ' is-invalid' : ''); ?>" name="TipoArchivo" value="<?php echo e(old('TipoArchivo')); ?>" required autofocus>

                                <?php if($errors->has('TipoArchivo')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('TipoArchivo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="DesArchP" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Descripción de Archivo')); ?></label>

                            <div class="col-md-6">
                                <input id="DesArchP" type="text" placeholder="Perteneciente a..." class="form-control<?php echo e($errors->has('DesArchP') ? ' is-invalid' : ''); ?>" name="DesArchP" value="<?php echo e(old('DesArchP')); ?>" required autofocus>

                                <?php if($errors->has('DesArchP')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('DesArchP')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="AutorArchP" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Autor/es de Archivo')); ?></label>

                            <div class="col-md-6">
                                <input id="AutorArchP" type="text" placeholder="Perteneciente a..." class="form-control<?php echo e($errors->has('AutorArchP') ? ' is-invalid' : ''); ?>" name="AutorArchP" value="<?php echo e(old('AutorArchP')); ?>" required autofocus>

                                <?php if($errors->has('AutorArchP')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('AutorArchP')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaGener" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha Generación')); ?></label>

                            <div class="col-md-6">
                                <input id="fechaGener" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control<?php echo e($errors->has('fechaGener') ? ' is-invalid' : ''); ?>" name="fechaGener" value="<?php echo e(old('fechaGener')); ?>" required autofocus>

                                <?php if($errors->has('fechaGener')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fechaGener')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        <div class="form-group row">
                            <label for="objPlano" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Agregar Objeto')); ?></label>

                            <div class="col-md-6">
                                <input id="objPlano" type="file" name="objPlano" value="<?php echo e(old('objPlano')); ?>" required autofocus>

                                <?php if($errors->has('objPlano')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('objPlano')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="DocArchP" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Agregar Documento')); ?></label>

                            <div class="col-md-6">
                                <input id="DocArchP" type="file" name="DocArchP" value="<?php echo e(old('DocArchP')); ?>" required autofocus>

                                <?php if($errors->has('DocArchP')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('DocArchP')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="ImgArchP" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Agregar Imagen Mapa')); ?></label>

                            <div class="col-md-6">
                                <input id="ImgArchP" type="file" name="ImgArchP" value="<?php echo e(old('ImgArchP')); ?>" required autofocus>

                                <?php if($errors->has('ImgArchP')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('ImgArchP')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="observacion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Observacion de archivo')); ?></label>

                            <div class="col-md-6">
                                <input id="observacion" type="text" placeholder="abrir con Ilust..." class="form-control<?php echo e($errors->has('observacion') ? ' is-invalid' : ''); ?>" name="observacion" value="<?php echo e(old('observacion')); ?>" required autofocus>

                                <?php if($errors->has('observacion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('observacion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="tipoObjP" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipo de objeto')); ?></label>

                            <div class="col-md-6">
                                <!-- <div class="col-sm-4"> -->
                                              <select name="tipoObjP" class="form-control">
                                                <option value="1">Mapa General</option>
                                                <option value="2" >Mapa Individual</option>
                                            </select>
                                            <!-- </div> -->

                                <?php if($errors->has('tipoObjP')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('tipoObjP')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--fin ndatos  -->
                        <!--new datos  -->
                        <!--estado  -->
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
			
			


			<?php echo Form::close(); ?>


		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>