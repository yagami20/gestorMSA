@extends ('layouts.docente')
@section ('content')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="{{asset('GestorDocente/Almacen')}}">Almacen</a>/
                <a href="{{asset('GestorDocente/Graficos3D')}}">Graficos 3D</a>/Editar
            </h5>
			<h3>Editar datos grafico 3D: {{$graf3d->tipoSW}}</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

	
			


<form method="POST" action="/GestorDocente/Graficos3D/{{$graf3d->id}}" enctype="multipart/form-data">
    @method('PUT')  
    @csrf
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    
                       

                        <div class="form-group row">
                            <label for="tipoSW" class="col-md-4 col-form-label text-md-right">{{ __('Tipo de Software de Creación') }}</label>

                            <div class="col-md-6">
                                <input id="tipoSW" type="text" title="Nombre que se le da al objeto 3D" placeholder="Nombre Apellido" class="form-control{{ $errors->has('tipoSW') ? ' is-invalid' : '' }}" name="tipoSW" value="{{$graf3d->tipoSW}}" required autofocus>

                                @if ($errors->has('tipoSW'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('tipoSW') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="Autorgraf3D" class="col-md-4 col-form-label text-md-right">{{ __('Autor/es') }}</label>

                            <div class="col-md-6">
                                <input id="Autorgraf3D" type="text" title="Autor o autores que coperaron en la creación" placeholder="Nombre Apellido" class="form-control{{ $errors->has('Autorgraf3D') ? ' is-invalid' : '' }}" name="Autorgraf3D" value="{{$graf3d->Autorgraf3D}}" required autofocus>

                                @if ($errors->has('Autorgraf3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('Autorgraf3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="Desgraf3D" class="col-md-4 col-form-label text-md-right">{{ __('Descripción del S.W.') }}</label>

                            <div class="col-md-6">
                                <input id="Desgraf3D" type="text" title="Breve descripcion del objeto 3D" placeholder="Descripción" class="form-control{{ $errors->has('Desgraf3D') ? ' is-invalid' : '' }}" name="Desgraf3D" value="{{$graf3d->Desgraf3D}}" required autofocus>

                                @if ($errors->has('Desgraf3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('Desgraf3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaCreacion" class="col-md-4 col-form-label text-md-right">{{ __('Fecha Modificación') }}</label>

                            <div class="col-md-6">
                                <input id="fechaCreacion" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('fechaCreacion') ? ' is-invalid' : '' }}" name="fechaCreacion" value="{{$graf3d->fechaCreacion}}" required autofocus>

                                @if ($errors->has('fechaCreacion'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fechaCreacion') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="obj3D" class="col-md-4 col-form-label text-md-right">{{ __('Agregar Objeto (extensión: dae,gltf,json,obj,ply,stl y comprimido en zip):') }}</label>

                            <div class="col-md-6">
                                <input id="obj3D" type="file" title="Objeto comprimido en formato zip con todos los archivos que se generaron" name="obj3D" value="{{ old('obj3D') }}" required autofocus>

                                @if ($errors->has('obj3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('obj3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="Docgraf3D" class="col-md-4 col-form-label text-md-right">{{ __('Agregar Documento Objeto (extensión: pdf)') }}</label>

                            <div class="col-md-6">
                                <input id="Docgraf3D" type="file" title="Documento pdf del objeto 3D" name="Docgraf3D" value="{{ old('Docgraf3D') }}" required autofocus>

                                @if ($errors->has('Docgraf3D'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('Docgraf3D') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->                        
                        <div class="form-group row">
                            <label for="observacion" class="col-md-4 col-form-label text-md-right">{{ __('Observación de archivo') }}</label>

                            <div class="col-md-6">
                                <input id="observacion" type="text" placeholder="Nombre Apellido" class="form-control{{ $errors->has('observacion') ? ' is-invalid' : '' }}" name="observacion" value="{{$graf3d->observacion}}" required autofocus>

                                @if ($errors->has('observacion'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('observacion') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="tipoObj" class="col-md-4 col-form-label text-md-right">{{ __('Tipo de objeto') }}</label>

                            <div class="col-md-6">
                                <!-- <div class="col-sm-4"> -->
                        <select name="tipoObj" class="form-control">
                        @if($graf3d->tipoObj=='1')
                        <option value="{{$graf3d->tipoObj}}" selected>Objeto Json</option>
                        @endif
                        @if($graf3d->tipoObj=='2') 
                        <option value="{{$graf3d->tipoObj}}" selected>Objeto Obj</option>
                        @endif
                        @if($graf3d->tipoObj=='4')
                        <option value="{{$graf3d->tipoObj}}" selected>Objeto Stl</option>
                        @endif
                        @if($graf3d->tipoObj=='5')
                        <option value="{{$graf3d->tipoObj}}" selected>Objeto Dae</option>
                        @endif
                        @if($graf3d->tipoObj=='6')
                        <option value="{{$graf3d->tipoObj}}" selected>Objeto Ply</option>
                        @endif
                        @if($graf3d->tipoObj=='7')
                        <option value="{{$graf3d->tipoObj}}" selected>Objeto Gltf</option>
                        @else
                                                <option value="1">Objeto Json</option>
                                                <option value="2">Objeto Obj</option>
                                                <option value="4">Objeto Stl</option>
                                                <option value="5">Objeto Dae</option>
                                                <option value="6">Objeto Ply</option>
                                                <option value="7">Objeto Gltf</option>
                        @endif                                                
                        </select>
                                            <!-- </div> -->

                                @if ($errors->has('tipoObj'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('tipoObj') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        

                        <!--fin ndatos  -->
                        <input type="hidden" name="idProducto" value="{{$prod->id}}">
                         
                        <!--estado  -->
                        <!--new datos  -->
                        <!--estado  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    {{ __('Enviar') }}
                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
@endsection