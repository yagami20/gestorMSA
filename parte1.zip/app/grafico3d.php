<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class grafico3d extends Model
{
    //
    protected $table='grafico3ds';

    protected $primaryKey='id';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'fechaCreacion',
        
        'Desgraf3D',
        'Docgraf3D',
        'Autorgraf3D',

        'obj3D',
    	
        'observacion', 
    	
        'tipoSW',
        
        'tipoObj'
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ];
}
