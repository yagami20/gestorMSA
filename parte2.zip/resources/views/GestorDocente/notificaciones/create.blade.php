@extends ('layouts.docente')
@section ('content')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Nueva Notificación:</h3><br>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>
			{!!Form::open(array('url'=>'GestorDocente/notificaciones','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			{{Form::token()}} 

		<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="{{ route('register') }}" aria-label="{{ __('Register') }}"> -->
                        @csrf

                        <div class="form-group row">
                            <label for="titulo" class="col-md-4 col-form-label text-md-right">{{ __('Titulo') }}</label>

                            <div class="col-md-6">
                                <input id="titulo" type="text" title="Titulo que aparece en la notificación" placeholder="Simulador #..." class="form-control{{ $errors->has('titulo') ? ' is-invalid' : '' }}" name="titulo" value="{{ old('titulo') }}" required autofocus>

                                @if ($errors->has('titulo'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('titulo') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="descripcion" class="col-md-4 col-form-label text-md-right">{{ __('Descripción:') }}</label>

                            <div class="col-md-6">
                                <input id="descripcion" type="text" title="Breve reseña de lo que involucra la notificación" placeholder="Descripción #..." class="form-control{{ $errors->has('descripcion') ? ' is-invalid' : '' }}" name="descripcion" value="{{ old('descripcion') }}" required autofocus>

                                @if ($errors->has('descripcion'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('descripcion') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaNotf" class="col-md-4 col-form-label text-md-right">{{ __('Fecha creación S.W.') }}</label>

                            <div class="col-md-6">
                                <input id="fechaNotf" type="date" title="Fecha de registro de la notificación" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('fechaNotf') ? ' is-invalid' : '' }}" name="fechaNotf" value="{{ old('fechaNotf') }}" required autofocus>

                                @if ($errors->has('fechaNotf'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fechaNotf') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="foto" class="col-md-4 col-form-label text-md-right">{{ __('Cargar Foto:') }}</label>

                            <div class="col-md-6">
                                <input id="foto" type="file" title="Formato imagen: jpeg,bmp,jpg,png" name="foto" value="{{ old('foto') }}" required autofocus>

                                @if ($errors->has('foto'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('foto') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        
                        <div class="form-group row">
                            <label for="docNotif" class="col-md-4 col-form-label text-md-right">{{ __('Importar Documento:') }}</label>

                            <div class="col-md-6">
                                <input id="docNotif" type="file" title="Formato documento tipo pdf" name="docNotif" value="{{ old('docNotif') }}" required autofocus>

                                @if ($errors->has('docNotif'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('docNotif') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        
                        

                        <!--fin ndatos  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    {{ __('Ingresar') }}
                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
			
			


			{!!Form::close()!!}

		
@endsection