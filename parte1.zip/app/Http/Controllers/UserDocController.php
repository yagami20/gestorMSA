<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;


use App\Http\Requests\UserFormRequest;
use App\Http\Requests\UserUpdateFormRequest;

use DB;
//

class UserDocController extends Controller
{
    
    /*
    * Autentificacion
    */

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        $request->user()->authorizeRoles('docent');
        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda

            
            $usuario=DB::table('users as tbU')
            ->select('tbU.id','tbU.name','tbU.email','tbU.password','tbU.foto','tbU.cedula','tbU.direccion','tbU.genero','tbU.fechaNac','tbU.pais','tbU.ciudad','tbU.estado')
            
            ->where('tbU.name','LIKE','%'.$query.'%')
            ->orwhere('tbU.email','LIKE','%'.$query.'%')
            ->orwhere('tbU.genero','LIKE','%'.$query.'%')
            ->orwhere('tbU.cedula','LIKE','%'.$query.'%')
            ->where ('tbU.estado','=','0') 

            
            ->orderBy('tbU.id','desc')

            ->paginate(7);

            return view ('GestorDocente.UsuariosD.index',["usuario"=>$usuario,"searchText"=>$query]);
            
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $request->user()->authorizeRoles('docent');
        return view ("GestorDocente.UsuariosD.create");
    }

    
public function store (UserFormRequest $request)
    {

        $role_user = Role::where('name','user')->first();
        $role_docent = Role::where('name','docent')->first();
        //
        $usuario=new User;

        $usuario->name=$request->get('name');

        $usuario->email=$request->get('email');

        $usuario->password=bcrypt($request->get('password'));

        $usuario->cedula=$request->get('cedula');

        $usuario->direccion=$request->get('direccion');
        
        $usuario->genero=$request->get('genero');

        $usuario->fechaNac=$request->get('fechaNac');

        if (Input::hasFile('foto')){
         $file=Input::file('foto');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/imagenes/perfil/',$nameF);
         $usuario->foto=$nameF;
        }

        $usuario->pais=$request->get('pais');

        $usuario->ciudad=$request->get('ciudad');

        $usuario->estado=$request->get('estado');

        $usuario->save();
        
            if($request->get('TI')=='2'){
                $usuario->roles()->attach($role_docent);
            }
            else{
                $usuario->roles()->attach($role_user);
            }
        

        return Redirect::to('GestorDocente/UsuariosD');


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {

        $request->user()->authorizeRoles(['docent']);
        $usuario=User::findOrFail($id);
        return view("GestorDocente.UsuariosD.edit",["usuario"=>$usuario]);
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $role_user = Role::where('name','user')->first();
        $role_docent = Role::where('name','docent')->first();

        $usuario=User::findOrFail($id);

        // $usuario->name=$request->get('name');

        // $usuario->password=bcrypt($request->get('password'));

        // $usuario->cedula=$request->get('cedula');

        // $usuario->direccion=$request->get('direccion');
        
        // $usuario->genero=$request->get('genero');

        // $usuario->fechaNac=$request->get('fechaNac');

        // if (Input::hasFile('foto')){
        //  $file=Input::file('foto');
        //  $nameF=time().$file->getClientOriginalName();
        //  $file->move(public_path().'/imagenes/perfil/',$nameF);
        //  $usuario->foto=$nameF;
        // }

        // $usuario->pais=$request->get('pais');

        // $usuario->ciudad=$request->get('ciudad');

        $usuario->estado=$request->get('estado');

        $usuario->save();
        if($request->get('TI')=='2'){
                $usuario->roles()->attach($role_docent);
            }
            else{
                $usuario->roles()->attach($role_user);
            }
        

        return Redirect::to('GestorDocente/UsuariosD');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
