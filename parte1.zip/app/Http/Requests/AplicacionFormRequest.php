<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AplicacionFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'tipoSW' => 'required|string|max:255',
            'AutorApp' => 'required|string|max:255',
            'fechaReproduc'=>'required|max:10',
            'fotoApp'=>'mimes:jpeg,bmp,jpg,png',
            'examinar'=>'mimes:rar,zip,exe'
        ];
    }
}
