<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tarjetasPP extends Model
{
    //
    protected $table='tarjetas_p_ps';

    protected $primaryKey='id'; 
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'DesTarjet',

        'QRTarjet',

        'AutorTarj',

        'NombTarj',

        'fechaCreacT',
        
        'fotoApp',

        'examinar' 
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ];
}
