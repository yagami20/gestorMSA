<!DOCTYPE html>
<!--[if lt IE 8 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 8)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

   <!--- Basic Page Needs
   ================================================== -->
    <meta charset="utf-8">
    <title>M.S.A-3D</title>
    <meta name="description" content="">
    <meta name="author" content="">
   <!-- Mobile Specific Metas
  ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- CSS
   ================================================== -->
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/proyectos.css">

   <!-- Favicons
    ================================================== -->
    <link rel="shortcut icon" href="logomenu.ico" >
</head>

<body data-spy="scroll" data-target="#nav-wrap">
  
   <!-- Header
   ================================================== -->
   <header class="mobile"> 

      <div class="row">

         <div class="col full" >
            <div class="logo" style=" position: relative;"  >                    
                  <a href=""><img alt="" src="images/logomenu2.ico" style="width: 50px; height: 40px"></a>
            </div>

            <nav id="nav-wrap"> 
                <a class="mobile-btn" href="#nav-wrap" title="Show navigation">Mostrar navegación </a>
                <a class="mobile-btn" href="#" title="Hide navigation">Ocultar navegación</a>
                   
                   <ul id="nav" class="nav" >
                       <li><a href="#intro">Inicio</a></li>                       
                       <li><a href="#servicios">Servicios</a></li>                 
                       <li><a href="#nosotros">Nosotros</a></li>
                       <li><a href="#proyectos">Proyectos</a></li> 
                       <li><a href="#contacto">Contacto</a></li>
                       
                       
                       <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                              <li><a href="<?php echo e(url('/GestorP')); ?>">MSA3D</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        
                        <?php endif; ?>
                      
                        <?php endif; ?>
                   </ul>
            </nav>    
         </div>
      </div>
   </header> <!-- Header End -->


   <!-- Intro Section
   ================================================== -->
   <section id="intro">

      <!-- Flexslider Start-->
       <div id="intro-slider" class="flexslider">

           <ul class="slides">
               <!-- Slide -->
                   <div class="row">
                       <div class="col full">
                           <div class="slider-text">
                                <img src="images/acerca de/LOGO3D.png" align="center" alt="">
                                <h2>
                                    GRUPO DE INVESTIGACIÓN <span> M.S.A 3-D</span> </br>ESPOCH
                                </h2> 
                           </div>
                       </div>
                   </div>             
           </ul>
       </div>
       <!-- Flexslider End-->
   </section> <!-- Intro Section End-->

   <!-- Sección servicios
   ================================================== -->

  <section id="servicios">
       <div class="row section-head">
           <div class="col full" align="justify">
              <p class="desc" >
                  <h2> MISIÓN Y VISIÓN </h2> </br>
                      <dd>
                          <h3 style="color: #11ABB0;">
                              1. MISIÓN
                          </h3>
                      </dd>
                      <dd>
                          Somos un grupo de investigadores dedicados a la búsqueda de soluciones informáticas, electrónicas y de diseño 3D para la academia, investigación y vinculación. Nos comprometemos a producir productos y servicios de calidad para uso interno de la ESPOCH y fuera de ella.
                      </dd>  </br>              
                      <dd>
                          <h3 style="color: #11ABB0;">
                              2.  VISIÓN
                          </h3>
                      </dd>
                      <dd>
                          Pretendemos ser un referente en el ámbito universitario, ofreciendo productos con innovación y con un valor agregado al utilizar soluciones tecnológicas para necesidades sociales. Nos ubicamos en el ambiente de utilizar tecnología de punta, estar en constante innovación y realizar trabajos con “extra milla”.
                      </dd>                
              </p>          

              <p class="desc">
                  
                      <h2>OBJETIVOS DEL GRUPO</h2>
                
                  <dd>
                      <ul>
                          <li ><img src="images/icon.png">  Realizar, promocionar y difundir resultados de la investigación científica generadora de resultados de transferencia de conocimientos, en el ámbito "Modelado Simulación y Animación 3D".</li> 
                          <li> <img src="images/icon.png">  Generar proyectos innovadores en el campo del diseño, simulaciónn y animación 3D tanto a nivel educativo como profesional.</li> 
                          <li><img src="images/icon.png">  Publicar resultados de la investigación en eventos científicos a nivela local, nacional e internacional.</li>       
                      </ul> 
                  </dd>
              </p>   
                  <h2>Servicios</h2>    
          </div>
      </div>

        <div class="row">
             <!-- Servicios Wrapper -->
             <div id="portfolio-wrapper">
                 <div class="col portfolio-item">
                     <div class="item-wrap">
                             <img src="images/servicios/swEducativo.jpg" alt=""/>
                             <div class="portfolio-item-meta">
                                <h5><a>Software Educativo</a></h5>
                             </div>
                     </div>
              </div>

              <div class="col portfolio-item">
                 <div class="item-wrap">
                         <img src="images/servicios/realidadVirtual.jpg" alt=""/>
                         <div class="portfolio-item-meta">
                             <h5><a>Sistema de realidad virtual</a></h5>
                         </div>
                 </div>
              </div>

              <div class="col portfolio-item">
                 <div class="item-wrap">
                         <img src="images/servicios/juegos.jpg" alt=""/>
                         <div class="portfolio-item-meta">
                             <h5><a>Juegos por computadora</a></h5>
                         </div>
                 </div>
              </div>

              <div class="col portfolio-item">
                 <div class="item-wrap">
                      <img src="images/servicios/elearning.jpg" alt=""/>
                         <div class="portfolio-item-meta">
                             <h5><a>Sistemas E-learning</a></h5>
                         </div>
                 </div>
              </div>

              <div class="col portfolio-item">
                 <div class="item-wrap">
                    <img src="images/servicios/sistemasholograficos.jpg" alt=""/>
                         <div class="portfolio-item-meta">
                             <h5><a>Sistemas holográficos</a></h5>
                         </div>
                 </div>
              </div>

              <div class="col portfolio-item">
                 <div class="item-wrap">
                         <img src="images/servicios/realidad aumentada.jpg" alt=""/>
                         <div class="portfolio-item-meta">
                             <h5><a>Sistemas de realidad aumentada</a></h5>
                         </div>
                 </div>
              </div>

              <div class="col portfolio-item">
                 <div class="item-wrap">
                         <img src="images/servicios/simulacion3D.jpg" alt=""/>
                         <div class="portfolio-item-meta">
                             <h5><a>Modelado, animación y simulación 3D</a></h5>
                         </div>
                 </div>
              </div>

              <div class="col portfolio-item">
                 <div class="item-wrap">
                         <img src="images/servicios/resultadostridimensionales.jpg" alt=""/>
                         <div class="portfolio-item-meta">
                             <h5><a>Resultados tridimensionales para la toma de decisiones</a></h5>
                         </div>
                 </div>
              </div>
             </div> <!-- Portfolio Wrapper End -->

          </div> <!-- End Row -->

        <!-- Modal Popup
         =========================================================== -->

      <!-- modal-01 -->
         
         <!-- modal-01 End -->

    <!-- modal-02 -->
          
          <!-- modal-02 End -->

      <!-- modal-03 -->
         
          <!-- modal-03 End -->

      <!-- modal-04 -->
         
          <!-- modal-04 End -->

      <!-- modal-05 -->
         
          <!-- modal-05 End -->

      <!-- modal-06 -->
         
       <!-- modal-06 End -->

      <!-- modal-07 -->
         
          <!-- modal-07 End -->

      <!-- modal-08 -->
   
         </div>
          <!-- modal-08 End --> 
     </section> <!-- Fin Servicios-->


  <!-- Acerca de Section
   ================================================== 062c47-->
   <section id="nosotros" style="background: #0f8488">

      <div class="row section-head" >

         <div class="col one-fourth" >
            <h2 style="color:#f1f1f1">NOSOTROS</h2>                           
         </div>

         <div class="col three-fourths" >
            <img src="images/acerca de/grupo.jpg" alt="" />
             <p class="ctexto" style="color: #f3f3f3;"  >
             Somos un grupo de investigadores dedicados a la búsqueda de soluciones informáticas, electrónicas y de diseño 3D para la academia, investigación y vinculación. Nos comprometemos a producir productos y servicios de calidad para uso interno de la ESPOCH y fuera de ella.</br>
             El Grupo de investigación Modelado Simulación y Animación 3D (MSA-3D) se inscribe prioritariamente, en lo relativo a la línea nacional de investigación  “Tecnologías de la Información, Comunicación y Procesos Industriales”. Específicamente el Grupo (MSA-3D) se concentra en diseñar y producir objetos y servicios tridimensionales o 3D para la educación superior e investigación productiva. </p>
         </div>
      </div>

    <div class="row">
         <div class="col full"><h3 style="color: #f1f1f1">Actividades</h3></div>      
    </div>

  <div class="row process-wrap" >
    <div class=" row">
        <dd>
            <ul align="justify" style="color: #f3f3f3">
                <li><img src="images/icon2.png">  Publicación de resultados definitivos o preliminares de la investigación en revistas científicas de preferencia indexadas.</li> 
                <li><img src="images/icon2.png">  Realización de sistemas informáticos en colaboración con instituciones educativas, militares y privadas.</li> 
                <li><img src="images/icon2.png">  Apoyo a la organización de ventos científicos de la Facultad de Informática y Electrónica.</li>      
                <li><img src="images/icon2.png">  Desarrollo de la investigación en las líneas y programas mencionados.</li> 
                <li><img src="images/icon2.png">  Reporte técnicos de uso de una determinada herramienta o equipo.</li> 
                <li><img src="images/icon2.png">  Realización de proyectos con propuestas de innovación tecnológica.</li> 
                <li><img src="images/icon2.png">  Evaluaciones de productos software, hardware, comunicación.</li> 
                <li><img src="images/icon2.png">  Tesis de pregrado y postgrado debidamente seleccionadas.</li> 
                <li><img src="images/icon2.png">  Temas de mejores prácticas de un determinado campo.</li>  
                <li><img src="images/icon2.png">  Propuesta de criterios de comparación de técnicas.</li>
                <li><img src="images/icon2.png">  Propuesta de inventos. </li> 
                <li><img src="images/icon2.png">  Estudio de casos.</li>                 
            </ul> 
        </dd>        
    </div>
  </div>

      <div class="row">
         <div class="col full"><h3 style="color: lightgray">Equipo de trabajo.</h3></div>
      </div>

      <!-- Team Wrap End -->
      <div class="row team-wrap">

         <div class="col one-sixth">
          <center>
            <img src="images/MSA/FERNANDO PROAÑO.jpg" alt=""/>
          </center>
            <div class="member-name">
               <h5 style="color: #f3f3f3">Fernando Proaño Brito, Msc</h5>
               <span class="desc" style="color: #f3f3f3">Director Investigador Responsable Grupo MSA-3D</span>
            </div>
            <ul class="member-social">
               <li><a>fproanio@espoch.edu.ec</a></li>
            </ul>
          </div>

         <div class="col one-sixth">
          <center>
            <img src="images/MSA/DIANA OLMEDO.jpg" alt="" height="166px" />
          </center>
            <div class="member-name">
               <h5 style="color: #f3f3f3">Diana Olmedo Vizueta, PhD</h5>
               <span class="desc"style="color: #f3f3f3">Miembro área diseño y STEAM</span>
            </div>
            <ul class="member-social">
               <li><a>diana.olmedo@espoch.edu.ec</a></li>
            </ul>
            </div>

         <div class="col one-sixth">
          <center>
            <img src="images/MSA/RAMIRO SANTOS.jpg" alt=""/>
          </center>
            <div class="member-name">
               <h5 style="color: #f3f3f3">Ramiro Santos Poveda, Msc</h5>
               <span class="desc" class="desc" style="color: #f3f3f3">Miembro área diseño 3D</span>
            </div>
            <ul class="member-social">
               <li><a>rsantos@espoch.edu.ec</a></li>
            </ul>

          </div>

         
         <div class="col one-sixth">
          <center>
            <img src="images/MSA/PATRICIO SANTILLAN.jpg" alt="" height="126px" />
          </center>
              <div class="member-name">
                 <h5 style="color: #f3f3f3">Patricio Santillán Aguirre, Msc</h5>
                 <span class="desc" style="color: #f3f3f3">Miembro area diseño y comunicación</span>
              </div>
              <ul class="member-social">
                 <li><a>juan.santillan@espoch.edu.ec</a></li>
              </ul>
            </div>

            <div class="col one-sixth">
              <center>
                <img src="images/MSA/VICTOR HERRERA.jpg" alt=""  height="166px" />
              </center>
              <div class="member-name">
                   <h5 style="color: #f3f3f3">Victor Herrera Pérez, Msc</h5>
                   <span class="desc" style="color: #f3f3f3">Miembrp área electrónica con STEAM</span>
                </div>
              <ul class="member-social">
                 <li><a>isaac.herrera@espoch.edu.ec</a></li>
              </ul>
            </div>
      </div> <!-- Team Wrap End -->


  </section> <!-- acerca Section End-->


   <!--=====================================================
          Sección proyectos 
    ===================================================== -->
<section id="proyectos">

      <div class="row section-head">
          <div class="col full" ALIGN="justify">
                <h2>PROYECTOS</h2>
                <p class="desc">
                  Diseñar y construir una maqueta sobre transportes con elementos electrónicos, de software y de diseño gráfico interactivos, para desarrollar proyectos de tesis en la Escuela Superior Politécnica de Chimborazo (ESPOCH)
                </p>
          </div>
      </div>

      <div class="row">

           <!-- Portfolio Wrapper -->
           <div id="proyectos-wrapper">

               <div class="col proyectos-item"  style="width: 250px">
                   <div class="item-wrap">
                           <a href="#" data-reveal-id="modal-01"><img src="images/proyecto tren/tren.jpg" alt=""/></a>
                           <div class="proyectos-item-meta">
                               <h5><a href="#">El tren de la dulzura</a></h5>
                           </div>
                   </div>
               </div>

            <div class="col proyectos-item" style="width: 250px"> 
               <div class="item-wrap">
                       <a href="#" data-reveal-id="modal-02"><img src="images/proyecto tren/europa en auto/p_europeo.jpg" alt=""/></a>
                       <div class="proyectos-item-meta">
                           <h5><a href="#">Módulo: Europa en Auto</a></h5>
                       </div>
               </div>
            </div>

            <div class="col proyectos-item"  style="width: 250px">
               <div class="item-wrap">
                    <a href="#" data-reveal-id="modal-03"><img src="images/proyecto tren/aeropuerto/avion.jpg" alt=""/></a>
                       <div class="proyectos-item-meta">
                           <h5><a href="#">Módulo: Aeropuerto de Tababela</a></h5>
                       </div>
               </div>
            </div>

            <div class="col proyectos-item"  style="width: 250px">
               <div class="item-wrap">
                       <a href="#" data-reveal-id="modal-04"><img src="images/proyecto tren/juguetes educativos/tren.jpg" alt=""/></a>
                       <div class="proyectos-item-meta">
                           <h5><a href="#">Juguetes educativos - investigativos</a></h5>
                       </div>
               </div>
            </div>

            <div class="col proyectos-item" style="width: 250px">
               <div class="item-wrap">
                       <a href="#" data-reveal-id="modal-05"><img src="images/proyecto tren/ruta trenes/tren.jpg" alt=""/></a>
                       <div class="proyectos-item-meta">
                           <h5><a href="#">Módulo: Ruta de trenes interactivo</a></h5>
                       </div>
               </div>
            </div>

            <div class="col proyectos-item" style="width: 250px"> 
               <div class="item-wrap">
                       <a href="#" data-reveal-id="modal-06"><img src="images/proyecto tren/aeromodelismo/aeromodelismo.jpg" alt=""/></a>
                       <div class="proyectos-item-meta">
                           <h5><a href="#">Aeromodelismo</a></h5>
                       </div>
               </div>
            </div>

            <div class="col proyectos-item" style="width: 250px">

               <div class="item-wrap">
                       <a href="#" data-reveal-id="modal-07"><img src="images/proyecto tren/buque/buque.jpg" alt=""/></a>
                       <div class="proyectos-item-meta">
                           <h5><a href="#">Módulo: Buque escuela Guayas</a></h5>
                       </div>
               </div>
            </div>
            <!--ob3d  -->
            <div class="col proyectos-item" style="width: 250px; height: 80px">

               <div class="item-wrap">
                       <a href="<?php echo e(asset('/fie')); ?>" data-reveal-id="modal-08"><img src="images/proyecto3d/fie.jpg" alt=""/></a>
                       <div class="proyectos-item-meta">
                           <h5><a href="#">Módulo: Diseño Objetos 3D</a></h5>
                       </div>
               </div>
            </div>
            <!--  -->
        </div> <!-- Portfolio Wrapper End -->
    </div> <!-- End Row -->


      <!-- Modal Popup
       =========================================================== -->

      <!-- modal-01 -->
       <div id="modal-01" class="reveal-modal" align="center">

           <img class="scale-with-grid" src="images/proyecto tren/tren.jpg" alt="" align="center" />

           <div class="description-box">
               <h4>El tren de la dulzura</h4>
                <p>
                    Con el objetivo de investigar la educación lúdica y promocionar el turismo ferroviario en Ecuador, se esta realizando una tesis de grado de un estudiante de la carrera de Ingeniería en Sistemas de la ESPOCH con el siguiente titulo:</br>
                    <b>"MAQUETA  INTERACTIVA 3D PARA SIMULAR LA RUTA DEL TREN DE LA DULZURA.</b>
                </p>
            <span class="categories"><i class="icon-tag"></i>Tren</span>
           </div>

         <div class="link-box">
            <a href="<?php echo e(asset('/trendulzura')); ?>">Detalles</a>
              <a class="close-reveal-modal">Cerrar</a>
         </div>

       </div><!-- modal-01 End -->

      <!-- modal-02 -->
       <div id="modal-02" class="reveal-modal" align="center">

           <img class="scale-with-grid" src="images/proyecto tren/europa en auto/p_europeo.jpg" alt="" align="center" />

           <div class="description-box">
               <h4>Europa en Auto</h4>
               <p>Autos y camiones se desplazaran con la técnica "car sytem" los mismos que recorrerán varias vías representativas de Europa. El punto de partida será Madrid-España, recorrerá Francia y llegara a la ciudad de Hamburgo en Alemania.</p>
            <span class="categories"><i class="icon-tag"></i>Europa, Auto</span>
         </div>

         <div class="link-box">
            <a href="<?php echo e(asset('/europaAuto')); ?>">Detalles</a>
              <a class="close-reveal-modal">Cerrar</a>
         </div>

       </div> <!-- modal-02 End -->

      <!-- modal-03 -->
       <div id="modal-03" class="reveal-modal"  align="center">

           <img class="scale-with-grid" src="images/proyecto tren/aeropuerto/avion.jpg" alt="" />

           <div class="description-box">
               <h4>Aeropuerto de Tababela</h4>
               <p>El modelo de avión tanto de manera virtual (a través de Software) y de manera física a través de componentes electromecánicos (sistemas de control) realiza maniobras tanto de parqueo, carretaje, despegue y aterrizaje.</p>
            <span class="categories"><i class="icon-tag"></i>Aeropuerto</span>
         </div>

         <div class="link-box">
            <a href="<?php echo e(asset('/aeropuerto')); ?>">Detalles</a>
              <a class="close-reveal-modal">Cerrar</a>
         </div>

       </div> <!-- modal-03 End -->

      <!-- modal-04 -->
       <div id="modal-04" class="reveal-modal"  align="center">

           <img class="scale-with-grid" src="images/proyecto tren/juguetes educativos/tren.jpg" alt="" />

           <div class="description-box">
               <h4>Juguetes Educativos- Interactivos </h4>
               <p>Con la idea de promocionar el arte del modelismo y combinar con la educación superior se presenta el proyecto:  JUGUETES EDUCATIVOS - INVESTIGATIVOS, el mismo que ha sido fruto de varios años de trabajo e investigación.</p>
            <span class="categories"><i class="icon-tag"></i>Juguetes, Educacíon, Investigación</span>
         </div>

         <div class="link-box">
            <a href="<?php echo e(asset('/juegueteseducativos')); ?>">Detalles</a>
              <a class="close-reveal-modal">Cerrar</a>
         </div>

       </div> <!-- modal-04 End -->

      <!-- modal-05 -->
       <div id="modal-05" class="reveal-modal" align="center">

           <img class="scale-with-grid" src="images/proyecto tren/ruta trenes/tren.jpg" alt="" />

           <div class="description-box">
              <h4> Ruta de trenes interactivo</h4>
              <p>En este modulo se presenta la ruta del ferrocarril de Ecuador del tramo Riobamba - Quito.</p>
            <span class="categories"><i class="icon-tag"></i>tren interactivo</span>
         </div>

         <div class="link-box">
            <a href="<?php echo e(asset('/treninteractivo')); ?>">Detalles</a>
              <a class="close-reveal-modal">Cerrar</a>
         </div>

       </div> <!-- modal-05 End -->
            
      <!-- modal-06 -->
       <div id="modal-06" class="reveal-modal" align="center">

           <img class="scale-with-grid" src="images/proyecto tren/aeromodelismo/aeromodelismo.jpg" alt="" />

           <div class="description-box">
               <h4>Aeromodelismo</h4>
               <p>El aeromodelismo comprende el estudio, diseño y construcción de modelos de aviones, los mismos que pueden fabricados en diferentes materiales como balsa (lo más común), madera, cartón, papel.</p>
            <span class="categories"><i class="icon-tag"></i>Aeromodelismo</span>
         </div>

         <div class="link-box">
            <a href="<?php echo e(asset('/aeromodelismo')); ?>"> Detalles</a>
              <a class="close-reveal-modal">Cerrar</a>
         </div>

       </div> <!-- modal-06 End -->

      <!-- modal-07 -->
       <div id="modal-07" class="reveal-modal"  align="center">

           <img class="scale-with-grid" src="images/proyecto tren/buque/buque.jpg" alt="" />

           <div class="description-box">
               <h4>Buque escuela Guayas</h4>
               <p>Este módulo presenta al emblemático Buque Escuela Guayas, tanto a nivel de diseño 3D como en varios modelos a construir en material de madera y balsa, con detalles propios de replicas de colección.</p>
            <span class="categories"><i class="icon-tag"></i>Buque</span>
         </div>

         <div class="link-box">
            <a href="<?php echo e(asset('/buque')); ?>">Detalles</a>
              <a class="close-reveal-modal">Cerrar</a>
         </div>

       </div> <!-- modal-07 End -->
       <!--modal 8  -->
       <div id="modal-08" class="reveal-modal"  align="center">

           <img class="scale-with-grid" src="images/proyecto3d/fie.jpg" alt="" />

           <div class="description-box">
               <h4>Diseño Objetos 3D</h4>
               <p>Este módulo presenta al Edificio de la Facultad de Informática y Electónica, tanto a nivel de diseño 3D como en varios modelos a construir en material de madera y plastico, con detalles propios de replicas de colección.</p>
            <span class="categories"><i class="icon-tag"></i>FIE</span>
         </div>

         <div class="link-box">
            <a href="<?php echo e(asset('/fie')); ?>">Detalles</a>
              <a class="close-reveal-modal">Cerrar</a>
         </div>

       </div> 
       <!--end modal8  -->

     
   </section> <!-- Proyectos End -->
<!-- ==================================================== -->
     <!--  Contacto
   ================================================== -->
   <section id="contacto">

      <div class="row section-head">

        <div class="row">
             <div class="col full">
                <h2>Contacto</br> </h2> 
                <p class="desc" >
                  Para todo tipo de preguntas, comentarios e inquietudes completa el formulario a continuación.
                </p>          
             </div>
        </div>

            <aside class="col g-5">
               
    ​           <h3>Dirección: </h3>
                <p class="desc">
                   Panamericana Sur km 1 1/2<br />
                   Riobamba - Ecuador<br />
                   Teléfono: +593 98 759 108<br />
                   Email: grupo3d@espoch.edu.ec
                   <br/>

                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2326.1466287114445!2d-78.67549771911482!3d-1.6570028504950938!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xef8636414c424459!2sFacultad+De+Inform%C3%A1tica+y+Electr%C3%B3nica+-+ESPOCH!5e0!3m2!1ses-419!2sec!4v1555435571912!5m2!1ses-419!2sec" width="300" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
                </p>

            </aside>

         <div class="col g-7">
            <h3 style="color: #11ABB0">Preguntas</h3>
            
            <!-- formulario de contacto -->
            <form name="contactForm" id="contactForm" method="post" action="">
                    <fieldset>

                  <div>
                        <label for="contactName">Nombre <span class="required">*</span></label>
                        <input name="contactName" type="text" id="contactName" size="35" value="" height="25px" />
                  </div>

                  <div>
                        <label for="contactEmail">Email <span class="required">*</span></label>
                        <input name="contactEmail" type="text" id="contactEmail" size="35" value="" />
                  </div>

                  <div>
                        <label for="contactSubject">Asunto</label>
                        <input name="contactSubject" type="text" id="contactSubject" size="35" value="" />
                  </div>

                  <div>
                        <label  for="contactMessage">Mensaje <span class="required">*</span></label>
                        <textarea name="contactMessage"  id="contactMessage" rows="15" cols="50" ></textarea>
                  </div>

                  <div>
                        <button class="submit">Enviar</button>
                        <span id="image-loader">
                             <img src="images/loader.gif" alt="" />
                        </span>
                  </div>
                    </fieldset>
                </form> <!-- Fin del formulario de contacto   -->

            <!-- Mensaje de advertencia -->
            <div id="message-warning"></div>
            <!-- Mensaje exitoso de contacto -->
                <div id="message-success">
               <i class="icon-ok"></i>Su mensaje ha sido enviado, Gracias !<br />
                </div>
         </div>

                <!-- seccion contacto envio de mensajEs! -->
                <a id="foxyform_embed_link_336900" href="http://es.foxyform.com/">foxyform</a>
                <script type="text/javascript">
                (function(d, t){
                   var g = d.createElement(t),
                       s = d.getElementsByTagName(t)[0];
                   g.src = "http://es.foxyform.com/js.php?id=336900&sec_hash=a89b559d4b0&width=350px";
                   s.parentNode.insertBefore(g, s);
                }(document, "script"));
                </script>
                <!-- FIN sección envio de mensajes ! -->
      </div>

   </section> <!-- fin de la sección Contacto-->


   <!-- footer
   ================================================== -->
   <footer>

      <div class="row">

         <div class="col g-7">
            <ul class="copyright">
               <li>&copy; 2014 Kreative</li>
               <li>Design by <a href="http://www.styleshout.com/" title="Styleshout">Styleshout</a></li>               
            </ul>
         </div>

         <div class="col g-5 pull-right">
            <ul class="social-links">
               <li><a href="#"><i class="icon-facebook"></i></a></li>
               <li><a href="#"><i class="icon-twitter"></i></a></li>
               <li><a href="#"><i class="icon-google-plus-sign"></i></a></li>
               <li><a href="#"><i class="icon-skype"></i></a></li>         
            </ul>
         </div>
      </div>
   </footer> <!-- Footer End-->
   <!-- Java Script
   ================================================== -->
   <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
   <script>window.jQuery || document.write('<script src="js/jquery-1.10.2.min.js"><\/script>')</script>
   <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
   <script src="js/app.js"></script>
   <script src="js/scrollspy.js"></script>
   <script src="js/jquery.flexslider.js"></script>
   <script src="js/jquery.reveal.js"></script>
   <script src="http://maps.google.com/maps/api/js?sensor=true" type="text/javascript"></script>
   <script src="js/gmaps.js"></script>
   <script src="js/init.js"></script>
   <script src="js/smoothscrolling.js"></script>

</body>

</html>