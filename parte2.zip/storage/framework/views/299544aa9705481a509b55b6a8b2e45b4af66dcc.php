    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<?php $__env->startSection('content'); ?>
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    <h5><a href="<?php echo e(asset('GestorMSA/Almacen')); ?>">Almacen</a>/Graficos 3D</h5>
		<h3>Grafico 3D: <a href="Graficos3D/create"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Nuevo</button></a></h3><br>

		<h3>Listado de Graficos 3D</h3>
		<?php echo $__env->make('GestorMSA.Graficos3D.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>
  <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Código</th>
                  <th>tipo S.W.</th>
                  <th>Autor/es</th>
                  <th>fecha Creación</th>
                  <th>observación</th>
                  <th>obj 3D</th>
                  <th>tipo Obj</th>                
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $graf3d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <td>FIEOBJ3D<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->tipoSW); ?></td>
                  <td><?php echo e($usd->Autorgraf3D); ?></td>
                  <td><?php echo e($usd->fechaCreacion); ?></td>
                  <td><?php echo e($usd->observacion); ?></td>
                  <td><?php echo e($usd->obj3D); ?></td>
                  <td><?php echo e($usd->tipoObj); ?></td>
                  <td>
                    <a href="<?php echo e(URL::action('GraficosController@verObj',$usd->id)); ?>"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-edit"></i>Obj. 3D</button></a>
                    <a href="" data-target="#modal-Documento-<?php echo e($usd->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Documento</button></a>
                    <a href="<?php echo e(URL::action('GraficosController@edit',$usd->id)); ?>"><button type="button" class="btn btn-outline-info btn-sm"><i class="fa fa-edit"></i> Editar</button></a> 
                    
                    
                    <a href="" data-target="#modal-delete-<?php echo e($usd->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-danger btn-sm"><i class="fa fa-user-times"></i> Eliminar</button></a>
                  </td>
                </tr>
                <?php echo $__env->make('GestorMSA.Graficos3D.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('GestorMSA.Graficos3D.modal3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
              </table>
            </div>
            <?php echo e($graf3d->render()); ?>

          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>