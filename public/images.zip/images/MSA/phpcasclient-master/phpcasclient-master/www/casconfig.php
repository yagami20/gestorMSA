<?php

//require_once $_SERVER["DOCUMENT_ROOT"] . '/vendor/autoload.php';
require_once( __DIR__ . '/../vendor/autoload.php');

// #### change with your own CAS server ####
//phpCAS::setDebug();
$casservername = 'seguridad.espoch.edu.ec';
$casport = 443;
$casbaseuri = '/cas';
$caslogouturl = '/logout?service=';
$casprotocol = 'https://';
phpCAS::client(CAS_VERSION_3_0, $casservername, $casport, $casbaseuri);
//phpCAS::setCasServerCACert($_SERVER["DOCUMENT_ROOT"] . '../certs/usertrust_ca.cer');
phpCAS::setNoCasServerValidation();

// handle logout requests directly from the CAS server
//phpCAS::handleLogoutRequests(true, array('localhost'));
?>
