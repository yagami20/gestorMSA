<link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>

<link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/layout.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/proyectos.css')); ?>">
<?php $__env->startSection('content'); ?>


<!-- <archvista-component></archvista-component> -->
<div id="app">
        <model-gltf 
            src="/documentos/arch3D/extract/<?=  $graf3d->obj3D;   ?>"
            @on-mousemove="onMouseMove">
        </model-gltf>
    </div>
<script>
  new Vue({ el: '#app' });
</script>
<a href="<?php echo e(asset('/DescargaFie')); ?>"><button type="button" class="btn btn-outline-dark btn-sm">
			<span aria-hidden="true">atras X</span>
</button></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>