<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>
<?php $__env->startSection('content'); ?>
<div class="row section-head">
         <div class="col full" align="justify">
            <p class="desc" align="justify" >             
              <center><h2> EDIFICIO 3D: Facultad de Informática y Electrónica </h2></center> 
              
            
        
    
    <div id="app">
        <model-collada src="/documentos/arch3D/extract/EDIFICIO-FIE.dae"></model-collada>
    </div>

		    <script>
		        new Vue({
		            el: '#app'
		        })
		    </script>
                          
            
          
          <button class="regresar">
            <a style="color: white" href="<?php echo e(asset('/fie')); ?>">Regresar</a>
          </button>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>