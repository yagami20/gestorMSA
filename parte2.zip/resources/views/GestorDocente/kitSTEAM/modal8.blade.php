<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-foto-{{$usd->id}}">
{{Form::Open(array('action'=>array('KitSTEAMdController@Download',$usd->id),'method'=>'delete'))}}
<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">X</span>
			
		</button>
		<h4 class="modal-title">Ver Archivo</h4>
	</div>
	<div class="modal-body">
		
		
				<!--  -->
				<div class="box-body box-profile">
                      <p class="text-muted text-center">Kit STEAM</p>
                      <p class="text-muted text-center"><img src="{{asset('/imagenes/kitSTEAM/portadaKit/'.$usd->Portada)}}" style="width: 150px; height: 180px" class="img-thumbnail"></p> 
                      <p class="text-muted text-left">Codigo: FIEKIT{{$usd->id}}</p>
                      <p class="text-muted text-left">Titulo: {{$usd->nombreCaja}}</p>
                      <p class="text-muted text-left">Autor/es: {{$usd->Autor}}</p>
                      <p class="text-muted text-left">Correo Autor/es: {{$usd->correo}}</p>
                      <p class="text-muted text-left">Fecha registro: {{$usd->fecha}}</p>
                      <p class="text-muted text-left">Tipo Material: {{$usd->material}}</p>
                      <p class="text-muted text-center">Enlace web: <a href="#">{{$usd->enlace}}</a></p>

                      <a href="{{URL::action('KitSTEAMdController@downloadPlano',$usd->plano)}}"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Plano</button></a>
                      
                      <a href="" data-target="#modal-video-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> VideoV</button></a>

                      
                  </div>
				<!--  -->
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
		
	</div>

	</div>
</div>
{{Form::Close()}}	

</div>