<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class archPFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'TipoArchivo' => 'required|string|max:255',
            'AutorArchP' => 'required|string|max:255',
            'DocArchP'=>'mimes:pdf',//
            'ImgArchP'=>'mimes:jpeg,bmp,jpg,png',//
            'fechaGener'=>'required|max:10',
            'observacion' => 'required|string|max:255',
            'tipoObjP' => 'required|string|max:1',
            'objPlano'=>'mimes:rar,zip,exe'
        ];
    }
}
