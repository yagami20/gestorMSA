<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//parte llamado

use App\patentesPrP;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\PatentesFormRequest;
use App\Http\Requests\busquedaAppFormRequest;
use phpCAS;

use DB;
use Fpdf;

class pdfRepTarjetDController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $request->user()->authorizeRoles(['docent']);
        
        $apg=DB::table('tarjetas_p_ps as tbU')
            ->select('tbU.id','tbU.DesTarjet','tbU.QRTarjet','tbU.NombTarj','tbU.fotoApp','tbU.examinar','tbU.fechaCreacT')
            ->orderBy('tbU.id','desc')
            ->paginate(7);
        return view ('GestorDocente.Reportes.tarjeta.index',["apg"=>$apg]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $request->user()->authorizeRoles(['docent']);
        
            $apg=DB::table('tarjetas_p_ps as tbU')
            ->select('tbU.NombTarj','tbU.fechaCreacT','tbU.examinar')
            ->where('tbU.id','!=',1)
            ->orderBy('tbU.id','desc')
            ->paginate(20);
            $this->bfecha($apg);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show ($id)
    {        
        return view("GestorDocente.Reportes.tarjeta.show"); 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function bfecha ($apg)
    {

            Fpdf::AddPage();
            Fpdf::Image('ENCABEZ.JPG',20,20,-100);
            Fpdf::Ln(50);
            Fpdf::SetFont('Arial','B',14);
            Fpdf::Write(5,'Reporte Tarjetas Pop - Up ');
            Fpdf::Ln(10);
            Fpdf::Cell(40,6,'Nombre Tarjeta',1,0,'C');
            Fpdf::Cell(30,6,'Fecha',1,0,'C');
            Fpdf::Cell(70,6,'Documento',1,1,'C');
            Fpdf::SetFont('Arial','',8);

            foreach($apg as $row)
            {
                $j=0;
                foreach($row as $col){
                    if($j==2){
                    Fpdf::Cell(70,6,$col,1);    
                    }
                    else{
                        if($j==1){
                            Fpdf::Cell(30,6,$col,1,0,'C');
                        }
                        else{
                            if($j==3){
                                Fpdf::Cell(75,6,$col,1);
                            }
                            else{
                                Fpdf::Cell(40,6,$col,1);    
                            }
                            
                        }
                        
                    }
                    
                    $j++;
                    }
                Fpdf::Ln();
            }
            
            Fpdf::Output();
            exit;
    }
    public function destroy(busquedaAppFormRequest $request,$id)
    {
        $fecha1=trim($request->get('FechaInicio')); //determinr texto de busqueda

            $fecha2=trim($request->get('FechaFin')); //determinr texto de busqueda
            $f1=date("Y-m-d", strtotime($request->get('FechaInicio')));
            $f2=date("Y-m-d", strtotime($request->get('FechaFin')));
            $fechaI=DB::table('tarjetas_p_ps as tbI')
            ->whereBetween('tbI.fechaCreacT',[$f1,$f2])
            ->get();
            if($fechaI)
                {
                    $oficioI=DB::table('tarjetas_p_ps as tbU')
                    ->select('tbU.NombTarj','tbU.fechaCreacT','tbU.examinar')
                        ->whereBetween('tbU.fechaCreacT',[$f1,$f2])
                        ->where('tbU.id','!=',1)
                        ->get();
                    // if($oficioI->idOficioI<>'1')
                    // {
                        $this->bfecha($oficioI);
                //fin id
                    // }
            //fin prim if
                }
    }
}
