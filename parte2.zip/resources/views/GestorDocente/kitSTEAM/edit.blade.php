@extends ('layouts.docente')
@section ('content')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="{{asset('GestorDocente/Almacen')}}">Almacen</a>/
                <a href="{{asset('GestorDocente/kitSTEAM')}}">Kit STEAM</a>/Crear
            </h5>
			<h3>Editar Kit: {{$caja->nombreC}}</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

	
			


<form method="POST" action="/GestorDocente/kitSTEAM/{{$kit->id}}" enctype="multipart/form-data">
    @method('PUT')  
    @csrf
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="{{ route('register') }}" aria-label="{{ __('Register') }}"> -->
                       

                        <div class="form-group row">
                            <label for="nombreC" class="col-md-4 col-form-label text-md-right">{{ __('Nombre Caja') }}</label>

                            <div class="col-md-6">
                                <input id="nombreC" type="text" placeholder="Nombre Apellido" class="form-control{{ $errors->has('nombreC') ? ' is-invalid' : '' }}" name="nombreC" value="{{$caja->nombreC}}" required autofocus>

                                @if ($errors->has('nombreC'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('nombreC') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="AutorKit" class="col-md-4 col-form-label text-md-right">{{ __('Autor/es') }}</label>

                            <div class="col-md-6">
                                <input id="AutorKit" type="text" placeholder="Descripción" class="form-control{{ $errors->has('AutorKit') ? ' is-invalid' : '' }}" name="AutorKit" value="{{$kit->AutorKit}}" required autofocus>

                                @if ($errors->has('AutorKit'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('AutorKit') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="tipoMateria" class="col-md-4 col-form-label text-md-right">{{ __('Tipo Material') }}</label>

                            <div class="col-md-6">
                                <input id="tipoMateria" type="text" placeholder="Descripción" class="form-control{{ $errors->has('tipoMateria') ? ' is-invalid' : '' }}" name="tipoMateria" value="{{$contKit->tipoMateria}}" required autofocus>

                                @if ($errors->has('tipoMateria'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('tipoMateria') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="enlaceWeb" class="col-md-4 col-form-label text-md-right">{{ __('Enlace web:') }}</label>

                            <div class="col-md-6">
                                <input id="enlaceWeb" type="text" placeholder="www.kitSTEAM.blogspot.com..." class="form-control{{ $errors->has('enlaceWeb') ? ' is-invalid' : '' }}" name="enlaceWeb" value="{{$contKit->enlaceWeb}}" required autofocus>

                                @if ($errors->has('enlaceWeb'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('enlaceWeb') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('Correo Creador:') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="text" placeholder="www.kitSTEAM.blogspot.com..." class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{$kit->email}}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaKit" class="col-md-4 col-form-label text-md-right">{{ __('Fecha creación S.W.') }}</label>

                            <div class="col-md-6">
                                <input id="fechaKit" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('fechaKit') ? ' is-invalid' : '' }}" name="fechaKit" value="{{$kit->fechaKit}}" required autofocus>

                                @if ($errors->has('fechaKit'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fechaKit') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="portadakit" class="col-md-4 col-form-label text-md-right">{{ __('Cargar Foto Portada (extensión: jpeg,bmp,jpg,png):') }}</label>

                            <div class="col-md-6">
                                <input id="portadakit" type="file" name="portadakit" value="{{ old('portadakit') }}" required autofocus>

                                @if ($errors->has('portadakit'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('portadakit') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="aplicabilidad" class="col-md-4 col-form-label text-md-right">{{ __('Cargar Documento Aplicabilidad (extensión: pdf):') }}</label>

                            <div class="col-md-6">
                                <input id="aplicabilidad" type="file" name="aplicabilidad" value="{{ old('aplicabilidad') }}" required autofocus>

                                @if ($errors->has('aplicabilidad'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('aplicabilidad') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="planos" class="col-md-4 col-form-label text-md-right">{{ __('Cargar archivo Planos (extensión: zip max:20MB):') }}</label>

                            <div class="col-md-6">
                                <input id="planos" type="file" name="planos" value="{{ old('planos') }}" required autofocus>

                                @if ($errors->has('planos'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('planos') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="piezaArmar" class="col-md-4 col-form-label text-md-right">{{ __('Importar Documento pieza Armar (extensión: pdf):') }}</label>

                            <div class="col-md-6">
                                <input id="piezaArmar" type="file" name="piezaArmar" value="{{ old('piezaArmar') }}" required autofocus>

                                @if ($errors->has('piezaArmar'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('piezaArmar') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="instrucciones" class="col-md-4 col-form-label text-md-right">{{ __('Cargar Documento instrucciones (extensión: pdf) ') }}</label>

                            <div class="col-md-6">
                                <input id="instrucciones" type="file" name="instrucciones" value="{{ old('instrucciones') }}" required autofocus>

                                @if ($errors->has('instrucciones'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('instrucciones') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="tutoDigital" class="col-md-4 col-form-label text-md-right">{{ __('Importar video Comprimido (extensión: .mp4 compresión: zip) ') }}</label>

                            <div class="col-md-6">
                                <input id="tutoDigital" type="file" name="tutoDigital" value="{{ old('tutoDigital') }}" required autofocus>

                                @if ($errors->has('tutoDigital'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('tutoDigital') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="informacion" class="col-md-4 col-form-label text-md-right">{{ __('Importar documento de información (extensión: pdf):') }}</label>

                            <div class="col-md-6">
                                <input id="informacion" type="file" name="informacion" value="{{ old('informacion') }}" required autofocus>

                                @if ($errors->has('informacion'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('informacion') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="codQR" class="col-md-4 col-form-label text-md-right">{{ __('Importar foto QR (extensión: jpeg,bmp,jpg,png):') }}</label>

                            <div class="col-md-6">
                                <input id="codQR" type="file" name="codQR" value="{{ old('codQR') }}" required autofocus>

                                @if ($errors->has('codQR'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('codQR') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        {{--  --}}
                        
                        

                        <!--fin ndatos  -->
                        <!--new datos  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idKit" value="{{$kit->id}}">
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idContenido" value="{{$contKit->id}}">
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idCaja" value="{{$caja->id}}">
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idProducto" value="{{$prod->id}}">
                            </div>
                        </div>
                        <!--estado  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    {{ __('Enviar') }}
                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
@endsection