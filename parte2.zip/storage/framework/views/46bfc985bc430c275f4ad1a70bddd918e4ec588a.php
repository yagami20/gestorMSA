<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="<?php echo e(asset('GestorMSA/Almacen')); ?>">Almacen</a>/
                <a href="<?php echo e(asset('GestorMSA/Graficos3D')); ?>">Graficos 3D</a>/Crear
            </h5>
			<h3>Nuevo Objeto 3D</h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>
			<?php echo Form::open(array('url'=>'GestorMSA/Graficos3D','method'=>'POST','autocomplete'=>'off','files'=>'true')); ?>

			<?php echo e(Form::token()); ?>


		<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="tipoSW" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipo de Software de Creación')); ?></label>

                            <div class="col-md-6">
                                <input id="tipoSW" type="text" placeholder="S.W. de Creación" class="form-control<?php echo e($errors->has('tipoSW') ? ' is-invalid' : ''); ?>" name="tipoSW" value="<?php echo e(old('tipoSW')); ?>" required autofocus>

                                <?php if($errors->has('tipoSW')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('tipoSW')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="Autorgraf3D" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Autor/es')); ?></label>

                            <div class="col-md-6">
                                <input id="Autorgraf3D" type="text" placeholder="Autor1, Autor2#..." class="form-control<?php echo e($errors->has('Autorgraf3D') ? ' is-invalid' : ''); ?>" name="Autorgraf3D" value="<?php echo e(old('Autorgraf3D')); ?>" required autofocus>

                                <?php if($errors->has('Autorgraf3D')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('Autorgraf3D')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="Desgraf3D" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Descripción')); ?></label>

                            <div class="col-md-6">
                                <input id="Desgraf3D" type="text" placeholder="Descripcion de Obj. 3D" class="form-control<?php echo e($errors->has('Desgraf3D') ? ' is-invalid' : ''); ?>" name="Desgraf3D" value="<?php echo e(old('Desgraf3D')); ?>" required autofocus>

                                <?php if($errors->has('Desgraf3D')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('Desgraf3D')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaCreacion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha Creación')); ?></label>

                            <div class="col-md-6">
                                <input id="fechaCreacion" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control<?php echo e($errors->has('fechaCreacion') ? ' is-invalid' : ''); ?>" name="fechaCreacion" value="<?php echo e(old('fechaCreacion')); ?>" required autofocus>

                                <?php if($errors->has('fechaCreacion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fechaCreacion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        <div class="form-group row">
                            <label for="obj3D" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Agregar Objeto')); ?></label>

                            <div class="col-md-6">
                                <input id="obj3D" type="file" name="obj3D" value="<?php echo e(old('obj3D')); ?>" required autofocus>

                                <?php if($errors->has('obj3D')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('obj3D')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="Docgraf3D" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Agregar Documento Objeto')); ?></label>

                            <div class="col-md-6">
                                <input id="Docgraf3D" type="file" name="Docgraf3D" value="<?php echo e(old('Docgraf3D')); ?>" required autofocus>

                                <?php if($errors->has('Docgraf3D')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('Docgraf3D')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="observacion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Observación de archivo')); ?></label>

                            <div class="col-md-6">
                                <input id="observacion" type="text" placeholder="abrir con Sketchup..." class="form-control<?php echo e($errors->has('observacion') ? ' is-invalid' : ''); ?>" name="observacion" value="<?php echo e(old('observacion')); ?>" required autofocus>

                                <?php if($errors->has('observacion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('observacion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="tipoObj" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipo de objeto')); ?></label>

                            <div class="col-md-6">
                                <!-- <div class="col-sm-4"> -->
                                              <select name="tipoObj" class="form-control">
                                                <option value="1">Objeto Json</option>
                                                <option value="2">Objeto Obj</option>
                                                <option value="4">Objeto Stl</option>
                                                <option value="5">Objeto Dae</option>
                                                <option value="6">Objeto Ply</option>
                                                <option value="7">Objeto Gltf</option>
                                            </select>
                                            <!-- </div> -->

                                <?php if($errors->has('tipoObj')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('tipoObj')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--fin ndatos  -->
                        <!--new datos  -->
                        <!--estado  -->
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>


		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>