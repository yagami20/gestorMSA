<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class kitSteamFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'nombreC'=>'required|string|max:255',//
            'tipoMateria'=>'required|string|max:255',//
            'AutorKit'=>'required|string|max:255',//
            'enlaceWeb'=>'required|string|max:255',//
            'email' => 'required|string|email|max:255',//
            'fechaKit'=>'required|max:10',//
            'aplicabilidad'=>'mimes:pdf',//
            'planos'=>'mimes:rar,zip,exe',
            'piezaArmar'=>'mimes:rar,zip,pdf',//
            'instrucciones'=>'mimes:pdf',//
            'tutoDigital'=>'mimes:zip',
            'informacion'=>'mimes:pdf',//
            'codQR'=>'mimes:jpeg,bmp,jpg,png',// 
            'portadakit'=>'mimes:jpeg,bmp,jpg,png'//
        ];
    }
}
