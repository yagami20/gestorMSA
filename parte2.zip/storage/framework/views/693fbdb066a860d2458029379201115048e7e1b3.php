    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    <h5><a href="<?php echo e(asset('GestorUsuario/Almacen')); ?>">Almacen</a>/Archivos Planos</h5>
		<h3>Archivo Plano: </h3>
		<h3>Listado de Archivos Planos</h3>
		<?php echo $__env->make('GestorUsuario.archPlanos.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Código</th>
                  <th>NombreArchivo</th>
                  <th>Autor/es</th>
		 			        <th>fechaGener</th>
                  <th>observacion</th>
                  <th>tipoObjP</th>                
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                	<?php $__currentLoopData = $archP; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id!='1'): ?>
                  <td>FIEARCHPL<?php echo e($usd->id); ?></td>
        		 			<td><?php echo e($usd->TipoArchivo); ?></td>
                  <td><?php echo e($usd->AutorArchP); ?></td>
                  <td><?php echo e($usd->fechaGener); ?></td>
                  <td><?php echo e($usd->observacion); ?></td>
                  <td><?php echo e($usd->tipoObjP); ?></td>
                  <td>
                    <a href="" data-target="#modal-foto-<?php echo e($usd->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Examinar</button></a>
                    <a href="" data-target="#modal-solic-<?php echo e($usd->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Documento</button></a>
                  </td> 
                </tr>
                <?php endif; ?>
                <?php echo $__env->make('GestorUsuario.archPlanos.modal2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('GestorUsuario.archPlanos.modal4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
              </table>
            </div>
            <?php echo e($archP->render()); ?>

            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>