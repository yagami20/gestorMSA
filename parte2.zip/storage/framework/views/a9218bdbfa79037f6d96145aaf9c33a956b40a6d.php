<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="<?php echo e(asset('GestorUsuario/Almacen')); ?>">Almacen</a>/
                <a href="<?php echo e(asset('GestorUsuario/tarjetasPopUp')); ?>">Tarjetas</a>/Create
            </h5>
			<h3>Nueva Tarjeta Pop Up:</h3><br>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>
			<?php echo Form::open(array('url'=>'GestorUsuario/tarjetasPopUp','method'=>'POST','autocomplete'=>'off','files'=>'true')); ?>

			<?php echo e(Form::token()); ?> 

		<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>"> -->
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre Tarjeta:')); ?></label>

                            <div class="col-md-6">
                                <input id="NombTarj" type="text" title="Nombre que se le aplica a la tarjeta" placeholder="NombTarj #..." class="form-control<?php echo e($errors->has('NombTarj') ? ' is-invalid' : ''); ?>" name="NombTarj" value="<?php echo e(old('NombTarj')); ?>" required autofocus>

                                <?php if($errors->has('NombTarj')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('NombTarj')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="DesTarjet" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Descripción de Tarjeta')); ?></label>

                            <div class="col-md-6">
                                <input id="DesTarjet" type="text" title="Breve descripción sobre la tarjeta" placeholder="Simulador #..." class="form-control<?php echo e($errors->has('DesTarjet') ? ' is-invalid' : ''); ?>" name="DesTarjet" value="<?php echo e(old('DesTarjet')); ?>" required autofocus>

                                <?php if($errors->has('DesTarjet')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('DesTarjet')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="AutorTarj" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Autor/es de Tarjeta')); ?></label>

                            <div class="col-md-6">
                                <input id="AutorTarj" type="text" placeholder="Simulador #..." class="form-control<?php echo e($errors->has('AutorTarj') ? ' is-invalid' : ''); ?>" name="AutorTarj" value="<?php echo e(Auth::user()->name); ?>" required autofocus>

                                <?php if($errors->has('AutorTarj')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('AutorTarj')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        
                        <!--  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaCreacT" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha creación:')); ?></label>

                            <div class="col-md-6">
                                <input id="fechaCreacT" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control<?php echo e($errors->has('fechaCreacT') ? ' is-invalid' : ''); ?>" name="fechaCreacT" value="<?php echo e(old('fechaCreacT')); ?>" required autofocus>

                                <?php if($errors->has('fechaCreacT')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fechaCreacT')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cargar Foto (extensión: archivo:jpeg,bmp,jpg,png):')); ?></label>

                            <div class="col-md-6">
                                <input id="fotoApp" type="file" title="Formato de archivo:jpeg,bmp,jpg,png" name="fotoApp" value="<?php echo e(old('fotoApp')); ?>" required autofocus>

                                <?php if($errors->has('fotoApp')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fotoApp')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="QRTarjet" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cargar codigo QR (extensión: archivo:jpeg,bmp,jpg,png):')); ?></label>

                            <div class="col-md-6">
                                <input id="QRTarjet" type="file" title="QR de realidad aumentada" name="QRTarjet" value="<?php echo e(old('QRTarjet')); ?>" required autofocus>

                                <?php if($errors->has('QRTarjet')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('QRTarjet')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        <div class="form-group row">
                            <label for="examinar" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Importar Documentacion (extensión: pdf):')); ?></label>

                            <div class="col-md-6">
                                <input id="examinar" type="file" title="Archivo formato zip o pdf" name="examinar" value="<?php echo e(old('examinar')); ?>" required autofocus>

                                <?php if($errors->has('examinar')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('examinar')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  --><!--  -->
                       
                                <input type="hidden" name="idUser" value="<?php echo e(Auth::user()->id); ?>">
                          
                        <!--  -->
                      
                                <input type="hidden" name="idGraf3D" value="1">
                       
                        <!--  -->
                      
                                <input type="hidden" name="idarchPlano" value="1">
                          
                        <!--  -->
                      
                                <input type="hidden" name="idApp" value="1">
                         
                        <!--  -->
                      
                                <input type="hidden" name="idKit" value="1">
                          
                        <!--  -->
                       
                                <input type="hidden" name="idPatent" value="1">
                        
                        <!--  -->
                       
                                <input type="hidden" name="idAutor" value="1">
                          
                        <!--  -->
                        
                        

                        <!--fin ndatos  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Ingresar')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
			
			


			<?php echo Form::close(); ?>


		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>