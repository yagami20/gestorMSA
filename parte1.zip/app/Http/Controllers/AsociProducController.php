<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;

use App\producto;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use App\Http\Requests\AplicacionFormRequest;
use phpCAS;

use DB; 
//

class AsociProducController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $request->user()->authorizeRoles(['admin']);
        if ($request)
        {
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $apg=DB::table('productos as tbU')
            ->join('users as tbI', 'tbU.idUser','=','tbI.id')
            ->select('tbU.id','tbU.nombreP as nombreP','tbI.name as nombreU')
            ->where('tbU.nombreP','LIKE','%'.$query.'%')
            ->where('tbI.name','LIKE','%'.$query.'%')
            ->orderBy('tbU.id','desc')
            ->paginate(7);
            return view('GestorMSA.Productos.index',["apg"=>$apg,"searchText"=>$query]);

        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        if ($request->get('tipoProduct')=='1'){
            $fecha= new producto;//llamar
            /* */
            $apg=DB::table('aplicacions as tbU')
            ->select('tbU.tipoSW','tbU.fechaReproduc','tbU.examinar','tbU.DesApp')
            ->where('tbU.id','!=',1)
            ->orderBy('tbU.id','desc')
            ->paginate(1);
            /**/
            $fecha->nombreP=$apg->tipoSW;
            $fecha->idGraf3D='1';
            $fecha->idarchPlano='1';
            $fecha->idApp=$apg->id;
            $fecha->idKit='1';
            $fecha->idUser=$request->get('idUser');
            $fecha->idTarj='1';
            $fecha->idPatent='1';
            $fecha->idAutor='1';

            $fecha->save();
            return Redirect::to('GestorMSA/AsocProduct');
        }
        if ($request->get('tipoProduct')=='2'){
            $fecha= new producto;//llamar
            /* */
            $apg=DB::table('arch_planos as tbU')
            ->select('tbU.TipoArchivo','tbU.fechaGener','tbU.objPlano')
            ->where('tbU.id','!=',1)
            ->orderBy('tbU.id','desc')
            ->paginate(1);
            /**/
            $fecha->nombreP=$apg->TipoArchivo;
            $fecha->idGraf3D='1';
            $fecha->idarchPlano=$apg->id;
            $fecha->idApp='1';
            $fecha->idKit='1';
            $fecha->idUser=$request->get('idUser');
            $fecha->idTarj='1';
            $fecha->idPatent='1';
            $fecha->idAutor='1';

            $fecha->save();
            return Redirect::to('GestorMSA/AsocProduct');
        }
        if ($request->get('tipoProduct')=='3'){
            $fecha= new producto;//llamar
            /* */
            $apg=DB::table('grafico3ds as tbU')
            ->select('tbU.tipoSW','tbU.fechaCreacion','tbU.observacion','tbU.obj3D')
            ->where('tbU.id','!=',1)
            ->orderBy('tbU.id','desc')
            ->paginate(1);
            /**/
            $fecha->nombreP=$apg->tipoSW;
            $fecha->idGraf3D=$apg->id;
            $fecha->idarchPlano='1';
            $fecha->idApp='1';
            $fecha->idKit='1';
            $fecha->idUser=$request->get('idUser');
            $fecha->idTarj='1';
            $fecha->idPatent='1';
            $fecha->idAutor='1';

            $fecha->save();
            return Redirect::to('GestorMSA/AsocProduct');
        }
        if ($request->get('tipoProduct')=='4'){
            $fecha= new producto;//llamar
            /* */
            $apg=DB::table('kit_steams as tbSI')
            ->join('contenido_kits as tbI', 'tbSI.idContenido','=','tbI.id')
            ->join('caja_contenidos as tbSC','tbI.id','=','tbSC.idContenido')
            ->join('cajas as tbC','tbSC.idCaja','=','tbC.id')
            ->select('tbC.nombreC as nombreCaja','tbSI.AutorKit as Autor','tbSI.fechaKit as fecha',
                'tbSI.email as correo','tbI.enlaceWeb as enlace')
            ->where('tbSI.id','!=',1)
            ->orderBy('tbSI.id','desc')
            ->paginate(1);
            /**/
            $fecha->nombreP=$apg->nombreCaja;
            $fecha->idGraf3D='1';
            $fecha->idarchPlano='1';
            $fecha->idApp='1';
            $fecha->idKit=$apg->id;
            $fecha->idUser=$request->get('idUser');
            $fecha->idTarj='1';
            $fecha->idPatent='1';
            $fecha->idAutor='1';

            $fecha->save();
            return Redirect::to('GestorMSA/AsocProduct');
        }
        if ($request->get('tipoProduct')=='5'){
            $fecha= new producto;//llamar
            /* */
            $apg=DB::table('patentes_pr_ps as tbU')
            ->select('tbU.TituloPatent','tbU.fechaPatent','tbU.AutorsPatent','tbU.AppPatent')
            ->where('tbU.id','!=',1)
            ->orderBy('tbU.id','desc')
            ->paginate(1);
            /**/
            $fecha->nombreP=$apg->TituloPatent;
            $fecha->idGraf3D='1';
            $fecha->idarchPlano='1';
            $fecha->idApp='1';
            $fecha->idKit='1';
            $fecha->idUser=$request->get('idUser');
            $fecha->idTarj='1';
            $fecha->idPatent=$apg->id;
            $fecha->idAutor='1';

            $fecha->save();
            return Redirect::to('GestorMSA/AsocProduct');
        }
        if ($request->get('tipoProduct')=='6'){
            $fecha= new producto;//llamar
            /* */
            $apg=DB::table('tarjetas_p_ps as tbU')
            ->select('tbU.NombTarj','tbU.fechaCreacT','tbU.examinar')
            ->where('tbU.id','!=',1)
            ->orderBy('tbU.id','desc')
            ->paginate(1);
            /**/
            $fecha->nombreP=$apg->NombTarj;
            $fecha->idGraf3D='1';
            $fecha->idarchPlano='1';
            $fecha->idApp='1';
            $fecha->idKit='1';
            $fecha->idUser=$request->get('idUser');
            $fecha->idTarj=$apg->id;
            $fecha->idPatent='1';
            $fecha->idAutor='1';

            $fecha->save();
            return Redirect::to('GestorMSA/AsocProduct');
        }
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $prod=producto::findOrFail($id);
        $prod->delete();
        return Redirect::to('GestorMSA/AsocProduct');
    }
}
