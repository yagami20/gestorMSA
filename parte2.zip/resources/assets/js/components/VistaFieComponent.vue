<template>
    <model-collada src="/documentos/arch3D/extract/EDIFICIO-FIE.dae"></model-collada>
</template>

<script>
    import { ModelCollada } from 'vue-3d-model'

    export default {
        components: {
            ModelCollada
        }
        
    }
</script>