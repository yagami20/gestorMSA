<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\NotificacionFormRequest;
use App\notificacionP;

use DB;
//

class notificacionesG extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        //
        $request->user()->authorizeRoles('admin');
        if ($request)
        {
        
            
            $query=trim($request->get('searchText')); //determinr texto de busqueda

            
            $notifG=DB::table('notificacion_ps as tbU')
            ->select('tbU.id','tbU.titulo','tbU.descripcion','tbU.foto','tbU.docNotif','tbU.fechaNotf')
            
            ->where('tbU.titulo','LIKE','%'.$query.'%')
            ->orwhere('tbU.descripcion','LIKE','%'.$query.'%')
            ->orwhere('tbU.fechaNotf','LIKE','%'.$query.'%')

            
            ->orderBy('tbU.id','asc')

            ->paginate(7);

            return view ('GestorMSA.notificaciones.index',["notifG"=>$notifG,"searchText"=>$query]);
            
        } 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        //
        $request->user()->authorizeRoles('admin'); 
        return view ("GestorMSA.notificaciones.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(NotificacionFormRequest $request)
    {
        //
        $notifG=new notificacionP;

        $notifG->titulo=$request->get('titulo');

        $notifG->descripcion=$request->get('descripcion');

        $notifG->fechaNotf=$request->get('fechaNotf');
        
        if (Input::hasFile('foto')){
         $file1=Input::file('foto');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/notifImg/',$nameF1);
         $notifG->foto=$nameF1;
        }

        if (Input::hasFile('docNotif')){
         $file=Input::file('docNotif');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/docNotif/',$nameF);
         $notifG->docNotif=$nameF;
        }

        $notifG->save();

        return Redirect::to('GestorMSA/notificaciones');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        return view("GestorMSA.notificaciones.show");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        //
        $request->user()->authorizeRoles(['admin']);
        $notifG=notificacionP::findOrFail($id);
        return view("GestorMSA.notificaciones.edit",["notifG"=>$notifG]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(NotificacionFormRequest $request, $id)
    {
        //
        $notifG=notificacionP::findOrFail($id);

        $notifG->titulo=$request->get('titulo');

        $notifG->descripcion=$request->get('descripcion');

        $notifG->fechaNotf=$request->get('fechaNotf');
        
        if (Input::hasFile('foto')){
         $file1=Input::file('foto');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/notifImg/',$nameF1);
         $notifG->foto=$nameF1;
        }

        if (Input::hasFile('docNotif')){
         $file=Input::file('docNotif');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/docNotif/',$nameF);
         $notifG->docNotif=$nameF;
        }

        $notifG->save();
        // dd($apg);
        return Redirect::to('GestorMSA/notificaciones');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $notifG=notificacionP::findOrFail($id);
        $notifG->delete();
        return Redirect::to('GestorMSA/notificaciones');
    }

    public function Download($docNotif)
    {
        //
        // if(!$this->downloadFile(public_path().'/documentos/aplicaciones/',$examinar)){
        //     return redirect()->back();
        $pathtoFile = public_path().'/documentos/docNotif/'.$docNotif;
        return response()->download($pathtoFile);
        
    }
}
