<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\NotificacionFormRequest;
use App\notificacionP;
use App\kitSteam;
use App\caja;
use App\cajaContenido;
use App\contenidoKit;

use DB;

class noticiasKitController extends Controller
{
    
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $publicacion=kitSteam::findOrFail($id);
        $contK=contenidoKit::findOrFail($publicacion->idContenido);
        $caja=caja::findOrFail($contK->idCaja);

        return view('GestorPublic.Kit.Noticia',['caja'=>$caja,'publicacion'=>$publicacion,'contK'=>$contK]); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
