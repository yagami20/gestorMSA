<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TarjetasFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
            'DesTarjet'=>'required|string|max:255',
            'AutorTarj'=>'required|string|max:255',
            'QRTarjet'=>'mimes:jpeg,bmp,jpg,png',
            'NombTarj'=>'required|string|max:255',
            'fechaCreacT'=>'required|max:10',
            'fotoApp'=>'mimes:jpeg,bmp,jpg,png',
            'examinar'=>'mimes:rar,zip,pdf'
        ];
    }
}
