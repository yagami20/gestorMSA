<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class aplicacion extends Model
{
    //
    protected $table='aplicacions';

    protected $primaryKey='id'; 
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'tipoSW',

        'fechaReproduc',

        'fotoApp',
        'DesApp',
        'AutorApp',
    	
        'examinar' 
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ];
}
