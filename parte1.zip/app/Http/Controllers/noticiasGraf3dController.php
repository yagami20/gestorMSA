<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\NotificacionFormRequest;
use App\notificacionP;
use App\grafico3d;
use App\aplicacion;

use DB;

class noticiasGraf3dController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $publicacion=grafico3d::findOrFail($id);

        return view('GestorPublic.graf3d.Noticia',['publicacion'=>$publicacion]);
    }

    public function verObj(Request $request,$id)
    {
        //$request->user()->authorizeRoles(['admin']); 
        $graf3d=grafico3d::findOrFail($id);
        if ($graf3d->tipoObj=='1')
        {
            return view('GestorPublic.graf3d.vistaJson',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='2')
        {
            return view('GestorPublic.graf3d.vistaObj',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='4')
        {
            return view('GestorPublic.graf3d.vistaStl',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='5')
        {
            return view('GestorPublic.graf3d.vistaDae',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='6')
        {
            return view('GestorPublic.graf3d.vistaPly',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='7')
        {
            return view('GestorPublic.graf3d.vistaGltf',["graf3d"=>$graf3d]);
        }
        // return view("GestorMSA.Graficos3D.edit",["graf3d"=>$graf3d]);
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
