@extends('nav')
<link rel="stylesheet" href="{{asset('css/botones.css')}}">
<script src="{{ asset('js/app.js') }}" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>
{{--  --}}
<link rel="stylesheet" href="{{ asset('css/base.css') }}">
    <link rel="stylesheet" href="{{ asset('css/layout.css') }}">
    <link rel="stylesheet" href="{{ asset('css/proyectos.css') }}">
   <!-- Favicons
    ================================================== -->
    
    {{-- <link rel="shortcut icon" href="logomenu.ico" > --}}
{{--  --}}

@section('content')
<div class="row section-head"> 
         <div class="col full" align="justify">

<section class="row">
  <article class="col-xs-12 col-md-10 col-lg-10">
    <div id="myTabContent" class="tab-content">
      <div class="tab-pane fade in active show" id="Noticia">
        <!-- Seccion noticias-->
        <div class="container">
          <!-- Blog Post -->
          <div class="card mb-2">
            <div class="card-body"> 
              <div class="row">
                {{-- <div class="col-lg-4" style="width: 300px; height: 300px;"> --}}
                  {{--  --}}
                  <h2 class="card-title" align="justify">Ver: 
                  <a href="{{URL::action('noticiasGraf3dController@verObj',$publicacion->id)}}"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-edit"></i>Obj. 3D</button></a></h2>
                  {{--  --}}
                {{-- </div> --}}
                <div class="col-lg-6">
                  <h2 class="card-title" align="justify">Nombre: {{$publicacion->tipoSW}}</h2>
                  <p class="lead" align="justify">Autor/es: {!! $publicacion->Autorgraf3D !!}</p>
                  <p class="lead" align="justify">{!! $publicacion->Desgraf3D !!}</p>
                  <h2 class="card-title" align="center">Documento: </h2>
                  <p class="lead" align="center"><iframe src="/documentos/arch3D/documentos/<?=  $publicacion->Docgraf3D;   ?>" height="480px" width="450px" align="center"> archivo</iframe></p><br>
                </div>
              </div>
            </div>
            <div class="card-footer text-muted">
              Posted on {{$publicacion->fechaCreacion}}
            </div><!-- Pagination -->
              <ul class="pagination justify-content-center mb-4"></ul>
            </div>
          </div>
        </div>
      </div>
    </article>
  </section>
</div>
</div> 
@endsection