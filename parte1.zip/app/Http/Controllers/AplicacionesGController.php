<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;

use App\aplicacion;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use App\Http\Requests\AplicacionFormRequest;
use phpCAS;

use DB; 
//

class AplicacionesGController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $request->user()->authorizeRoles(['admin']);
        if ($request)
        {
            $query=trim($request->get('searchText')); //determinr texto de busqueda
            $apg=DB::table('aplicacions as tbU')
            ->select('tbU.id','tbU.tipoSW','tbU.fechaReproduc','tbU.examinar', 'tbU.fotoApp','tbU.DesApp','tbU.AutorApp')
            ->where('tbU.tipoSW','LIKE','%'.$query.'%')
            ->where('tbU.AutorApp','LIKE','%'.$query.'%')
            ->orwhere('tbU.fechaReproduc','LIKE','%'.$query.'%')
            ->orderBy('tbU.id','desc')
            ->paginate(7);
            return view('GestorMSA.Aplicaciones.index',["apg"=>$apg,"searchText"=>$query]);

        }
    }
    public function create(Request $request)
    {
        $request->user()->authorizeRoles(['admin']);
        return view ("GestorMSA.Aplicaciones.create");
    }

    
public function store (AplicacionFormRequest $request)
    {
        $apg=new aplicacion;

        $apg->tipoSW=$request->get('tipoSW');

        $apg->DesApp=$request->get('DesApp');

        $apg->AutorApp=$request->get('AutorApp');

        $apg->fechaReproduc=$request->get('fechaReproduc');
        
        if (Input::hasFile('fotoApp')){
         $file1=Input::file('fotoApp');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/software/',$nameF1);
         $apg->fotoApp=$nameF1;
        }

        if (Input::hasFile('examinar')){
         $file=Input::file('examinar');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/aplicaciones/',$nameF);
         $apg->examinar=$nameF;
        }

        $apg->save();

        return Redirect::to('GestorMSA/Aplicaciones');
    }


    
public function show ($id)
    {        
        return view("GestorMSA.Aplicaciones.show"); 
    }

    
public function edit(Request $request,$id)
    {
        $request->user()->authorizeRoles(['admin']);
        $apg=aplicacion::findOrFail($id);
        return view("GestorMSA.Aplicaciones.edit",["apg"=>$apg]);
    }

    
public function update(AplicacionFormRequest $request, $id)
    {
        $apg=aplicacion::findOrFail($id); 

        $apg->tipoSW=$request->get('tipoSW');

        $apg->DesApp=$request->get('DesApp');

        $apg->AutorApp=$request->get('AutorApp');

        $apg->fechaReproduc=$request->get('fechaReproduc');

        if (Input::hasFile('fotoApp')){
         $file1=Input::file('fotoApp');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/software/',$nameF1);
         $apg->fotoApp=$nameF1;
        }

        if (Input::hasFile('examinar')){
         $file=Input::file('examinar');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/aplicaciones/',$nameF);
         $apg->examinar=$nameF;
        }

        $apg->save();
        // dd($apg);
        return Redirect::to('GestorMSA/Aplicaciones');
    }

    

public function destroy($id)
    {
        $apg=aplicacion::findOrFail($id);
        $apg->delete();
        return Redirect::to('GestorMSA/Aplicaciones');
    }
}
