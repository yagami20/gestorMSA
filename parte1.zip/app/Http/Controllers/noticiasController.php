<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\NotificacionFormRequest;
use App\notificacionP;
use App\tarjetasPP;
use App\aplicacion;

use DB;
//

class noticiasController extends Controller
{
    //
    public function edit(Request $request,$id)
    {
        $publicacion=notificacionP::findOrFail($id);

        return view('GestorPublic.notificacion.Noticia',['publicacion'=>$publicacion]);

        
        // ->with('publicacion','$publicacion'); 

    }

    public function edit2(Request $request,$id)
    {
        $publicacion=aplicacion::findOrFail($id);

        return view('GestorPublic.aplicacion.Noticia',['publicacion'=>$publicacion]);

        
        // ->with('publicacion','$publicacion'); 

    }

    public function edit3(Request $request,$id)
    {
        $publicacion=tarjetasPP::findOrFail($id);

        return view('GestorPublic.tarjeta.Noticia',['publicacion'=>$publicacion]);

        
        // ->with('publicacion','$publicacion'); 

    }

    public function destroy($id)
    {

        $publicacion=tbPublicaciones::findOrFail($idPublicacion);

        $publicacion->tbpEstado='0';

        $publicacion->update();

        return Redirect::to('WebExterna/noticias'); 


    }
}
