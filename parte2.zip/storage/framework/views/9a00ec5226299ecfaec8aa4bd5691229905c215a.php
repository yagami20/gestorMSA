<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="<?php echo e(asset('GestorDocente/Almacen')); ?>">Almacen</a>/Agregar Observación
                
            </h5>
			<?php if($band=='1'): ?>
            <h3>Agregar Observación: <?php echo e($tarjetaspp->NombTarj); ?></h3>
            <?php else: ?>
            <h3>Agregar Observación: <?php echo e($caja->nombreC); ?></h3>
            <?php endif; ?>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>

	
			


<form method="POST" action="/GestorDocente/ObservacionD/<?php echo e($prod->id); ?>" enctype="multipart/form-data">
    <?php echo method_field('PUT'); ?> 
    <?php echo csrf_field(); ?>
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>"> -->
                       

                        <div class="form-group row">
                            <label for="nombreA" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Autor Observación ')); ?></label>

                            <div class="col-md-6">
                                <input id="nombreA" type="text" title="Nombre de autor o autores" placeholder="Autor1, Autor2 #..." class="form-control<?php echo e($errors->has('nombreA') ? ' is-invalid' : ''); ?>" name="nombreA" value="<?php echo e(Auth::user()->name); ?>" required autofocus>

                                <?php if($errors->has('nombreA')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('nombreA')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="DocObserv" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cargar Documento (extensión: pdf):')); ?></label>

                            <div class="col-md-6">
                                <input id="DocObserv" type="file" title="Formato de archivo:pdf" name="DocObserv" value="<?php echo e(old('DocObserv')); ?>" required autofocus>

                                <?php if($errors->has('DocObserv')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('DocObserv')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <input type="hidden" name="idProducto" value="<?php echo e($prod->id); ?>">
                        <?php if($band=='1'): ?>
                        <input type="hidden" name="band" value="1">
                        <?php else: ?>
                        <input type="hidden" name="band" value="2">
                        <?php endif; ?>

                            
                        <!--  -->
                        <!--fin ndatos  -->
                        <!--new datos  -->
                        <!--estado  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Agregar')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>