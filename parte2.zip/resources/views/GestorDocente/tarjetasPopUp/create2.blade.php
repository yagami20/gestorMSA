<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-create-{{$tarjetaspp->id='1'}}">
{{Form::Open(array('action'=>array('tarjetaPopUpU@destroy',$tarjetaspp->id='1'),'method'=>'delete'))}}
<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">X</span>
			
		</button>
		<h4 class="modal-title">Nueva Tarjeta</h4>
	</div>
	<div class="modal-body">
		<!--  -->
		<div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right">{{ __('Nombre Tarjeta:') }}</label>

                            <div class="col-md-6">
                                <input id="NombTarj" type="text" placeholder="NombTarj #..." class="form-control{{ $errors->has('NombTarj') ? ' is-invalid' : '' }}" name="NombTarj" value="{{ old('NombTarj') }}" required autofocus>

                                @if ($errors->has('NombTarj'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('NombTarj') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        {{--  --}}
                        <div class="form-group row">
                            <label for="DesTarjet" class="col-md-4 col-form-label text-md-right">{{ __('Descripción de Tarjeta') }}</label>

                            <div class="col-md-6">
                                <input id="DesTarjet" type="text" placeholder="Simulador #..." class="form-control{{ $errors->has('DesTarjet') ? ' is-invalid' : '' }}" name="DesTarjet" value="{{ old('DesTarjet') }}" required autofocus>

                                @if ($errors->has('DesTarjet'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('DesTarjet') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="AutorTarj" class="col-md-4 col-form-label text-md-right">{{ __('Autor/es de Tarjeta') }}</label>

                            <div class="col-md-6">
                                <input id="AutorTarj" type="text" placeholder="Simulador #..." class="form-control{{ $errors->has('AutorTarj') ? ' is-invalid' : '' }}" name="AutorTarj" value="{{ Auth::user()->name }}" required autofocus>

                                @if ($errors->has('AutorTarj'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('AutorTarj') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="fechaCreacT" class="col-md-4 col-form-label text-md-right">{{ __('Fecha creación:') }}</label>

                            <div class="col-md-6">
                                <input id="fechaCreacT" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('fechaCreacT') ? ' is-invalid' : '' }}" name="fechaCreacT" value="{{ old('fechaCreacT') }}" required autofocus>

                                @if ($errors->has('fechaCreacT'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fechaCreacT') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right">{{ __('Cargar Foto:') }}</label>

                            <div class="col-md-6">
                                <input id="fotoApp" type="file" name="fotoApp" value="{{ old('fotoApp') }}" required autofocus>

                                @if ($errors->has('fotoApp'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fotoApp') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="QRTarjet" class="col-md-4 col-form-label text-md-right">{{ __('Cargar codigo QR:') }}</label>

                            <div class="col-md-6">
                                <input id="QRTarjet" type="file" name="QRTarjet" value="{{ old('QRTarjet') }}" required autofocus>

                                @if ($errors->has('QRTarjet'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('QRTarjet') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="examinar" class="col-md-4 col-form-label text-md-right">{{ __('Importar Documentacion:') }}</label>

                            <div class="col-md-6">
                                <input id="examinar" type="file" name="examinar" value="{{ old('examinar') }}" required autofocus>

                                @if ($errors->has('examinar'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('examinar') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idUser" value="{{ Auth::user()->id }}">
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idGraf3D" value=1>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idarchPlano" value=1>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idApp" value=1>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idKit" value=1>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idPatent" value=1>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idAutor" value=1>
                            </div>
                        </div>
                        <!--  -->
		
		
				
				
				<!--  -->
	</div>
	<div class="modal-footer">
		<button type="submit" class="btn btn-primary">Guardar <i class="fa fa-search"></i></button>
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
		
	</div>

	</div>
</div>
{{Form::Close()}}	

</div>