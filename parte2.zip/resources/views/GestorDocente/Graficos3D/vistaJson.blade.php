@extends('layouts.docente')
<script src="{{ asset('js/app.js') }}" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>
@section('content')
{{--  --}}
<h5><a href="{{asset('GestorDocente/Almacen')}}">Almacen</a>/
                <a href="{{asset('GestorDocente/Graficos3D')}}">Graficos 3D</a>/Ver Objeto
            </h5>
<div class="alert alert-warning alert-dismissable">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <strong>¡Aviso!</strong> Al dar clic con el mouse o seleccionar desde un dispositivo movil, sobre el area de trabajo se puede manipular al objeto.
</div>
{{--  --}}
<a href="{{URL::action('GraficosController@download',$graf3d->obj3D)}}"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Descargar</button></a>
<a href="{{asset('GestorDocente/Graficos3D')}}"><button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">atras X</span>
			
		</button></a>
<!-- <archvista-component></archvista-component> -->
<div id="app">
        <model-three src="/documentos/arch3D/extract/<?=  $graf3d->obj3D;   ?>"></model-three>
    </div>
<script>
  new Vue({ el: '#app' });
</script>

@endsection 
