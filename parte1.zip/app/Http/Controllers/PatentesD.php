<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\PatentesFormRequest;
use App\patentesPrP;
use App\producto;

use DB;
//

class PatentesD extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        //
        $request->user()->authorizeRoles('docent');
        if ($request)
        {
        
            
            $query=trim($request->get('searchText')); //determinr texto de busqueda

            
            $patent=DB::table('patentes_pr_ps as tbU')
            ->join('productos as tbI', 'tbU.id','=','tbI.idPatent')
            ->select('tbU.id','tbU.TituloPatent','tbI.id as idProd','tbI.idUser','tbU.ClasePatent','tbU.CertifPatent','tbU.SolicPatent','tbU.ComprovPatent','tbU.AppPatent','tbU.logoApp','tbU.AutorsPatent','tbU.fechaPatent','tbU.DocPatent')
            
            ->where('tbU.TituloPatent','LIKE','%'.$query.'%')
            ->orwhere('tbU.AutorsPatent','LIKE','%'.$query.'%')
            ->orwhere('tbU.ClasePatent','LIKE','%'.$query.'%')
            ->orwhere('tbU.fechaPatent','LIKE','%'.$query.'%')

            
            ->orderBy('tbU.id','desc')

            ->paginate(7);

            return view ('GestorDocente.patentes.index',["patent"=>$patent,"searchText"=>$query]);
            
        } 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        // 
        $request->user()->authorizeRoles('docent');
        return view ("GestorDocente.patentes.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PatentesFormRequest $request)
    {
        //
        $patent=new patentesPrP;

        $patent->TituloPatent=$request->get('TituloPatent');

        $patent->ClasePatent=$request->get('ClasePatent');

        $patent->AutorsPatent=$request->get('AutorsPatent');

        $patent->fechaPatent=$request->get('fechaPatent');

        if (Input::hasFile('DocPatent')){
         $file=Input::file('DocPatent');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/docPatentP/Documento/',$nameF);
         $patent->DocPatent=$nameF;
        }
        
        if (Input::hasFile('logoApp')){
         $file1=Input::file('logoApp');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/imgPatent/logo/',$nameF1);
         $patent->logoApp=$nameF1;
        }

        if (Input::hasFile('AppPatent')){
         $file2=Input::file('AppPatent');
         $nameF2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/docPatentP/AppPatent/',$nameF2);
         $patent->AppPatent=$nameF2;
        }

        if (Input::hasFile('ComprovPatent')){
         $file3=Input::file('ComprovPatent');
         $nameF3=time().$file3->getClientOriginalName();
         $file3->move(public_path().'/imagenes/imgPatent/comprob/',$nameF3);
         $patent->ComprovPatent=$nameF3;
        }

        if (Input::hasFile('SolicPatent')){
         $file4=Input::file('SolicPatent');
         $nameF4=time().$file4->getClientOriginalName();
         $file4->move(public_path().'/documentos/docPatentP/Solicit/',$nameF4);
         $patent->SolicPatent=$nameF4;
        }

        if (Input::hasFile('CertifPatent')){
         $file5=Input::file('CertifPatent');
         $nameF5=time().$file5->getClientOriginalName();
         $file5->move(public_path().'/documentos/docPatentP/CerTP/',$nameF5);
         $patent->CertifPatent=$nameF5;
        }

        $patent->save();
        $this->addProduct($patent->id,$request);

        return Redirect::to('GestorDocente/patentes');
    }

    public function addProduct ($idPatent,$request)
    {
        $fecha= new producto;//llamar
        $fecha->nombreP=$request->get('TituloPatent');
        $fecha->idGraf3D=$request->get('idGraf3D');
        $fecha->idarchPlano=$request->get('idarchPlano');
        $fecha->idApp=$request->get('idApp');
        $fecha->idKit=$request->get('idKit');
        $fecha->idUser=$request->get('idUser');
        $fecha->idTarj=$request->get('idTarj');
        $fecha->idPatent=$idPatent;
        $fecha->idAutor=$request->get('idAutor');

        $fecha->save();
        return Redirect::to('GestorDocente/patentes');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        return view("GestorDocente.patentes.show");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        //
        $request->user()->authorizeRoles(['docent']);
        $prod=producto::findOrFail($id);
        $patent=patentesPrP::findOrFail($prod->idPatent);
        return view("GestorDocente.patentes.edit",["prod"=>$prod,"patent"=>$patent]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PatentesFormRequest $request, $id)
    {
        //
        $patent=patentesPrP::findOrFail($id);

        $patent->TituloPatent=$request->get('TituloPatent');

        $patent->ClasePatent=$request->get('ClasePatent');

        $patent->AutorsPatent=$request->get('AutorsPatent');

        $patent->fechaPatent=$request->get('fechaPatent');

        if (Input::hasFile('DocPatent')){
         $file=Input::file('DocPatent');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/documentos/docPatentP/Documento/',$nameF);
         $patent->DocPatent=$nameF;
        }
        
        if (Input::hasFile('logoApp')){
         $file1=Input::file('logoApp');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/imgPatent/logo/',$nameF1);
         $patent->logoApp=$nameF1;
        }

        if (Input::hasFile('AppPatent')){
         $file2=Input::file('AppPatent');
         $nameF2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/docPatentP/AppPatent/',$nameF2);
         $patent->AppPatent=$nameF2;
        }

        if (Input::hasFile('ComprovPatent')){
         $file3=Input::file('ComprovPatent');
         $nameF3=time().$file3->getClientOriginalName();
         $file3->move(public_path().'/imagenes/imgPatent/comprob/',$nameF3);
         $patent->ComprovPatent=$nameF3;
        }

        if (Input::hasFile('SolicPatent')){
         $file4=Input::file('SolicPatent');
         $nameF4=time().$file4->getClientOriginalName();
         $file4->move(public_path().'/documentos/docPatentP/Solicit/',$nameF4);
         $patent->SolicPatent=$nameF4;
        }

        if (Input::hasFile('CertifPatent')){
         $file5=Input::file('CertifPatent');
         $nameF5=time().$file5->getClientOriginalName();
         $file5->move(public_path().'/documentos/docPatentP/CerTP/',$nameF5);
         $patent->CertifPatent=$nameF5;
        }

        $patent->save();
        $this->modProduct($patent->id,$request);
        // dd($apg);
        return Redirect::to('GestorDocente/patentes');
    }

    public function modProduct ($idPatent,$request)
    {
        $fecha= producto::findOrFail($request->get('idProducto'));
        $fecha->nombreP=$request->get('TituloPatent');

        $fecha->save();
        // $this->addcajaContenido($request,$fecha->id,$idCaja);
        /* */
        
                
        return Redirect::to('GestorDocente/patentes');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        //
        $apg2=producto::findOrFail($request->get('idProd'));
        $idPatent=$apg2->idPatent;
        $apg2->delete();

        $patent=patentesPrP::findOrFail($id);
        $patent->delete();
        return Redirect::to('GestorDocente/patentes');
    }

    public function Download($DocPatent)
    {
        //
        // if(!$this->downloadFile(public_path().'/documentos/aplicaciones/',$examinar)){
        //     return redirect()->back();
        $pathtoFile = public_path().'/documentos/docPatentP/Documento/'.$DocPatent;
        return response()->download($pathtoFile);
        
    }

    public function DownloadApp($AppPatent)
    {
        //
        // if(!$this->downloadFile(public_path().'/documentos/aplicaciones/',$examinar)){
        //     return redirect()->back();
        $pathtoFile = public_path().'/documentos/docPatentP/AppPatent/'.$AppPatent;
        return response()->download($pathtoFile);
        
    }

    public function DownloadSolic($CertifPatent)
    {
        //
        // if(!$this->downloadFile(public_path().'/documentos/aplicaciones/',$examinar)){
        //     return redirect()->back();
        $pathtoFile = public_path().'/documentos/docPatentP/CerTP/'.$CertifPatent;
        return response()->download($pathtoFile);
        
    }
}
