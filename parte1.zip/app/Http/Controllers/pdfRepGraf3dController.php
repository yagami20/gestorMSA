<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//parte llamado

use App\patentesPrP;
use App\grafico3d;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\PatentesFormRequest;
use App\Http\Requests\busquedaAppFormRequest;
use phpCAS;

use DB;
use Fpdf;

class pdfRepGraf3dController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index(Request $request)
    {
        $request->user()->authorizeRoles(['admin']);
        
        $apg=DB::table('grafico3ds as tbU')
            ->select('tbU.id','tbU.fechaCreacion','tbU.obj3D','tbU.Autorgraf3D','tbU.observacion', 'tbU.tipoSW','tbU.tipoObj','tbU.Desgraf3D') 
            ->orderBy('tbU.id','desc')
            ->paginate(7);
        return view ('GestorMSA.Reportes.graf3d.index',["apg"=>$apg]);
    }

    public function show ($id)
    {        
        return view("GestorMSA.Reportes.graf3d.show"); 
    }

   public function create(Request $request)
    {
        $request->user()->authorizeRoles(['admin']);
        
            $apg=DB::table('grafico3ds as tbU')
            ->select('tbU.tipoSW','tbU.fechaCreacion','tbU.observacion','tbU.obj3D')
            ->where('tbU.id','!=',1)
            ->orderBy('tbU.id','desc')
            ->paginate(20);
            $this->bfecha($apg);
    }

public function update(busquedaAppFormRequest $request, $id)
    {

    }


    //
    public function bfecha ($apg)
    {

            Fpdf::AddPage();
            Fpdf::Image('ENCABEZ.JPG',20,20,-100);
            Fpdf::Ln(50);
            Fpdf::SetFont('Arial','B',14);
            Fpdf::Write(5,'Reporte graficos 3D ');
            Fpdf::Ln(10);
            Fpdf::Cell(40,6,'Nombre graf. 3D',1,0,'C');
            Fpdf::Cell(30,6,'Fecha',1,0,'C');
            Fpdf::Cell(70,6,'Observacion',1,0,'C');
            Fpdf::Cell(75,6,'Documento',1,1,'C');
            Fpdf::SetFont('Arial','',10);

        	foreach($apg as $row)
		    {
		    	$j=0;
		        foreach($row as $col){
                 	if($j==2){
                	Fpdf::Cell(70,6,$col,1); 	
                 	}
                 	else{
                 		if($j==1){
                 			Fpdf::Cell(30,6,$col,1,0,'C');
                 		}
                 		else{
                 			if($j==3){
                 				Fpdf::Cell(75,6,$col,1);
                 			}
                 			else{
                 				Fpdf::Cell(40,6,$col,1);	
                 			}
                 			
                 		}
                 		
                 	}
		            
		            $j++;
		            }
		        Fpdf::Ln();
		    }
            
            Fpdf::Output();
            exit;
    }
    public function destroy(busquedaAppFormRequest $request,$id)
    {
        $fecha1=trim($request->get('FechaInicio')); //determinr texto de busqueda

            $fecha2=trim($request->get('FechaFin')); //determinr texto de busqueda
            $f1=date("Y-m-d", strtotime($request->get('FechaInicio')));
            $f2=date("Y-m-d", strtotime($request->get('FechaFin')));
            $fechaI=DB::table('grafico3ds as tbI')
            ->whereBetween('tbI.fechaCreacion',[$f1,$f2])
            ->get();
            if($fechaI)
                {
                    $oficioI=DB::table('grafico3ds as tbU')
                    ->select('tbU.tipoSW','tbU.fechaCreacion','tbU.observacion','tbU.obj3D')
                        ->whereBetween('tbU.fechaCreacion',[$f1,$f2])
                        ->where('tbU.id','!=',1)
                        ->get();
                    // if($oficioI->idOficioI<>'1')
                    // {
                        $this->bfecha($oficioI);
                //fin id
                    // }
            //fin prim if
                }
    }
    public function verObj(Request $request,$id)
    {
        $request->user()->authorizeRoles(['admin']); 
        $graf3d=grafico3d::findOrFail($id);
        if ($graf3d->tipoObj=='1')
        {
            return view('GestorMSA.Reportes.graf3d.vistaJson',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='2')
        {
            return view('GestorMSA.Reportes.graf3d.vistaObj',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='4')
        {
            return view('GestorMSA.Reportes.graf3d.vistaStl',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='5')
        {
            return view('GestorMSA.Reportes.graf3d.vistaDae',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='6')
        {
            return view('GestorMSA.Reportes.graf3d.vistaPly',["graf3d"=>$graf3d]);
        }
        if ($graf3d->tipoObj=='7')
        {
            return view('GestorMSA.Reportes.graf3d.vistaGltf',["graf3d"=>$graf3d]);
        }
        // return view("GestorMSA.Graficos3D.edit",["graf3d"=>$graf3d]);
        
    }
}
