    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<?php $__env->startSection('content'); ?>
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    <h5><a href="<?php echo e(asset('GestorMSA/Almacen')); ?>">Almacen</a>/</h5>
		<h3>Notificación: <a href="notificaciones/create"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Nuevo</button></a></h3><br>

		<h3>Listado de notificaciones</h3>
		<?php echo $__env->make('GestorMSA.notificaciones.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Titulo</th>
                  <th>Fecha de Notificación</th>               
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $notifG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id!='1'): ?> 
                  <td>FIENOTIFMSA<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->titulo); ?></td>
                  <td><?php echo e($usd->fechaNotf); ?></td>
                  <td>
                    <a href="" data-target="#modal-foto-<?php echo e($usd->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Examinar</button></a> 
                    <a href="<?php echo e(URL::action('notificacionesG@edit',$usd->id)); ?>"><button type="button" class="btn btn-outline-info btn-sm"><i class="fa fa-edit"></i> Editar</button></a>
                    <a href="" data-target="#modal-delete-<?php echo e($usd->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-danger btn-sm"><i class="fa fa-user-times"></i> Eliminar</button></a>
                  </td>
                </tr>
                <?php endif; ?>
                <?php echo $__env->make('GestorMSA.notificaciones.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('GestorMSA.notificaciones.modal2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            <?php echo e($notifG->render()); ?>

            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>