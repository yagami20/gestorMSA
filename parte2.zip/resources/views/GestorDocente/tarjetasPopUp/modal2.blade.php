<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-foto-{{$usd->id}}">
{{Form::Open(array('action'=>array('tarjetaPopUpD@Download',$usd->id),'method'=>'delete'))}}
<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">X</span>
			
		</button>
		<h4 class="modal-title">Ver Archivo</h4>
	</div>
	<div class="modal-body">
		
		
				<!--  -->
				<div class="box-body box-profile">
                      <p class="text-muted text-center">Tarjeta Pop Up</p>
                      <p class="text-muted text-center"><img src="{{asset('/imagenes/tarjtPP/img/'.$usd->fotoApp)}}" style="width: 150px; height: 180px" class="img-thumbnail"></p> 
                      <p class="text-muted text-center">Codigo: FIEAPPG{{$usd->id}}</p>
                      <p class="text-muted text-center">Nombre: {{$usd->NombTarj}}</p>
                      <p class="text-muted text-center">Fecha Creación: {{$usd->fechaCreacT}}</p>
                      <p class="text-muted text-center">Descripción: {{$usd->DesTarjet}}</p>
                      <a href="{{URL::action('tarjetaPopUpD@Download',$usd->examinar)}}"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Documento</button></a>
                  </div>
				<!--  -->
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
		
	</div>

	</div>
</div>
{{Form::Close()}}	

</div>