@extends ('layouts.admin')
@section ('content')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="{{asset('GestorMSA/Almacen')}}">Almacen</a>/
                <a href="{{asset('GestorMSA/patentes')}}">Patentes</a>/Crear
            </h5>
			<h3>Nueva Patente/Producto:</h3><br>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>
			{!!Form::open(array('url'=>'GestorMSA/patentes','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			{{Form::token()}} 

		<div class="container">
    <div class="row justify-content-center"> 
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="{{ route('register') }}" aria-label="{{ __('Register') }}"> -->
                        @csrf

                        <div class="form-group row">
                            <label for="TituloPatent" class="col-md-4 col-form-label text-md-right">{{ __('Titulo ') }}</label>

                            <div class="col-md-6">
                                <input id="TituloPatent" type="text" placeholder="Simulador #..." class="form-control{{ $errors->has('TituloPatent') ? ' is-invalid' : '' }}" name="TituloPatent" value="{{ old('TituloPatent') }}" required autofocus>

                                @if ($errors->has('TituloPatent'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('TituloPatent') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="ClasePatent" class="col-md-4 col-form-label text-md-right">{{ __('Descripción ') }}</label>

                            <div class="col-md-6">
                                <input id="ClasePatent" type="text" placeholder="S.W. que genera..." class="form-control{{ $errors->has('ClasePatent') ? ' is-invalid' : '' }}" name="ClasePatent" value="{{ old('ClasePatent') }}" required autofocus>

                                @if ($errors->has('ClasePatent'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('ClasePatent') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right">{{ __('Autor/es:') }}</label>

                            <div class="col-md-6">
                                <input id="AutorsPatent" type="text" placeholder="Autor/es #..." class="form-control{{ $errors->has('AutorsPatent') ? ' is-invalid' : '' }}" name="AutorsPatent" value="{{ old('AutorsPatent') }}" required autofocus>

                                @if ($errors->has('AutorsPatent'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('AutorsPatent') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaPatent" class="col-md-4 col-form-label text-md-right">{{ __('Fecha de registro') }}</label>

                            <div class="col-md-6">
                                <input id="fechaPatent" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('fechaPatent') ? ' is-invalid' : '' }}" name="fechaPatent" value="{{ old('fechaPatent') }}" required autofocus>

                                @if ($errors->has('fechaPatent'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fechaPatent') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="DocPatent" class="col-md-4 col-form-label text-md-right">{{ __('Cargar Documento:') }}</label>

                            <div class="col-md-6">
                                <input id="DocPatent" type="file" name="DocPatent" value="{{ old('DocPatent') }}" required autofocus>

                                @if ($errors->has('DocPatent'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('DocPatent') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="logoApp" class="col-md-4 col-form-label text-md-right">{{ __('Cargar logo de producto:') }}</label>

                            <div class="col-md-6">
                                <input id="logoApp" type="file" name="logoApp" value="{{ old('logoApp') }}" required autofocus>

                                @if ($errors->has('logoApp'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('logoApp') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="AppPatent" class="col-md-4 col-form-label text-md-right">{{ __('Importar aplicación:') }}</label>

                            <div class="col-md-6">
                                <input id="AppPatent" type="file" name="AppPatent" value="{{ old('AppPatent') }}" required autofocus>

                                @if ($errors->has('AppPatent'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('AppPatent') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="ComprovPatent" class="col-md-4 col-form-label text-md-right">{{ __('Cargar foto comprobante ') }}</label>

                            <div class="col-md-6">
                                <input id="ComprovPatent" type="file" name="ComprovPatent" value="{{ old('ComprovPatent') }}" required autofocus>

                                @if ($errors->has('ComprovPatent'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('ComprovPatent') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="SolicPatent" class="col-md-4 col-form-label text-md-right">{{ __('Importar Solicitud ') }}</label>

                            <div class="col-md-6">
                                <input id="SolicPatent" type="file" name="SolicPatent" value="{{ old('SolicPatent') }}" required autofocus>

                                @if ($errors->has('SolicPatent'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('SolicPatent') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="CertifPatent" class="col-md-4 col-form-label text-md-right">{{ __('Importar certificado:') }}</label>

                            <div class="col-md-6">
                                <input id="CertifPatent" type="file" name="CertifPatent" value="{{ old('CertifPatent') }}" required autofocus>

                                @if ($errors->has('CertifPatent'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('CertifPatent') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        
                        

                        <!--fin ndatos  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    {{ __('Ingresar') }}
                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
			
			


			{!!Form::close()!!}

		
@endsection