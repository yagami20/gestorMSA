<?php $__env->startSection('content'); ?>
	<div class="container">
		<center><img style="height: 250px; width: 450px" src="<?php echo e(asset('404Error.jpg')); ?>"></center>
		<center><h1>Esta acción no esta autorizada</h1></center>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>