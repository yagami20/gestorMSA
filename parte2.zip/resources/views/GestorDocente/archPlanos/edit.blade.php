@extends ('layouts.docente')
@section ('content')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="{{asset('GestorDocente/Almacen')}}">Almacen</a>/
                <a href="{{asset('GestorDocente/archPlanos')}}">Archivos Planos</a>/Editar
            </h5>
			<h3>Editar Archivo Plano: FIEARCHPL{{$archP->id}}</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

	
			

<form method="POST" action="/GestorDocente/archPlanos/{{$archP->id}}" enctype="multipart/form-data">
	@method('PUT')
	@csrf
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="{{ route('register') }}" aria-label="{{ __('Register') }}"> -->
                       

                        <div class="form-group row">
                            <label for="TipoArchivo" class="col-md-4 col-form-label text-md-right">{{ __('Nombre del Archivo') }}</label>

                            <div class="col-md-6">
                                <input id="TipoArchivo" type="text" placeholder="Nombre Archivo" class="form-control{{ $errors->has('TipoArchivo') ? ' is-invalid' : '' }}" name="TipoArchivo" value="{{$archP->TipoArchivo}}" required autofocus>

                                @if ($errors->has('TipoArchivo'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('TipoArchivo') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="DesArchP" class="col-md-4 col-form-label text-md-right">{{ __('Descripción del Archivo Plano') }}</label>

                            <div class="col-md-6">
                                <input id="DesArchP" type="text" placeholder="Perteneciente a..." class="form-control{{ $errors->has('DesArchP') ? ' is-invalid' : '' }}" name="DesArchP" value="{{$archP->DesArchP}}" required autofocus>

                                @if ($errors->has('DesArchP'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('DesArchP') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="AutorArchP" class="col-md-4 col-form-label text-md-right">{{ __('Autor/es del Archivo Plano') }}</label>

                            <div class="col-md-6">
                                <input id="AutorArchP" type="text" placeholder="Perteneciente a..." class="form-control{{ $errors->has('AutorArchP') ? ' is-invalid' : '' }}" name="AutorArchP" value="{{$archP->AutorArchP}}" required autofocus>

                                @if ($errors->has('AutorArchP'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('AutorArchP') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaGener" class="col-md-4 col-form-label text-md-right">{{ __('Fecha Generación Arch. Plano') }}</label>

                            <div class="col-md-6">
                                <input id="fechaGener" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('fechaGener') ? ' is-invalid' : '' }}" name="fechaGener" value="{{$archP->fechaGener}}" required autofocus>

                                @if ($errors->has('fechaGener'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fechaGener') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->                       
                        <div class="form-group row">
                            <label for="objPlano" class="col-md-4 col-form-label text-md-right">{{ __('Importar (archivo comprimido en zip):') }}</label>

                            <div class="col-md-6">
                                <input id="objPlano" type="file" name="objPlano" value="{{ old('objPlano') }}" required autofocus>

                                @if ($errors->has('objPlano'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('objPlano') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="DocArchP" class="col-md-4 col-form-label text-md-right">{{ __('Agregar Documento (archivo pdf)') }}</label>

                            <div class="col-md-6">
                                <input id="DocArchP" type="file" name="DocArchP" value="{{ old('DocArchP') }}" required autofocus>

                                @if ($errors->has('DocArchP'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('DocArchP') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="ImgArchP" class="col-md-4 col-form-label text-md-right">{{ __('Agregar Imagen Mapa (extensión: jpeg,bmp,jpg,png)') }}</label>

                            <div class="col-md-6">
                                <input id="ImgArchP" type="file" name="ImgArchP" value="{{ old('ImgArchP') }}" required autofocus>

                                @if ($errors->has('ImgArchP'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('ImgArchP') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="observacion" class="col-md-4 col-form-label text-md-right">{{ __('Nombre del S.W.') }}</label>

                            <div class="col-md-6">
                                <input id="observacion" type="text" placeholder="Nombre Apellido" class="form-control{{ $errors->has('observacion') ? ' is-invalid' : '' }}" name="observacion" value="{{$archP->observacion}}" required autofocus>

                                @if ($errors->has('observacion'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('observacion') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="tipoObjP" class="col-md-4 col-form-label text-md-right">{{ __('Tipo de objeto') }}</label>

                            <div class="col-md-6">
                                <!-- <div class="col-sm-4"> -->
                                              <select name="tipoObjP" class="form-control">
                                                <option value="1">Mapa General</option>
                                                <option value="2" >Mapa Individual</option>
                                            </select>
                                            <!-- </div> -->

                                @if ($errors->has('tipoObjP'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('tipoObjP') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <!--fin ndatos  -->
                        <input type="hidden" name="idProducto" value="{{$prod->id}}">
                        <!--new datos  -->
                        <!--estado  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    {{ __('Enviar') }}
                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
@endsection