@extends('nav')

@section('content')
<div class="row section-head">
         <div class="col full" align="justify">
            <p class="desc" >             
              <h2> MÓDULO: Aeropuerto de Tababela</h2> 
                  <hr></br>               
                  <p>
                    El modelo de avión tanto de manera virtual (a través de Software) y de manera física a través de componentes electromecánicos (sistemas de control) realiza maniobras tanto de parqueo, carretaje, despegue y aterrizaje.   <br>

                  El modelo de avión inicial es un avión comercial TAME: 
                 </p>                                   
            </p>  
                <center>
                  <img style="width: 400px; height: 180px;" src="images/proyecto tren/aeropuerto/aeropuerto1.jpg">
                </center>
            <p>
              La maqueta del  aeropuerto inicialmente fue diseñado desde fotografías y luego modelado en el programa 3D-Max.
            </p>
                <center>
                  <img style="width: 400px; height: 180px;" src="images/proyecto tren/aeropuerto/aeropuerto2.jpg">
                </center><br>
                <center>
                  <img style="width: 400px; height: 180px;" src="images/proyecto tren/aeropuerto/aeropuerto3.jpg"> 
                </center><br>
                <center>
                  <img style="width: 400px; height: 180px;" src="images/proyecto tren/aeropuerto/aeropuerto4.jpg">
                </center>              
            <p>
              Finalmente la maqueta "cobró vida" con la integración de componentes electró-mecánicos con la maqueta física.
            </p>           
          <center>
            <img style="width: 400px; height: 240px;" src="images/proyecto tren/aeropuerto/aeropuerto5.jpg">
          </center><br>
          <center>
           <img style="width: 400px; height: 240px;" src="images/proyecto tren/aeropuerto/aeropuerto6.jpg"> 
          </center><br>
          <center>
            <img style="width: 400px; height: 240px;" src="images/proyecto tren/aeropuerto/aeropuerto7.jpg">
          </center><br>
          <center>
            <img style="width: 400px; height: 240px;" src="images/proyecto tren/aeropuerto/aeropuerto8.jpg">
          </center><br>
          <center>
            <img style="width: 400px; height: 240px;  border-image: initial;" src="images/proyecto tren/aeropuerto/aeropuerto9.jpg">
          </center><br>          
          <button class="regresar">
            <a style="color: white" href="{{asset('/#proyectos')}}">Volver a proyectos</a>
          </button>
  </div>
</div>
@endsection
