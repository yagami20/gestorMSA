@extends ('layouts.user')

    <link rel="stylesheet" href="{{asset('css/botones.css')}}">
@section ('content')
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    <h5><a href="{{asset('GestorUsuario/Almacen')}}">Almacen</a>/Tarjetas Pop-Up</h5>
		<h3>Tarjeta: <a href="tarjetasPopUp/create"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Nuevo</button></a></h3><br>

		<h3>Listado de Tarjetas Pop - Up</h3>
		@include('GestorUsuario.tarjetasPopUp.search')
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Creación</th>                
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($tarjetaspp as $usd)
                  @if ($usd->id!='1') 
                  <td>FIETAPP{{$usd->id}}</td>
                  <td>{{$usd->NombTarj}}</td>
                  <td>{{$usd->AutorTarj}}</td>
                  <td>{{$usd->fechaCreacT}}</td>
                  <td>
                    <a href="" data-target="#modal-foto-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Examinar</button></a>
                    <a href="" data-target="#modal-QR-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-qrcode"></i> CodigoQR</button></a>
                    
                    @if ($usd->idUser== Auth::user()->id )
                    <a href="{{URL::action('tarjetaPopUpU@edit',$usd->idProd)}}"><button type="button" class="btn btn-outline-info btn-sm"><i class="fa fa-edit"></i> Editar</button></a>
                    <a href="" data-target="#modal-delete-{{$usd->idProd}}" data-toggle="modal"><button type="button" class="btn btn-outline-danger btn-sm"><i class="fa fa-user-times"></i> Eliminar</button></a>  
                    @endif
                    @if($usd->idObserv!='1')
                    <a href="" data-target="#modal-DocObserv-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-warning btn-sm"><i class="fa fa-file-image-o"></i> Observación</button></a>
                    @endif
                    
                  </td>
                </tr>
                @endif
                @include('GestorUsuario.tarjetasPopUp.modal')
                @include('GestorUsuario.tarjetasPopUp.modal2')
                @include('GestorUsuario.tarjetasPopUp.modal3')
                @include('GestorUsuario.tarjetasPopUp.modal4')
                @endforeach           
              </table>
            </div>
            {{$tarjetaspp->render()}}
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

@endsection