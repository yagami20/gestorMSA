<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\TarjetasFormRequest;
use App\tarjetasPP;

use DB;
//

class tarjetaPopUpG extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth'); 
    }

    public function index(Request $request)
    {
        //
        $request->user()->authorizeRoles('admin');
        if ($request)
        {
        
            
            $query=trim($request->get('searchText')); //determinr texto de busqueda

            
            $tarjetaspp=DB::table('tarjetas_p_ps as tbU')
            ->select('tbU.id','tbU.DesTarjet','tbU.AutorTarj','tbU.QRTarjet','tbU.NombTarj','tbU.fotoApp','tbU.examinar','tbU.fechaCreacT')
            
            ->where('tbU.NombTarj','LIKE','%'.$query.'%')
            ->orwhere('tbU.DesTarjet','LIKE','%'.$query.'%')
            ->orwhere('tbU.fechaCreacT','LIKE','%'.$query.'%')

            
            ->orderBy('tbU.id','desc')

            ->paginate(7);
            // contador
            /*$users = DB::table('tarjetas_p_ps')
                     ->select(DB::raw('count(*) as tar_count'))
                     // ->where('estado', '<>', 0)
                     // ->groupBy('estado')
                     ->get();

            dd($users); */

            return view ('GestorMSA.tarjetasPopUp.index',["tarjetaspp"=>$tarjetaspp,"searchText"=>$query]);
            
        } 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        // 
        $request->user()->authorizeRoles('admin');
        return view ("GestorMSA.tarjetasPopUp.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TarjetasFormRequest $request)
    {
        //
        $tarjetaspp=new tarjetasPP;

        $tarjetaspp->NombTarj=$request->get('NombTarj');

        $tarjetaspp->DesTarjet=$request->get('DesTarjet');

        $tarjetaspp->AutorTarj=$request->get('AutorTarj');

        $tarjetaspp->fechaCreacT=$request->get('fechaCreacT');
        
        if (Input::hasFile('fotoApp')){
         $file1=Input::file('fotoApp');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/tarjtPP/img/',$nameF1);
         $tarjetaspp->fotoApp=$nameF1; 
        }

        if (Input::hasFile('examinar')){
         $file2=Input::file('examinar');
         $nameF2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/docTarjPP/',$nameF2);
         $tarjetaspp->examinar=$nameF2; 
        }

        if (Input::hasFile('QRTarjet')){
         $file=Input::file('QRTarjet');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/imagenes/tarjtPP/QRimg/',$nameF);
         $tarjetaspp->QRTarjet=$nameF;
        }

        $tarjetaspp->save();

        return Redirect::to('GestorMSA/tarjetaspopup');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        return view("GestorMSA.tarjetasPopUp.show");
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        //
        $request->user()->authorizeRoles(['admin']);
        $tarjetaspp=tarjetasPP::findOrFail($id);
        return view("GestorMSA.tarjetasPopUp.edit",["tarjetaspp"=>$tarjetaspp]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(TarjetasFormRequest $request, $id)
    {
        //
        $tarjetaspp=tarjetasPP::findOrFail($id);

        $tarjetaspp->NombTarj=$request->get('NombTarj');

        $tarjetaspp->DesTarjet=$request->get('DesTarjet');

        $tarjetaspp->AutorTarj=$request->get('AutorTarj');

        $tarjetaspp->fechaCreacT=$request->get('fechaCreacT');
        
        if (Input::hasFile('fotoApp')){
         $file1=Input::file('fotoApp');
         $nameF1=time().$file1->getClientOriginalName();
         $file1->move(public_path().'/imagenes/tarjtPP/img/',$nameF1);
         $tarjetaspp->fotoApp=$nameF1; 
        }

        if (Input::hasFile('examinar')){
         $file2=Input::file('examinar');
         $nameF2=time().$file2->getClientOriginalName();
         $file2->move(public_path().'/documentos/docTarjPP/',$nameF2);
         $tarjetaspp->examinar=$nameF2; 
        }

        if (Input::hasFile('QRTarjet')){
         $file=Input::file('QRTarjet');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/imagenes/tarjtPP/QRimg/',$nameF);
         $tarjetaspp->QRTarjet=$nameF;
        }

        $tarjetaspp->save();
        // dd($apg);
        return Redirect::to('GestorMSA/tarjetaspopup');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $tarjetaspp=tarjetasPP::findOrFail($id);
        $tarjetaspp->delete();
        return Redirect::to('GestorMSA/tarjetaspopup');
    }

    public function Download($examinar)
    {
        //
        // if(!$this->downloadFile(public_path().'/documentos/aplicaciones/',$examinar)){
        //     return redirect()->back();
        $pathtoFile = public_path().'/documentos/docTarjPP/'.$examinar;
        return response()->download($pathtoFile);
        
    }

}
