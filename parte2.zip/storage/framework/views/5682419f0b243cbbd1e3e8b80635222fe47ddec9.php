    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<?php $__env->startSection('content'); ?>
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    
    <h3>Busqueda: </h3>

		 
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <?php if($band=='1'): ?>
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $apg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id!='1'): ?> 
                  <td>FIEAPPG<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->tipoSW); ?></td>
                  <td><?php echo e($usd->AutorApp); ?></td>
                  <td><?php echo e($usd->fechaReproduc); ?></td>
                  
                  <td>
                    <?php if($band=='1'): ?>
                    <a href="<?php echo e(asset('GestorMSA/Aplicaciones')); ?>">Aplicaciones</a>
                    <?php endif; ?>
                    
                    
                    
                  </td>
                </tr>
                <?php endif; ?>
                
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            <?php endif; ?>
            <?php if($band=='2'): ?>
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $apg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id!='1'): ?>
                  <td>FIEARCHPL<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->TipoArchivo); ?></td>
                  <td><?php echo e($usd->AutorArchP); ?></td>
                  <td><?php echo e($usd->fechaGener); ?></td>
                  <td>
                    <?php if($band=='2'): ?>
                    <a href="<?php echo e(asset('GestorMSA/archPlanos')); ?>">Archivos Planos</a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            <?php endif; ?>
            <?php if($band=='3'): ?>
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $apg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id!='1'): ?>
                  <td>FIEOBJ3D<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->tipoSW); ?></td>
                  <td><?php echo e($usd->Autorgraf3D); ?></td>
                  <td><?php echo e($usd->fechaCreacion); ?></td>
                  <td>
                    <?php if($band=='3'): ?>
                    <a href="<?php echo e(asset('GestorMSA/Graficos3D')); ?>">Graficos 3D</a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            <?php endif; ?>
            <?php if($band=='4'): ?>
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $apg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id!='1'): ?>
                  <td>FIEKIT<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->nombreCaja); ?></td>
                  <td><?php echo e($usd->Autor); ?></td>
                  <td><?php echo e($usd->fecha); ?></td>
                  <td>
                    <?php if($band=='4'): ?>
                    <a href="<?php echo e(asset('GestorMSA/kitSTEAM')); ?>">Kit STEAM</a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            <?php endif; ?>
            <?php if($band=='5'): ?>
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $apg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id!='1'): ?>
                  <td>FIENOTIFMSA<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->titulo); ?></td>
                  <td><?php echo e($usd->fechaNotf); ?></td>
                  <td>
                    <?php if($band=='5'): ?>
                    <a href="<?php echo e(asset('GestorMSA/notificaciones')); ?>">Notificaciones</a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            <?php endif; ?>
            <?php if($band=='6'): ?>
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $apg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id!='1'): ?>
                  <td>FIEPAPP<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->TituloPatent); ?></td>
                  <td><?php echo e($usd->AutorsPatent); ?></td>
                  <td><?php echo e($usd->fechaPatent); ?></td>
                  <td>
                    <?php if($band=='6'): ?>
                    <a href="<?php echo e(asset('GestorMSA/patentes')); ?>">Patentes</a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            <?php endif; ?>
            <?php if($band=='7'): ?>
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $apg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id!='1'): ?>
                  <td>FIETAPP<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->NombTarj); ?></td>
                  <td><?php echo e($usd->AutorTarj); ?></td>
                  <td><?php echo e($usd->fechaCreacT); ?></td>
                  <td>
                    <?php if($band=='7'): ?>
                    <a href="<?php echo e(asset('GestorMSA/tarjetaspopup')); ?>">Tarjetas Pop-Up</a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            <?php endif; ?>
            <?php if($band=='8'): ?>
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $apg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id!='1'): ?> 
                  <td>FIEMSA-APP<?php echo e($usd->id); ?></td>
                  <?php if($usd->idApp!='1'): ?>
                  <td><?php echo e($usd->TitApp); ?></td>
                  <?php endif; ?>
                  <?php if($usd->idarchPlano!='1'): ?>
                  <td><?php echo e($usd->TipoArchivo); ?></td>
                  <?php endif; ?>
                  <?php if($usd->idGraf3D!='1'): ?>
                    <td><?php echo e($usd->tipoSW); ?></td>
                  <?php endif; ?>
                  <?php if($usd->idTarj!='1'): ?>
                    <td><?php echo e($usd->NombTarj); ?></td>
                  <?php endif; ?>
                  <?php if($usd->idKit!='1'): ?>
                    <td><?php echo e($usd->nombreC); ?></td>
                  <?php endif; ?>
                  <?php if($usd->idPatent!='1'): ?>
                    <td><?php echo e($usd->TituloPatent); ?></td>
                  <?php endif; ?>
                  
                <td>
                  <?php if($usd->idApp!='1'): ?>
                  <?php echo e($usd->AutorApp); ?>

                  <?php endif; ?>
                  <?php if($usd->idarchPlano!='1'): ?>
                  <?php echo e($usd->AutorArchP); ?>

                  <?php endif; ?>
                  <?php if($usd->idGraf3D!='1'): ?>
                    <?php echo e($usd->Autorgraf3D); ?>

                  <?php endif; ?>
                  <?php if($usd->idTarj!='1'): ?>
                    <?php echo e($usd->AutorTarj); ?>

                  <?php endif; ?>
                  <?php if($usd->idKit!='1'): ?>
                    <?php echo e($usd->AutorKit); ?>

                  <?php endif; ?>
                  <?php if($usd->idPatent!='1'): ?>
                    <?php echo e($usd->AutorsPatent); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <?php if($usd->idApp!='1'): ?>
                  <?php echo e($usd->fechaReproduc); ?>

                  <?php endif; ?>
                  <?php if($usd->idarchPlano!='1'): ?>
                  <?php echo e($usd->fechaGener); ?>

                  <?php endif; ?>
                  <?php if($usd->idGraf3D!='1'): ?>
                    <?php echo e($usd->fechaCreacion); ?>

                  <?php endif; ?>
                  <?php if($usd->idTarj!='1'): ?>
                    <?php echo e($usd->fechaCreacT); ?>

                  <?php endif; ?>
                  <?php if($usd->idKit!='1'): ?>
                    <?php echo e($usd->fechaKit); ?>

                  <?php endif; ?>
                  <?php if($usd->idPatent!='1'): ?>
                    <?php echo e($usd->fechaPatent); ?>

                  <?php endif; ?>
                </td>
                  <td>
                    <?php if($usd->idApp!='1'): ?>
                    <a href="<?php echo e(asset('GestorMSA/Aplicaciones')); ?>">Aplicaciones</a>
                    <?php endif; ?>
                    <?php if($usd->idarchPlano!='1'): ?>
                    <a href="<?php echo e(asset('GestorMSA/archPlanos')); ?>">Archivos Planos</a>
                    <?php endif; ?>
                    <?php if($usd->idGraf3D!='1'): ?>
                    <a href="<?php echo e(asset('GestorMSA/Graficos3D')); ?>">Graficos 3D</a>
                    <?php endif; ?>
                    <?php if($usd->idTarj!='1'): ?>
                    <a href="<?php echo e(asset('GestorMSA/tarjetaspopup')); ?>">Tarjetas Pop-Up</a>
                    <?php endif; ?>
                    <?php if($usd->idKit!='1'): ?>
                    <a href="<?php echo e(asset('GestorMSA/kitSTEAM')); ?>">Kit STEAM</a>
                    <?php endif; ?>
                    <?php if($usd->idPatent!='1'): ?>
                    <a href="<?php echo e(asset('GestorMSA/patentes')); ?>">Patentes</a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            <?php endif; ?>
            <?php echo e($apg->render()); ?>

            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>