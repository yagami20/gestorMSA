@extends('nav')
<script src="{{ asset('js/app.js') }}" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>
@section('content')
<div class="row section-head">
         <div class="col full" align="justify">
            <p class="desc" align="justify" >             
              <center><h2> EDIFICIO 3D: Facultad de Informática y Electrónica </h2></center> 
              {{-- <fieedifvista-component></fieedifvista-component>  --}}
            
        
    
    <div id="app">
        <model-collada src="/documentos/arch3D/extract/EDIFICIO-FIE.dae"></model-collada>
    </div>

		    <script>
		        new Vue({
		            el: '#app'
		        })
		    </script>
                          
            
          
          <button class="regresar">
            <a style="color: white" href="{{asset('/fie')}}">Regresar</a>
          </button>
  </div>
</div>
@endsection
