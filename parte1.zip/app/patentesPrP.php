<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class patentesPrP extends Model
{
    //
    protected $table='patentes_pr_ps';

    protected $primaryKey='id'; 
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'TituloPatent', 

        'ClasePatent',

        'AutorsPatent',

        'fechaPatent',
    	
        'DocPatent',

        'logoApp',

        'AppPatent',

        'ComprovPatent',

        'SolicPatent',
        
        'CertifPatent' 
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ]; 
}
