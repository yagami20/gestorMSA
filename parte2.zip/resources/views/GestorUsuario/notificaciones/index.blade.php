@extends ('layouts.user')

    <link rel="stylesheet" href="{{asset('css/botones.css')}}">
@section ('content')
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>Notificación: </h3><br>

		<h3>Listado de notificaciones</h3>
		@include('GestorUsuario.notificaciones.search')
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Titulo</th>
                  <th>Fecha de Notificación</th>               
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($notifG as $usd)
                  @if ($usd->id!='1') 
                  <td>FIENOTIFMSA{{$usd->id}}</td>
                  <td>{{$usd->titulo}}</td>
                  <td>{{$usd->fechaNotf}}</td>
                  <td>
                    <a href="" data-target="#modal-foto-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Examinar</button></a> 
                    
                    
                  </td>
                </tr>
                @endif
                
                @include('GestorUsuario.notificaciones.modal2')
                @endforeach           
              </table>
            </div>
            {{$notifG->render()}}
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

@endsection