<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/GestorMSA/index', 'otrosController@index')->name('gestorIndex');
Route::get('/GestorP', 'otrosController@indexGestor')->name('gestorP');
Route::get('/Fie3DEdif', 'otrosController@HomeFIE')->name('HomeFIE');
Route::get('/NotificFie', 'otrosController@NotifFIE')->name('NotifFIE');
Route::get('/DescargaFie', 'otrosController@DescargFIE')->name('DescargFIE');

Route::resource('GestorMSA/Usuarios', 'UsuariosController');
Route::resource('GestorMSA/Graficos3D', 'GraficosController'); 
Route::resource('GestorMSA/archPlanos', 'ArchivosPController');
Route::resource('/GestorMSA/Aplicaciones', 'AplicacionesGController');
Route::resource('GestorMSA/kitSTEAM', 'kitSTEAMaController');
Route::resource('/GestorMSA/notificaciones', 'notificacionesG');
Route::resource('GestorMSA/tarjetaspopup', 'tarjetaPopUpG');
Route::resource('GestorMSA/patentes', 'PatentesG');
Route::resource('GestorMSA/PerfilEdit', 'PerfilDController');
Route::resource('GestorMSA/PerfilEditU', 'PerfilUController');
Route::resource('GestorMSA/AsocProduct', 'AsociProducController');
Route::resource('GestorMSA/AsocProduct', 'AsociProducController');
Route::resource('GestorMSA/AsocProduct/AddP', 'AddProducController');
Route::resource('GestorMSA/Almacen', 'AlmacenController');
Route::resource('GestorMSA/BusquedaA', 'metaDatAController');

// docente
Route::get('/GestorDocente/index', 'otrosController@indexD')->name('gestorIndexD');
Route::resource('/GestorDocente/UsuariosD','UserDocController'); 
Route::resource('GestorDocente/AplicacionesD', 'AplicacionesDController');
Route::resource('GestorDocente/archPlanos', 'archPControllerD');
Route::resource('GestorDocente/notificaciones', 'notificacionesD');
Route::resource('GestorDocente/kitSTEAM', 'KitSTEAMdController');
Route::resource('GestorDocente/Graficos3D', 'graficosDController');
Route::resource('GestorDocente/tarjetasPopUp', 'tarjetaPopUpD');
Route::resource('GestorDocente/patentes', 'PatentesD');
Route::resource('GestorDocente/ObservacionD', 'observacionDController');
Route::resource('GestorDocente/Almacen', 'AlmacenDController');
Route::resource('GestorDocente/BusquedaA', 'metaDatDController');
// usuario
Route::get('/GestorUsuario/index', 'otrosController@indexU')->name('gestorIndexU');
Route::resource('/GestorUsuario/UsuariosMSA','UserMSAController');
Route::resource('GestorUsuario/AplicacionesU', 'AplicacionesUController');
Route::resource('GestorUsuario/archPlanos', 'archPControllerU');
Route::resource('GestorUsuario/notificaciones', 'notificacionesU');
Route::resource('GestorUsuario/tarjetasPopUp', 'tarjetaPopUpU');
Route::resource('GestorUsuario/Graficos3D', 'graficosUController');
Route::resource('GestorUsuario/kitSTEAM', 'KitSTEAMuController');
Route::resource('GestorUsuario/patentes', 'PatentesU');
Route::resource('GestorUsuario/Almacen', 'AlmacenUController');
Route::resource('GestorUsuario/BusquedaA', 'metaDatUController');
//ver obj3d
Route::get('GestorMSA/Graficos3D/verObj3D/{id}', 'GraficosController@verObj');
Route::get('GestorMSA/Reportes/graf3d/verObj3D/{id}', 'pdfRepGraf3dController@verObj');
Route::get('GestorDocente/Graficos3D/verObj3D/{id}', 'graficosDController@verObj');
Route::get('GestorDocente/Reportes/graf3d/verObj3D/{id}', 'pdfRepGraf3dDController@verObj');
Route::get('GestorUsuario/Graficos3D/verObj3D/{id}', 'graficosUController@verObj');
Route::resource('GestorMSA/Graficos3D/verArch3D', 'gestor3DController');
//download
Route::get('GestorUsuario/AplicacionesU/download/{examinar}', 'AplicacionesUController@Download');
Route::get('GestorMSA/archPlanos/download/{objPlano}', 'ArchivosPController@download');
Route::get('GestorDocente/archPlanos/download/{objPlano}', 'archPControllerD@download');
Route::get('GestorUsuario/archPlanos/download/{objPlano}', 'archPControllerU@download');
Route::get('GestorMSA/Graficos3D/download/{obj3D}', 'GraficosController@download');
Route::get('GestorUsuario/Graficos3D/download/{obj3D}', 'graficosUController@download');//
Route::get('GestorDocente/Graficos3D/download/{obj3D}', 'graficosDController@download');//
Route::get('GestorMSA/notificaciones/download/{docNotif}', 'notificacionesG@Download');
Route::get('GestorDocente/notificaciones/download/{docNotif}', 'notificacionesD@Download');
Route::get('GestorUsuario/notificaciones/download/{docNotif}', 'notificacionesU@Download');
Route::get('GestorMSA/tarjetaspopup/download/{examinar}', 'tarjetaPopUpG@Download');
Route::get('GestorUsuario/tarjetasPopUp/download/{examinar}', 'tarjetaPopUpU@Download');
Route::get('GestorDocente/tarjetasPopUp/download/{examinar}', 'tarjetaPopUpD@Download');
Route::get('GestorMSA/kitSTEAM/download/{QR}', 'kitSTEAMaController@Download');//aqui
Route::get('GestorMSA/kitSTEAM/downloadP/{planos}', 'kitSTEAMaController@downloadPlano');
Route::get('GestorMSA/kitSTEAM/downloadV/{tutoDigital}', 'kitSTEAMaController@downloadVideo');

Route::get('GestorUsuario/kitSTEAM/download/{QR}', 'KitSTEAMuController@Download');//aqui
Route::get('GestorUsuario/kitSTEAM/downloadP/{planos}', 'KitSTEAMuController@downloadPlano');
Route::get('GestorUsuario/kitSTEAM/downloadV/{tutoDigital}', 'KitSTEAMuController@downloadVideo');

Route::get('GestorDocente/kitSTEAM/download/{QR}', 'KitSTEAMdController@Download');//aqui
Route::get('GestorDocente/kitSTEAM/downloadP/{planos}', 'KitSTEAMdController@downloadPlano');
Route::get('GestorDocente/kitSTEAM/downloadV/{tutoDigital}', 'KitSTEAMdController@downloadVideo');

Route::get('GestorMSA/patentes/download/{examinar}', 'PatentesG@DownloadApp');
Route::get('GestorMSA/patentes/cert/{CertifPatent}', 'PatentesG@DownloadSolic');

Route::get('GestorUsuario/patentes/download/{examinar}', 'PatentesU@DownloadApp');
Route::get('GestorUsuario/patentes/cert/{CertifPatent}', 'PatentesU@DownloadSolic');

Route::get('GestorDocente/patentes/download/{examinar}', 'PatentesD@DownloadApp');
Route::get('GestorDocente/patentes/cert/{CertifPatent}', 'PatentesD@DownloadSolic');
Route::get('GestorDocente/ObservacionD/download/{id}', 'observacionDController@download');
//frontEnd


//reportes
Route::resource('GestorMSA/Reportes/aplicacion','pdfRepAppController'); 
Route::get('GestorMSA/Reportes/aplicacion/generar', 'pdfRepAppController@buscar');
Route::resource('GestorMSA/Reportes/archplano','pdfRepArchPController');
Route::get('GestorMSA/Reportes/archplano/download/{objPlano}', 'pdfRepArchPController@download');
Route::resource('GestorMSA/Reportes/patente','pdfRepPatenteController');
Route::resource('GestorMSA/Reportes/tarjeta','pdfRepTarjetController');
Route::resource('GestorMSA/Reportes/kitsteam','pdfRepKitController');
Route::resource('GestorMSA/Reportes/usuarios','pdfRepUserController');
Route::resource('GestorMSA/Reportes/graf3d','pdfRepGraf3dController');

//reporteDocente
Route::resource('GestorDocente/Reportes/aplicacion','pdfRepAppDController');
Route::get('GestorDocente/Reportes/aplicacion/generar', 'pdfRepAppDController@buscar');
Route::resource('GestorDocente/Reportes/archplano','pdfRepArchPDController');
Route::get('GestorDocente/Reportes/archplano/download/{objPlano}', 'pdfRepArchPDController@download');
Route::resource('GestorDocente/Reportes/patente','pdfRepPatenteDController');
Route::resource('GestorDocente/Reportes/tarjeta','pdfRepTarjetDController');
Route::resource('GestorDocente/Reportes/kitsteam','pdfRepKitDController');
Route::resource('GestorDocente/Reportes/graf3d','pdfRepGraf3dDController');

//cas
Route::get('/cas/protected/', 'otrosController@indexCas')->name('authCAS');
//front end
Route::get('/aeromodelismo','ProyectosController@aeroIndex')->name('aeromodelismo');
Route::get('/trendulzura','ProyectosController@trenDulzuraIndex')->name('trendulzura');
Route::get('/aeropuerto','ProyectosController@aeropuertoIndex')->name('aeropuerto');
Route::get('/buque','ProyectosController@buqueGuayasIndex')->name('buque');
Route::get('/europaAuto','ProyectosController@europaAutoIndex')->name('europaAuto');
Route::get('/juegueteseducativos','ProyectosController@juguetesEducativosIndex')->name('juegueteseducativos');
Route::get('/treninteractivo','ProyectosController@trenInteractivoIndex')->name('treninteractivo');
Route::get('/#proyectos','ProyectosController@volverIndex')->name('/#proyectos');
Route::get('/fie','ProyectosController@fieEdifIndex')->name('fieEdif');
Route::get('GestorPublic/notificacion/{id}', 'noticiasController@article');
Route::resource('/GestorPublic/notificacion', 'noticiasController');
Route::resource('/GestorPublic/aplicacion', 'noticiasAppController');
Route::resource('/GestorPublic/tarjeta', 'noticiasTarjController');
Route::resource('/GestorPublic/archPlano', 'noticiasArchPController');
Route::resource('/GestorPublic/graf3d', 'noticiasGraf3dController');
Route::get('/GestorPublic/graf3d/verObj3D/{id}', 'noticiasGraf3dController@verObj');
Route::resource('/GestorPublic/Kit', 'noticiasKitController');
