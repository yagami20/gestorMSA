<link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>

<link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/layout.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/proyectos.css')); ?>">
   <!-- Favicons
    ================================================== -->
    
    


<?php $__env->startSection('content'); ?>
<div class="row section-head"> 
         <div class="col full" align="justify">

<section class="row">
  <article class="col-xs-12 col-md-10 col-lg-10">
    <div id="myTabContent" class="tab-content">
      <div class="tab-pane fade in active show" id="Noticia">
        <!-- Seccion noticias-->
        <div class="container">
          <!-- Blog Post -->
          <div class="card mb-2">
            <div class="card-body"> 
              <div class="row">
                <div class="col-lg-4" style="width: 300px; height: 300px;">
                  <a href="#"><img  src="<?php echo e(asset('/imagenes/kitSTEAM/QRkit/'.$caja->codQR)); ?>" alt="<?php echo e($caja->id); ?>"  style="width: 300px; height: 300px;" class="img-responsive img-thumbnail"></a>
                </div>
                <div class="col-lg-6">
                  <h2 class="card-title" align="justify">Nombre: <?php echo e($caja->nombreC); ?></h2>
                  <p class="lead" align="justify">Autor/es: <?php echo $publicacion->AutorKit; ?></p>
                  <p class="lead" align="justify">URL: <?php echo $contK->enlaceWeb; ?>

                    
                  </p>
                  <h2 class="card-title" align="center">Documento: </h2>
                  <p class="lead" align="center"><iframe src="/documentos/kitSTEAM/piezaKit/<?=  $contK->piezaArmar;   ?>" height="480px" width="450px" align="center"> archivo</iframe></p><br>
                  <div class="box-body box-profile">
                    <video width="100%" height="50%" controls>
                <source src="/documentos/kitSTEAM/tutKit/extract/<?=  $contK->tutoDigital;   ?>" type="video/mp4">
                Your browser does not support the video tag.
            </video>

                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer text-muted">
              Posted on <?php echo e($publicacion->fechaKit); ?>

            </div><!-- Pagination -->
              <ul class="pagination justify-content-center mb-4"></ul>
            </div>
          </div>
        </div>
      </div>
    </article>
  </section>
</div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>