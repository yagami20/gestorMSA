<?php

use Illuminate\Database\Seeder;
use gestorMSA\grafico3d;

class graf3DSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $gf3= new grafico3d();
        $gf3->fechaCreacion = "2019-01-01";
        $gf3->Desgraf3D="sin descrip";
        $gf3->obj3D = "N/A";
        $gf3->observacion = "sin Observ";
        $gf3->tipoSW = "n/a";
        $gf3->tipoObj = "1"; 
        $gf3->save(); 
    }
}
