@extends ('layouts.admin')

    <link rel="stylesheet" href="{{asset('css/botones.css')}}">
    <script src="{{ asset('js/app.js') }}" defer></script>

@section ('content')

<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    <h5><a href="{{asset('GestorMSA/Almacen')}}">Almacen</a>/Archivos Planos</h5>
		<h3>Archivo Plano: <a href="archPlanos/create"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Nuevo</button></a></h3>
		<h3>Listado de Archivos Planos</h3>
		@include('GestorMSA.archPlanos.search')
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Código</th>
                  <th>NombreArchivo</th>
                  <th>Autor/es</th>
		 			        <th>fechaGener</th>
                  <th>objPlano</th>
                  <th>observacion</th>
                  <th>tipoObjP</th>                
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                	@foreach ($archP as $usd)
                  @if ($usd->id!='1')
                  <td>FIEARCHPL{{$usd->id}}</td>
        		 			<td>{{$usd->TipoArchivo}}</td>
                  <td>{{$usd->AutorArchP}}</td>
                  <td>{{$usd->fechaGener}}</td>
                  <td>{{$usd->objPlano}}</td>
                  <td>{{$usd->observacion}}</td>
                  <td>{{$usd->tipoObjP}}</td>
                  <td>
                    <a href="" data-target="#modal-foto-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Examinar</button></a>
                    <a href="" data-target="#modal-solic-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Documento</button></a>
                    <a href="{{URL::action('ArchivosPController@edit',$usd->id)}}"><button type="button" class="btn btn-outline-info btn-sm"><i class="fa fa-edit"></i> Editar</button></a>
                    <a href="" data-target="#modal-delete-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-danger btn-sm"><i class="fa fa-user-times"></i> Eliminar</button></a>
                  </td> 
                </tr>
                @endif
                @include('GestorMSA.archPlanos.modal2')
                @include('GestorMSA.archPlanos.modal4')
                @include('GestorMSA.archPlanos.modal')
                @endforeach                
              </table>
            </div>
            {{$archP->render()}}
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

@endsection