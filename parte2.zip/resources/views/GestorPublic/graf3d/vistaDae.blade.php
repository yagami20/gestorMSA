@extends('nav')
<link rel="stylesheet" href="{{asset('css/botones.css')}}">
<script src="{{ asset('js/app.js') }}" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>
{{--  --}}
<link rel="stylesheet" href="{{ asset('css/base.css') }}">
    <link rel="stylesheet" href="{{ asset('css/layout.css') }}">
    <link rel="stylesheet" href="{{ asset('css/proyectos.css') }}">
@section('content')

{{--  --}}
<div class="alert alert-warning alert-dismissable">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <strong>¡Aviso!</strong> Al dar clic con el mouse o seleccionar desde un dispositivo movil, sobre el area de trabajo se puede manipular al objeto.
</div>
{{--  --}}
<!-- <archvista-component></archvista-component> -->
<div id="app">
        <model-collada src="/documentos/arch3D/extract/<?=  $graf3d->obj3D;   ?>" ></model-collada>
    </div>
<script>
  new Vue({ el: '#app' });
</script>
<a href="{{asset('/DescargaFie')}}"><button type="button" class="btn btn-outline-dark btn-sm">
			<span aria-hidden="true">atras X</span>
</button></a>
@endsection
