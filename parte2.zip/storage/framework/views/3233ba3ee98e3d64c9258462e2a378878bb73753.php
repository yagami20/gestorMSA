<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Notificación: <?php echo e($notifG->titulo); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>

	
			


<form method="POST" action="/GestorDocente/notificaciones/<?php echo e($notifG->id); ?>" enctype="multipart/form-data">
    <?php echo method_field('PUT'); ?> 
    <?php echo csrf_field(); ?>
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>"> -->
                       

                        <div class="form-group row">
                            <label for="titulo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre del S.W.')); ?></label>

                            <div class="col-md-6">
                                <input id="titulo" type="text" placeholder="Nombre Apellido" class="form-control<?php echo e($errors->has('titulo') ? ' is-invalid' : ''); ?>" name="titulo" value="<?php echo e($notifG->titulo); ?>" required autofocus>

                                <?php if($errors->has('titulo')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('titulo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="descripcion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Descripción Notificación')); ?></label>

                            <div class="col-md-6">
                                <input id="descripcion" type="text" placeholder="Descripción" class="form-control<?php echo e($errors->has('descripcion') ? ' is-invalid' : ''); ?>" name="descripcion" value="<?php echo e($notifG->descripcion); ?>" required autofocus>

                                <?php if($errors->has('descripcion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaNotf" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha:')); ?></label>

                            <div class="col-md-6">
                                <input id="fechaNotf" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control<?php echo e($errors->has('fechaNotf') ? ' is-invalid' : ''); ?>" name="fechaNotf" value="<?php echo e($notifG->fechaNotf); ?>" required autofocus>

                                <?php if($errors->has('fechaNotf')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fechaNotf')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="foto" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Importar foto:')); ?></label>

                            <div class="col-md-6">
                                <input id="foto" type="file" name="foto" value="<?php echo e(old('foto')); ?>" required autofocus>

                                <?php if($errors->has('foto')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('foto')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->                        
                        <div class="form-group row">
                            <label for="docNotif" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Importar Documentación:')); ?></label>

                            <div class="col-md-6">
                                <input id="docNotif" type="file" name="docNotif" value="<?php echo e(old('docNotif')); ?>" required autofocus>

                                <?php if($errors->has('docNotif')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('docNotif')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        

                        <!--fin ndatos  -->
                        <!--new datos  -->
                        <!--estado  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Enviar')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>