 @extends('nav')

 @section('content')
<div class="row section-head">
         <div class="col full" align="justify">
            <p class="desc" align="justify" >             
              <h2> MÓDULO: Ruta de trenes interactivo</h2> 
                  <hr></br>             
                  <p>
                    En este modulo se presenta la ruta del ferrocarril de Ecuador del tramo Riobamba - Quito. <br>
                    Se construyeron los siguientes elementos:
                    <ul>
                      <li>➤ Maqueta en escala 1: 87 de la Estación de Riobamba (cuna del tren de Ecuador).</li>
                      <li>➤ Maqueta de la Estación de Urbina (situada en la parte mas alta los Andes Ecuatoriano).</li>
                      <li>➤ Maqueta de la Estación de Latacunga (famosa ciudad por su deliciosas allullas).</li>
                      <li>➤ Maqueta de la Estación de Quito (En el barrio tradicional de Chimbacalle).</li>
                    </ul>
                  La maqueta contiene trenes eléctricos en la escala HO, los cuales son controlados por un sistema de "touch screen" tanto para una pantalla táctil como para dispositivos móviles.
                  </p>             
          <center>
            <div id="intro-slider" class="flexslider" >
                <ul class="slides"  >
                   <!-- Slide -->
                       <li>
                         <div class="row">
                           <div class="col full">
                                <img src="images/proyecto tren/ruta trenes/ti1.png" style=" width: 440px; height: 326px;">
                           </div>
                         </div>
                       </li>
                  <!-- Slide -->
                       <li>
                         <div class="row">
                          <div class="col full">
                                <img src="images/proyecto tren/ruta trenes/ti2.jpg" style=" height: 326px;">
                          </div>
                         </div>
                       </li>
                  <!-- Slide -->
                       <li>
                         <div class="row">
                            <div class="col full">
                                  <img src="images/proyecto tren/ruta trenes/ti3.jpg" style=" width: 450px; height: 326px;" >
                             </div>
                         </div>
                       </li>
                  <!-- Slide -->
                       <li>
                         <div class="row">
                           <div class="col full">
                                <img src="images/proyecto tren/ruta trenes/ti4.jpg" style=" width: 580px; height: 326px;">
                             </div>
                         </div>
                       </li>
                  <!-- Slide -->
                       <li>
                        <div class="row">
                           <div class="col full">
                             <img src="images/proyecto tren/ruta trenes/ti5.jpg" style=" width: 580px; height: 326px;">
                           </div>
                         </div>
                       </li>
                     </ul>
                   </div>
              <!-- Flexslider End-->
          </center>
          <button class="regresar">
            <a style="color: white" href="{{asset('/#proyectos')}}">Volver a proyectos</a>
          </button>
          </div>
</div>
  <!-- Flexslider Start-->
@endsection