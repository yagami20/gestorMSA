@extends('nav')
<script src="{{ asset('js/app.js') }}" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>
{{--  --}}
  <link rel="stylesheet" href="{{asset('css/estilos.css')}}">
  <link rel="stylesheet" href="{{asset('css/bootstrap.css')}}">
  <link href="{{asset('lib/lightbox/css/lightbox.min.css')}}" rel="stylesheet">
  <link rel="stylesheet" href="{{asset('css/view/font-awesome/css/font-awesome.min.css')}}">
  <script src="{{asset('lib/jquery/jquery.min.js')}}"></script>
  <script src="{{asset('lib/jquery/jquery-migrate.min.js')}}"></script>
  <script src="{{asset('lib/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('lib/easing/easing.min.js')}}"></script>
  <script src="{{asset('lib/superfish/hoverIntent.js')}}"></script>
  <script src="{{asset('lib/superfish/superfish.min.js')}}"></script>
  <script src="{{asset('lib/wow/wow.min.js')}}"></script>
  <script src="{{asset('lib/waypoints/waypoints.min.js')}}"></script>
  <script src="{{asset('lib/counterup/counterup.min.js')}}"></script>
  <script src="{{asset('lib/owlcarousel/owl.carousel.min.js')}}"></script>
  <script src="{{asset('lib/isotope/isotope.pkgd.min.js')}}"></script>
  <script src="{{asset('lib/lightbox/js/lightbox.min.js')}}"></script>
  <script src="{{asset('lib/touchSwipe/jquery.touchSwipe.min.js')}}"></script>
 {{--  --}}
@section('content')
{{-- <div class="row section-head">
         <div class="col full" align="justify"> --}}
            <p class="desc" align="justify" >             
              <center><h2> Descargas: Facultad de Informática y Electrónica </h2></center>
              <br>
        <center><h2> Aplicaciones:</h2></center>
<section id="portfolio"   >
      	{{-- <div class="container">  --}}
      		<div class="row portfolio-container">
      			@forelse($sliders as $slider )
      			<div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
      				<div class="portfolio-wrap">
      					<figure>
			                <img class="d-block img-fluid" src="{{asset('/imagenes/software/'.$slider->fotoApp)}}"  alt="">
			                <a href="{{asset('/imagenes/software/'.$slider->fotoApp)}}" data-lightbox="portfolio" data-title="App 1" class="link-preview" title="Preview"><i class="fa fa-5x fa-eye"></i></a>
			                <a href="{{URL::action('noticiasAppController@edit',$slider->id)}}" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
              			</figure>
              			<div class="portfolio-info">
			            	<h6 align="left"><a>{{substr($slider->tipoSW,0,50).'...'}}</a></h6>
			            </div>
            		</div>
            	</div>
            	@empty
            	@endforelse
            </div>
        {{-- </div> --}}
    </section>
{{-- sec2 --}}
<center><h2> Tarjetas: </h2></center>
<section id="portfolio"   >
      	{{-- <div class="container">  --}}
      		<div class="row portfolio-container">
      			@forelse($sliders2 as $slider2 )
      			<div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
      				<div class="portfolio-wrap">
      					<figure>
			                <img class="d-block img-fluid" src="{{asset('/imagenes/tarjtPP/img/'.$slider2->fotoApp)}}"  alt="">
			                <a href="{{asset('/imagenes/tarjtPP/QRimg/'.$slider2->QRTarjet)}}" data-lightbox="portfolio" data-title="App 1" class="link-preview" title="Preview"><i class="fa fa-5x fa-eye"></i></a>
			                <a href="{{URL::action('noticiasTarjController@edit',$slider2->id)}}" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
              			</figure>
              			<div class="portfolio-info">
			            	<h6 align="left"><a>{{substr($slider2->NombTarj,0,50).'...'}}</a></h6>
			            </div>
            		</div>
            	</div>
            	@empty
            	@endforelse
            </div>
        {{-- </div> --}}
    </section>
<center><h2> Archivos Planos: </h2></center>
<section id="portfolio"   >
        {{-- <div class="container">  --}}
          <div class="row portfolio-container">
            @forelse($sliders3 as $slider3 )
            <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
              <div class="portfolio-wrap">
                <figure>
                      <img class="d-block img-fluid" src="{{asset('/imagenes/archPlanos/'.$slider3->ImgArchP)}}"  alt="">
                      <a href="{{asset('/imagenes/archPlanos/'.$slider3->ImgArchP)}}" data-lightbox="portfolio" data-title="App 1" class="link-preview" title="Preview"><i class="fa fa-5x fa-eye"></i></a>
                      <a href="{{URL::action('noticiasArchPController@edit',$slider3->id)}}" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
                    </figure>
                    <div class="portfolio-info">
                    <h6 align="left"><a>{{substr($slider3->TipoArchivo,0,50).'...'}}</a></h6>
                  </div>
                </div>
              </div>
              @empty
              @endforelse
            </div>
        {{-- </div> --}}
    </section>
<center><h2> Graficos 3D: </h2></center>
<section id="portfolio"   >
        {{-- <div class="container">  --}}
          <div class="row portfolio-container">
            @forelse($sliders4 as $slider4 )
            <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
              <div class="portfolio-wrap">
                <figure>
                      <img class="d-block img-fluid" src="{{-- {{asset('/imagenes/archPlanos/'.$slider4->ImgArchP)}} --}}"  alt="">
                      
                      <a href="{{URL::action('noticiasGraf3dController@edit',$slider4->id)}}" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
                    </figure>
                    <div class="portfolio-info">
                    <h6 align="left"><a>{{substr($slider4->tipoSW,0,50).'...'}}</a></h6>
                  </div>
                </div>
              </div>
              @empty
              @endforelse
            </div>
        {{-- </div> --}}
    </section>

<center><h2> Kit STEAM: </h2></center>
<section id="portfolio"   >
        {{-- <div class="container">  --}}
          <div class="row portfolio-container">
            @forelse($sliders5 as $slider5 )
            <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
              <div class="portfolio-wrap">
                <figure>
                      <img class="d-block img-fluid" src="{{asset('/imagenes/kitSTEAM/portadaKit/'.$slider5->Portada)}}"  alt="">
                      <a href="{{asset('/imagenes/kitSTEAM/portadaKit/'.$slider5->Portada)}}"  data-lightbox="portfolio" data-title="App 1" class="link-preview" title="Preview"><i class="fa fa-5x fa-eye"></i></a>
                      <a href="{{URL::action('noticiasKitController@edit',$slider5->id)}}" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
                    </figure>
                    <div class="portfolio-info">
                    <h6 align="left"><a>{{substr($slider5->nombreCaja,0,50).'...'}}</a></h6>
                  </div>
                </div>
              </div>
              @empty
              @endforelse
            </div>
        {{-- </div> --}}
    </section>
{{-- </div>
</div> --}}
@endsection
