@extends ('layouts.admin')

    <link rel="stylesheet" href="{{asset('css/botones.css')}}">
@section ('content')
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    <h5><a href="{{asset('GestorMSA/Almacen')}}">Almacen</a>/Reporte Aplicaciones</h5>
		<h3>Reporte General Aplicación: <a href="aplicacion/create"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Generar</button></a>
    <a href="" data-target="#modal-foto-{{$apg->id='1'}}" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Buscar</button></a></h3>
    @include('GestorMSA.Reportes.aplicacion.modal2')

		
		{{-- @include('GestorMSA.Reportes.aplicacion.search') --}}
    <h3>Listado de Aplicaciones</h3> 
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th>S.W.</th>                
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($apg as $usd)
                  @if ($usd->id!='1') 
                  <td>FIEAPPG{{$usd->id}}</td>
                  <td>{{$usd->tipoSW}}</td>
                  <td>{{$usd->AutorApp}}</td>
                  <td>{{$usd->fechaReproduc}}</td>
                  <td>{{$usd->examinar}}</td>
                  <td>
                    <a href="" data-target="#modal-foto-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Examinar</button></a> 
                    
                  </td>
                </tr>
                @endif
                @include('GestorMSA.Aplicaciones.modal')
                @include('GestorMSA.Aplicaciones.modal2')
                @endforeach           
              </table>
            </div>
            {{$apg->render()}}
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

@endsection