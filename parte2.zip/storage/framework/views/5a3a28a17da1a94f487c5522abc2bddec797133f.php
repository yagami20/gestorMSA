<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<script src="https://unpkg.com/vue-3d-model/dist/vue-3d-model.umd.js"></script>

  <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
  <link href="<?php echo e(asset('lib/lightbox/css/lightbox.min.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('css/view/font-awesome/css/font-awesome.min.css')); ?>">
  <script src="<?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery/jquery-migrate.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/easing/easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/superfish/hoverIntent.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/superfish/superfish.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/wow/wow.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/waypoints/waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/counterup/counterup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/isotope/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/lightbox/js/lightbox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/touchSwipe/jquery.touchSwipe.min.js')); ?>"></script>
 
<?php $__env->startSection('content'); ?>

            <p class="desc" align="justify" >             
              <center><h2> Descargas: Facultad de Informática y Electrónica </h2></center>
              <br>
        <center><h2> Aplicaciones:</h2></center>
<section id="portfolio"   >
      	
      		<div class="row portfolio-container">
      			<?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      			<div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
      				<div class="portfolio-wrap">
      					<figure>
			                <img class="d-block img-fluid" src="<?php echo e(asset('/imagenes/software/'.$slider->fotoApp)); ?>"  alt="">
			                <a href="<?php echo e(asset('/imagenes/software/'.$slider->fotoApp)); ?>" data-lightbox="portfolio" data-title="App 1" class="link-preview" title="Preview"><i class="fa fa-5x fa-eye"></i></a>
			                <a href="<?php echo e(URL::action('noticiasAppController@edit',$slider->id)); ?>" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
              			</figure>
              			<div class="portfolio-info">
			            	<h6 align="left"><a><?php echo e(substr($slider->tipoSW,0,50).'...'); ?></a></h6>
			            </div>
            		</div>
            	</div>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            	<?php endif; ?>
            </div>
        
    </section>

<center><h2> Tarjetas: </h2></center>
<section id="portfolio"   >
      	
      		<div class="row portfolio-container">
      			<?php $__empty_1 = true; $__currentLoopData = $sliders2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      			<div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
      				<div class="portfolio-wrap">
      					<figure>
			                <img class="d-block img-fluid" src="<?php echo e(asset('/imagenes/tarjtPP/img/'.$slider2->fotoApp)); ?>"  alt="">
			                <a href="<?php echo e(asset('/imagenes/tarjtPP/QRimg/'.$slider2->QRTarjet)); ?>" data-lightbox="portfolio" data-title="App 1" class="link-preview" title="Preview"><i class="fa fa-5x fa-eye"></i></a>
			                <a href="<?php echo e(URL::action('noticiasTarjController@edit',$slider2->id)); ?>" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
              			</figure>
              			<div class="portfolio-info">
			            	<h6 align="left"><a><?php echo e(substr($slider2->NombTarj,0,50).'...'); ?></a></h6>
			            </div>
            		</div>
            	</div>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            	<?php endif; ?>
            </div>
        
    </section>
<center><h2> Archivos Planos: </h2></center>
<section id="portfolio"   >
        
          <div class="row portfolio-container">
            <?php $__empty_1 = true; $__currentLoopData = $sliders3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
              <div class="portfolio-wrap">
                <figure>
                      <img class="d-block img-fluid" src="<?php echo e(asset('/imagenes/archPlanos/'.$slider3->ImgArchP)); ?>"  alt="">
                      <a href="<?php echo e(asset('/imagenes/archPlanos/'.$slider3->ImgArchP)); ?>" data-lightbox="portfolio" data-title="App 1" class="link-preview" title="Preview"><i class="fa fa-5x fa-eye"></i></a>
                      <a href="<?php echo e(URL::action('noticiasArchPController@edit',$slider3->id)); ?>" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
                    </figure>
                    <div class="portfolio-info">
                    <h6 align="left"><a><?php echo e(substr($slider3->TipoArchivo,0,50).'...'); ?></a></h6>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <?php endif; ?>
            </div>
        
    </section>
<center><h2> Graficos 3D: </h2></center>
<section id="portfolio"   >
        
          <div class="row portfolio-container">
            <?php $__empty_1 = true; $__currentLoopData = $sliders4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
              <div class="portfolio-wrap">
                <figure>
                      <img class="d-block img-fluid" src=""  alt="">
                      
                      <a href="<?php echo e(URL::action('noticiasGraf3dController@edit',$slider4->id)); ?>" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
                    </figure>
                    <div class="portfolio-info">
                    <h6 align="left"><a><?php echo e(substr($slider4->tipoSW,0,50).'...'); ?></a></h6>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <?php endif; ?>
            </div>
        
    </section>

<center><h2> Kit STEAM: </h2></center>
<section id="portfolio"   >
        
          <div class="row portfolio-container">
            <?php $__empty_1 = true; $__currentLoopData = $sliders5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
              <div class="portfolio-wrap">
                <figure>
                      <img class="d-block img-fluid" src="<?php echo e(asset('/imagenes/kitSTEAM/portadaKit/'.$slider5->Portada)); ?>"  alt="">
                      <a href="<?php echo e(asset('/imagenes/kitSTEAM/portadaKit/'.$slider5->Portada)); ?>"  data-lightbox="portfolio" data-title="App 1" class="link-preview" title="Preview"><i class="fa fa-5x fa-eye"></i></a>
                      <a href="<?php echo e(URL::action('noticiasKitController@edit',$slider5->id)); ?>" class="link-details" title="Leer mas.."><i class="fa fa-5x fa-external-link" target="_blank"></i></a>
                    </figure>
                    <div class="portfolio-info">
                    <h6 align="left"><a><?php echo e(substr($slider5->nombreCaja,0,50).'...'); ?></a></h6>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <?php endif; ?>
            </div>
        
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>