    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<?php $__env->startSection('content'); ?>
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    <h5><a href="<?php echo e(asset('GestorDocente/Almacen')); ?>">Almacen</a>/Kit STEAM</h5>
		<h3>Kit Steam: <a href="kitSTEAM/create"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Nuevo</button></a></h3><br>

		<h3>Listado de Kit Steam</h3>
		<?php echo $__env->make('GestorDocente.kitSTEAM.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>
  <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>Fecha</th>
                  <th>Material</th>
                  <th>Enlace</th>
                  <th>Correo Creador</th>                
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $__currentLoopData = $kit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id!='1'): ?> 
                  <td>FIEKIT<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->nombreCaja); ?></td>
                  <td><?php echo e($usd->Autor); ?></td>
                  <td><?php echo e($usd->fecha); ?></td>
                  <td><?php echo e($usd->material); ?></td>
                  <td><?php echo e($usd->enlace); ?></td>
                  <td><?php echo e($usd->correo); ?></td>
                  <td>
                    
                    <a href="" data-target="#modal-QR-<?php echo e($usd->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-qrcode"></i> CodigoQR</button></a>
                    <a href="" data-target="#modal-solic-<?php echo e($usd->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Documentos</button></a>
                     
                     <?php if($usd->idUser== Auth::user()->id ): ?>
                    <a href="<?php echo e(URL::action('KitSTEAMdController@edit',$usd->idProd)); ?>"><button type="button" class="btn btn-outline-info btn-sm"><i class="fa fa-edit"></i> Editar</button></a>
                    <a href="" data-target="#modal-delete-<?php echo e($usd->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-danger btn-sm"><i class="fa fa-user-times"></i> Eliminar</button></a>
                    <?php endif; ?>

                    
                    <?php if($usd->idObserv=='1'): ?>
                    <?php if($usd->idUser!= Auth::user()->id): ?>
                    <a href="<?php echo e(URL::action('observacionDController@edit',$usd->idProd)); ?>"><button type="button" class="btn btn-outline-success"><i class="fa fa-edit"></i> Add. Observ.</button></a>
                    
                    <?php else: ?>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if($usd->idObserv!='1'): ?>
                    <a href="" data-target="#modal-DocObserv-<?php echo e($usd->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-warning btn-sm"><i class="fa fa-file-image-o"></i> Observación</button></a>
                    <?php endif; ?>
                    
                  </td>
                </tr>
                <?php endif; ?>
                <?php echo $__env->make('GestorDocente.kitSTEAM.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('GestorDocente.kitSTEAM.modal3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('GestorDocente.kitSTEAM.modal4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('GestorDocente.kitSTEAM.modal5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('GestorDocente.kitSTEAM.modal6', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('GestorDocente.kitSTEAM.modal7', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('GestorDocente.kitSTEAM.modal8', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('GestorDocente.kitSTEAM.modal9', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('GestorDocente.kitSTEAM.modal10', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            <?php echo e($kit->render()); ?>

            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>