@extends ('layouts.user')

    <link rel="stylesheet" href="{{asset('css/botones.css')}}">
@section ('content')
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    <h5><a href="{{asset('GestorUsuario/Almacen')}}">Almacen</a>/Kit STEAM</h5>
		<h3>Kit Steam: <a href="kitSTEAM/create"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Nuevo</button></a></h3><br>

		<h3>Listado de Kit Steam</h3>
		@include('GestorUsuario.kitSTEAM.search')
	</div>
</div>
  <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>Fecha</th>
                  <th>Material</th>
                  <th>Enlace</th>
                  <th>Correo Creador</th>                
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($kit as $usd)
                  @if ($usd->id!='1') 
                  <td>FIEKIT{{$usd->id}}</td>
                  <td>{{$usd->nombreCaja}}</td>
                  <td>{{$usd->Autor}}</td>
                  <td>{{$usd->fecha}}</td>
                  <td>{{$usd->material}}</td>
                  <td>{{$usd->enlace}}</td>
                  <td>{{$usd->correo}}</td>
                  <td>
                    
                    <a href="" data-target="#modal-QR-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-qrcode"></i> CodigoQR</button></a>
                    <a href="" data-target="#modal-solic-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Documentos</button></a>
                     
                     @if ($usd->idUser== Auth::user()->id )
                    <a href="{{URL::action('KitSTEAMuController@edit',$usd->idProd)}}"><button type="button" class="btn btn-outline-info btn-sm"><i class="fa fa-edit"></i> Editar</button></a>
                    <a href="" data-target="#modal-delete-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-danger btn-sm"><i class="fa fa-user-times"></i> Eliminar</button></a>
                    @endif
                    @if($usd->idObserv!='1')
                    <a href="" data-target="#modal-DocObserv-{{$usd->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-warning btn-sm"><i class="fa fa-file-image-o"></i> Observación</button></a>
                    @endif
                  </td>
                </tr>
                @endif
                @include('GestorUsuario.kitSTEAM.modal')
                @include('GestorUsuario.kitSTEAM.modal3')
                @include('GestorUsuario.kitSTEAM.modal4')
                @include('GestorUsuario.kitSTEAM.modal5')
                @include('GestorUsuario.kitSTEAM.modal6')
                @include('GestorUsuario.kitSTEAM.modal7')
                @include('GestorUsuario.kitSTEAM.modal8')
                @include('GestorUsuario.kitSTEAM.modal9')
                @include('GestorUsuario.kitSTEAM.modal10')
                {{-- @include('GestorMSA.Aplicaciones.modal2') --}}
                @endforeach           
              </table>
            </div>
            {{$kit->render()}}
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

@endsection