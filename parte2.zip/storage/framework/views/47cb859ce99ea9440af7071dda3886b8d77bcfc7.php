<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="<?php echo e(asset('GestorMSA/Almacen')); ?>">Almacen</a>/
                <a href="<?php echo e(asset('GestorMSA/tarjetaspopup')); ?>">Tarjetas</a>/Editar
            </h5>
			<h3>Editar Tarjeta Pop Up: <?php echo e($tarjetaspp->NombTarj); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>

	
			


<form method="POST" action="/GestorMSA/tarjetaspopup/<?php echo e($tarjetaspp->id); ?>" enctype="multipart/form-data">
    <?php echo method_field('PUT'); ?> 
    <?php echo csrf_field(); ?>
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>"> -->
                       

                        <div class="form-group row">
                            <label for="NombTarj" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre de la Tarjeta')); ?></label>

                            <div class="col-md-6">
                                <input id="NombTarj" type="text" placeholder="Nombre Apellido" class="form-control<?php echo e($errors->has('NombTarj') ? ' is-invalid' : ''); ?>" name="NombTarj" value="<?php echo e($tarjetaspp->NombTarj); ?>" required autofocus>

                                <?php if($errors->has('NombTarj')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('NombTarj')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="DesTarjet" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Descripción de la Tarjeta')); ?></label>

                            <div class="col-md-6">
                                <input id="DesTarjet" type="text" placeholder="Descripción" class="form-control<?php echo e($errors->has('DesTarjet') ? ' is-invalid' : ''); ?>" name="DesTarjet" value="<?php echo e($tarjetaspp->DesTarjet); ?>" required autofocus>

                                <?php if($errors->has('DesTarjet')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('DesTarjet')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="AutorTarj" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Autor/es de la Tarjeta')); ?></label>

                            <div class="col-md-6">
                                <input id="AutorTarj" type="text" placeholder="Descripción" class="form-control<?php echo e($errors->has('AutorTarj') ? ' is-invalid' : ''); ?>" name="AutorTarj" value="<?php echo e($tarjetaspp->AutorTarj); ?>" required autofocus>

                                <?php if($errors->has('AutorTarj')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('AutorTarj')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaCreacT" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha creación S.W.')); ?></label>

                            <div class="col-md-6">
                                <input id="fechaCreacT" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control<?php echo e($errors->has('fechaCreacT') ? ' is-invalid' : ''); ?>" name="fechaCreacT" value="<?php echo e($tarjetaspp->fechaCreacT); ?>" required autofocus>

                                <?php if($errors->has('fechaCreacT')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fechaCreacT')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Importar foto:')); ?></label>

                            <div class="col-md-6">
                                <input id="fotoApp" type="file" name="fotoApp" value="<?php echo e(old('fotoApp')); ?>" required autofocus>

                                <?php if($errors->has('fotoApp')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fotoApp')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="QRTarjet" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Importar codigo QR:')); ?></label>

                            <div class="col-md-6">
                                <input id="QRTarjet" type="file" name="QRTarjet" value="<?php echo e(old('QRTarjet')); ?>" required autofocus>

                                <?php if($errors->has('QRTarjet')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('QRTarjet')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->                         
                        <div class="form-group row">
                            <label for="examinar" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Importar Documento:')); ?></label>

                            <div class="col-md-6">
                                <input id="examinar" type="file" name="examinar" value="<?php echo e(old('examinar')); ?>" required autofocus>

                                <?php if($errors->has('examinar')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('examinar')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        

                        <!--fin ndatos  -->
                        <!--new datos  -->
                        <!--estado  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Enviar')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>