<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Role;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    public function redirectPath()
        {
        if (auth()->user()->hasRole('admin')) {
            return '/GestorMSA/index';
            
        }
        else{
            if(auth()->user()->hasRole('docent')){
                return '/GestorDocente/index';
            }
        }

        return '/GestorUsuario/index';
        }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed', //
            'cedula'=>'nullable|numeric|min:10',
            'direccion'=>'required|max:100',
            'genero'=>'required|max:1',
            'fechaNac'=>'required|max:10',
            'foto'=>'mimes:jpeg,bmp,jpg,png',
            'pais'=> 'required|max:30',
            'ciudad'=> 'required|max:30',
            'estado'=>'required|max:1',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        /*if($data->hasfile('foto')){
            $file=$data->file('foto');
            $nameF=time().$file->getClientOriginalName();
            $file->move(public_path().'/imagenes/perfil/',$nameF);
        }*/

        if (Input::hasFile('foto')){
         $file=Input::file('foto');
         $nameF=time().$file->getClientOriginalName();
         $file->move(public_path().'/imagenes/perfil/',$nameF);
        }
        $role_user = Role::where('name','user')->first();

        
        return User::create([ 
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),//
            'cedula' => $data['cedula'],
            'direccion' => $data['direccion'],
            'genero' => $data['genero'],
            'fechaNac' => $data['fechaNac'],
            'foto' => $nameF,
            'pais' => $data['pais'],
            'ciudad' => $data['ciudad'],
            'estado' => $data['estado'], 
        ]);
        // $User->roles()->attach($role_user);
    }
}
