<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('productos', function (Blueprint $table) {
            $table->increments('id');
            $table->string('nombreP');
            $table->integer('idGraf3D')->unsigned();
            $table->foreign('idGraf3D')->references('id')->on('grafico3ds');
            $table->integer('idarchPlano')->unsigned();
            $table->foreign('idarchPlano')->references('id')->on('arch_planos');
            $table->integer('idApp')->unsigned();
            $table->foreign('idApp')->references('id')->on('aplicacions');
            $table->integer('idKit')->unsigned();
            $table->foreign('idKit')->references('id')->on('kit_steams');
            $table->integer('idAutor')->unsigned();
            $table->foreign('idAutor')->references('id')->on('autors'); 
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('productos');
    }
}
