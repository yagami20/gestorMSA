<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cajaContenido extends Model
{
    //
    protected $table='caja_contenidos'; 

    protected $primaryKey='id';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'idContenido', 

        'idCaja'
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ];
}
