<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGrafico3dsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('grafico3ds', function (Blueprint $table) {
            $table->increments('id');
            $table->date('fechaCreacion');
            $table->string('Desgraf3D');
            $table->string('Docgraf3D');
            $table->string('Autorgraf3D'); 
            $table->string('obj3D');
            $table->string('observacion');
            $table->string('tipoSW');
            $table->string('tipoObj',1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('grafico3ds');
    }
}
