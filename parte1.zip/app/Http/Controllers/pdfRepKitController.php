<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//parte llamado

use App\patentesPrP;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\PatentesFormRequest;
use App\Http\Requests\busquedaAppFormRequest;
use phpCAS;

use DB;
use Fpdf;

class pdfRepKitController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index(Request $request)
    {
        $request->user()->authorizeRoles(['admin']);
        
        $apg=DB::table('kit_steams as tbSI')
            ->join('contenido_kits as tbI', 'tbSI.idContenido','=','tbI.id')
            ->join('caja_contenidos as tbSC','tbI.id','=','tbSC.idContenido')
            ->join('cajas as tbC','tbSC.idCaja','=','tbC.id')
            ->select('tbSI.id','tbSI.aplicabilidad as App','tbSI.AutorKit as Autor','tbSI.portadakit as Portada','tbSI.fechaKit as fecha',
                'tbSI.planos as plano', 
                'tbSI.email as correo','tbI.piezaArmar as pieza','tbI.instrucciones as instruc',
                'tbI.tutoDigital as tutorial','tbI.enlaceWeb as enlace',
                'tbI.tipoMateria as material','tbC.nombreC as nombreCaja',
                'tbC.informacion as info','tbC.codQR as QR')
            ->orderBy('tbSI.id','desc')
            ->paginate(7);
        return view ('GestorMSA.Reportes.kitsteam.index',["apg"=>$apg]);
    }

    public function show ($id)
    {        
        return view("GestorMSA.Reportes.kitsteam.show"); 
    }

   public function create(Request $request)
    {
        $request->user()->authorizeRoles(['admin']);
        
            $apg=DB::table('kit_steams as tbSI')
            ->join('contenido_kits as tbI', 'tbSI.idContenido','=','tbI.id')
            ->join('caja_contenidos as tbSC','tbI.id','=','tbSC.idContenido')
            ->join('cajas as tbC','tbSC.idCaja','=','tbC.id')
            ->select('tbC.nombreC as nombreCaja','tbSI.AutorKit as Autor','tbSI.fechaKit as fecha',
                'tbSI.email as correo','tbI.enlaceWeb as enlace')
            ->where('tbSI.id','!=',1)
            ->orderBy('tbSI.id','desc')
            ->paginate(20);
            $this->bfecha($apg);
    }

public function update(busquedaAppFormRequest $request, $id)
    {

    }


    //
    public function bfecha ($apg)
    {

            Fpdf::AddPage();
            Fpdf::Image('ENCABEZ.JPG',20,20,-100);
            Fpdf::Ln(50);
            Fpdf::SetFont('Arial','B',14);
            Fpdf::Write(5,'Reporte Patente ');
            Fpdf::Ln(10);
            Fpdf::Cell(40,6,'Nombre Kit',1,0,'C');
            Fpdf::Cell(30,6,'Autor/es',1,0,'C');
            Fpdf::Cell(30,6,'Fecha',1,0,'C');
            Fpdf::Cell(40,6,'Correo',1,0,'C');
            Fpdf::Cell(40,6,'Enlace',1,1,'C');
            Fpdf::SetFont('Arial','',10);

        	foreach($apg as $row)
		    {
		    	$j=0;
		        foreach($row as $col){
                 	if($j==2){
                	Fpdf::Cell(30,6,$col,1); 	
                 	}
                 	else{
                 		if($j==1){
                 			Fpdf::Cell(30,6,$col,1,0,'C');
                 		}
                 		else{
                 			if($j==3){
                 				Fpdf::Cell(40,6,$col,1);
                 			}
                 			else{
                 				Fpdf::Cell(40,6,$col,1);	
                 			}
                 			
                 		}
                 		
                 	}
		            
		            $j++;
		            }
		        Fpdf::Ln();
		    }
            
            Fpdf::Output();
            exit;
    }
    public function destroy(busquedaAppFormRequest $request,$id)
    {
        $fecha1=trim($request->get('FechaInicio')); //determinr texto de busqueda

            $fecha2=trim($request->get('FechaFin')); //determinr texto de busqueda
            $f1=date("Y-m-d", strtotime($request->get('FechaInicio')));
            $f2=date("Y-m-d", strtotime($request->get('FechaFin')));
            $fechaI=DB::table('kit_steams as tbI')
            ->whereBetween('tbI.fechaKit',[$f1,$f2])
            ->get();
            if($fechaI)
                {
                    $oficioI=DB::table('kit_steams as tbSI')
            ->join('contenido_kits as tbI', 'tbSI.idContenido','=','tbI.id')
            ->join('caja_contenidos as tbSC','tbI.id','=','tbSC.idContenido')
            ->join('cajas as tbC','tbSC.idCaja','=','tbC.id')
            ->select('tbC.nombreC as nombreCaja','tbSI.AutorKit as Autor','tbSI.fechaKit as fecha',
                'tbSI.email as correo','tbI.enlaceWeb as enlace')
                        ->whereBetween('tbSI.fechaKit',[$f1,$f2])
                        ->where('tbSI.id','!=',1)
                        ->get();
                    // if($oficioI->idOficioI<>'1')
                    // {
                        $this->bfecha($oficioI);
                //fin id
                    // }
            //fin prim if
                }
    }
}
