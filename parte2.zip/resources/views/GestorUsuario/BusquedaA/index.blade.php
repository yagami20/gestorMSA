@extends ('layouts.user')

    <link rel="stylesheet" href="{{asset('css/botones.css')}}">
@section ('content')
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    <h3>Busqueda: </h3>
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            @if($band=='1')
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($apg as $usd)
                  @if ($usd->id!='1') 
                  <td>FIEAPPG{{$usd->id}}</td>
                  <td>{{$usd->tipoSW}}</td>
                  <td>{{$usd->AutorApp}}</td>
                  <td>{{$usd->fechaReproduc}}</td>
                  <td>
                    @if($band=='1')
                    <a href="{{asset('GestorUsuario/AplicacionesU')}}">Aplicaciones</a>
                    @endif
                  </td>
                </tr>
                @endif
                @endforeach           
              </table>
            </div>
            @endif
            @if($band=='2')
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($apg as $usd)
                  @if ($usd->id!='1')
                  <td>FIEARCHPL{{$usd->id}}</td>
                  <td>{{$usd->TipoArchivo}}</td>
                  <td>{{$usd->AutorArchP}}</td>
                  <td>{{$usd->fechaGener}}</td>
                  <td>
                    @if($band=='2')
                    <a href="{{asset('GestorUsuario/archPlanos')}}">Archivos Planos</a>
                    @endif
                  </td>
                </tr>
                @endif
                @endforeach           
              </table>
            </div>
            @endif
            @if($band=='3')
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($apg as $usd)
                  @if ($usd->id!='1')
                  <td>FIEOBJ3D{{$usd->id}}</td>
                  <td>{{$usd->tipoSW}}</td>
                  <td>{{$usd->Autorgraf3D}}</td>
                  <td>{{$usd->fechaCreacion}}</td>
                  <td>
                    @if($band=='3')
                    <a href="{{asset('GestorUsuario/Graficos3D')}}">Graficos 3D</a>
                    @endif
                  </td>
                </tr>
                @endif
                @endforeach           
              </table>
            </div>
            @endif
            @if($band=='4')
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($apg as $usd)
                  @if ($usd->id!='1')
                  <td>FIEKIT{{$usd->id}}</td>
                  <td>{{$usd->nombreCaja}}</td>
                  <td>{{$usd->Autor}}</td>
                  <td>{{$usd->fecha}}</td>
                  <td>
                    @if($band=='4')
                    <a href="{{asset('GestorUsuario/kitSTEAM')}}">Kit STEAM</a>
                    @endif
                  </td>
                </tr>
                @endif
                @endforeach           
              </table>
            </div>
            @endif
            @if($band=='5')
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  {{-- <th>Autor/es</th> --}}
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($apg as $usd)
                  @if ($usd->id!='1')
                  <td>FIENOTIFMSA{{$usd->id}}</td>
                  <td>{{$usd->titulo}}</td>
                  <td>{{$usd->fechaNotf}}</td>
                  <td>
                    @if($band=='5')
                    <a href="{{asset('GestorUsuario/notificaciones')}}">Notificaciones</a>
                    @endif
                  </td>
                </tr>
                @endif
                @endforeach           
              </table>
            </div>
            @endif
            @if($band=='6')
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($apg as $usd)
                  @if ($usd->id!='1')
                  <td>FIEPAPP{{$usd->id}}</td>
                  <td>{{$usd->TituloPatent}}</td>
                  <td>{{$usd->AutorsPatent}}</td>
                  <td>{{$usd->fechaPatent}}</td>
                  <td>
                    @if($band=='6')
                    <a href="{{asset('GestorUsuario/patentes')}}">Patentes</a>
                    @endif
                  </td>
                </tr>
                @endif
                @endforeach           
              </table>
            </div>
            @endif
            @if($band=='7')
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($apg as $usd)
                  @if ($usd->id!='1')
                  <td>FIETAPP{{$usd->id}}</td>
                  <td>{{$usd->NombTarj}}</td>
                  <td>{{$usd->AutorTarj}}</td>
                  <td>{{$usd->fechaCreacT}}</td>
                  <td>
                    @if($band=='7')
                    <a href="{{asset('GestorUsuario/tarjetasPopUp')}}">Tarjetas Pop-Up</a>
                    @endif
                  </td>
                </tr>
                @endif
                @endforeach           
              </table>
            </div>
            @endif
            @if($band=='8')
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Autor/es</th>
                  <th>fecha de Reproducción</th>
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($apg as $usd)
                  @if ($usd->id!='1') 
                  <td>FIEMSA-APP{{$usd->id}}</td>
                  @if($usd->idApp!='1')
                  <td>{{$usd->TitApp}}</td>
                  @endif
                  @if($usd->idarchPlano!='1')
                  <td>{{$usd->TipoArchivo}}</td>
                  @endif
                  @if($usd->idGraf3D!='1')
                    <td>{{$usd->tipoSW}}</td>
                  @endif
                  @if($usd->idTarj!='1')
                    <td>{{$usd->NombTarj}}</td>
                  @endif
                  @if($usd->idKit!='1')
                    <td>{{$usd->nombreC}}</td>
                  @endif
                  @if($usd->idPatent!='1')
                    <td>{{$usd->TituloPatent}}</td>
                  @endif
                  
                <td>
                  @if($usd->idApp!='1')
                  {{$usd->AutorApp}}
                  @endif
                  @if($usd->idarchPlano!='1')
                  {{$usd->AutorArchP}}
                  @endif
                  @if($usd->idGraf3D!='1')
                    {{$usd->Autorgraf3D}}
                  @endif
                  @if($usd->idTarj!='1')
                    {{$usd->AutorTarj}}
                  @endif
                  @if($usd->idKit!='1')
                    {{$usd->AutorKit}}
                  @endif
                  @if($usd->idPatent!='1')
                    {{$usd->AutorsPatent}}
                  @endif
                </td>
                <td>
                  @if($usd->idApp!='1')
                  {{$usd->fechaReproduc}}
                  @endif
                  @if($usd->idarchPlano!='1')
                  {{$usd->fechaGener}}
                  @endif
                  @if($usd->idGraf3D!='1')
                    {{$usd->fechaCreacion}}
                  @endif
                  @if($usd->idTarj!='1')
                    {{$usd->fechaCreacT}}
                  @endif
                  @if($usd->idKit!='1')
                    {{$usd->fechaKit}}
                  @endif
                  @if($usd->idPatent!='1')
                    {{$usd->fechaPatent}}
                  @endif
                </td>
                  <td>
                    @if($usd->idApp!='1')
                    <a href="{{asset('GestorUsuario/AplicacionesU')}}">Aplicaciones</a>
                    @endif
                    @if($usd->idarchPlano!='1')
                    <a href="{{asset('GestorUsuario/archPlanos')}}">Archivos Planos</a>
                    @endif
                    @if($usd->idGraf3D!='1')
                    <a href="{{asset('GestorUsuario/Graficos3D')}}">Graficos 3D</a>
                    @endif
                    @if($usd->idTarj!='1')
                    <a href="{{asset('GestorUsuario/tarjetasPopUp')}}">Tarjetas Pop-Up</a>
                    @endif
                    @if($usd->idKit!='1')
                    <a href="{{asset('GestorUsuario/kitSTEAM')}}">Kit STEAM</a>
                    @endif
                    @if($usd->idPatent!='1')
                    <a href="{{asset('GestorUsuario/patentes')}}">Patentes</a>
                    @endif
                  </td>
                </tr>
                @endif
                @endforeach           
              </table>
            </div>
            @endif
            {{$apg->render()}}
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

@endsection