@extends ('layouts.docente')
@section ('content')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="{{asset('GestorDocente/Almacen')}}">Almacen</a>/Agregar Observación
                
            </h5>
			@if ($band=='1')
            <h3>Agregar Observación: {{$tarjetaspp->NombTarj}}</h3>
            @else
            <h3>Agregar Observación: {{$caja->nombreC}}</h3>
            @endif
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

	
			


<form method="POST" action="/GestorDocente/ObservacionD/{{$prod->id}}" enctype="multipart/form-data">
    @method('PUT') 
    @csrf
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="{{ route('register') }}" aria-label="{{ __('Register') }}"> -->
                       

                        <div class="form-group row">
                            <label for="nombreA" class="col-md-4 col-form-label text-md-right">{{ __('Autor Observación ') }}</label>

                            <div class="col-md-6">
                                <input id="nombreA" type="text" title="Nombre de autor o autores" placeholder="Autor1, Autor2 #..." class="form-control{{ $errors->has('nombreA') ? ' is-invalid' : '' }}" name="nombreA" value="{{ Auth::user()->name }}" required autofocus>

                                @if ($errors->has('nombreA'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('nombreA') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="DocObserv" class="col-md-4 col-form-label text-md-right">{{ __('Cargar Documento (extensión: pdf):') }}</label>

                            <div class="col-md-6">
                                <input id="DocObserv" type="file" title="Formato de archivo:pdf" name="DocObserv" value="{{ old('DocObserv') }}" required autofocus>

                                @if ($errors->has('DocObserv'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('DocObserv') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <input type="hidden" name="idProducto" value="{{$prod->id}}">
                        @if ($band=='1')
                        <input type="hidden" name="band" value="1">
                        @else
                        <input type="hidden" name="band" value="2">
                        @endif

                            
                        <!--  -->
                        <!--fin ndatos  -->
                        <!--new datos  -->
                        <!--estado  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    {{ __('Agregar') }}
                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
@endsection