@extends ('layouts.admin')

    <link rel="stylesheet" href="{{asset('css/botones.css')}}">
@section ('content')
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    <h5><a href="{{asset('GestorMSA/Almacen')}}">Almacen</a>/Reporte Graficos 3D</h5>
		<h3>Reporte General Grafico 3D: <a href="graf3d/create"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Generar</button></a>
    <a href="" data-target="#modal-foto-{{$apg->id='1'}}" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Buscar</button></a></h3>
    @include('GestorMSA.Reportes.graf3d.modal2')
    <h3>Listado de Grafico 3D</h3> 
	</div> 
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Código</th>
                  <th>tipo S.W.</th>
                  <th>Autor/es</th>
                  <th>fecha Creación</th>
                  <th>observación</th>
                  <th>obj 3D</th>
                  <th>tipo Obj</th>                
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  @foreach ($apg as $usd)
                  <td>FIEOBJ3D{{$usd->id}}</td>
                  <td>{{$usd->tipoSW}}</td>
                  <td>{{$usd->Autorgraf3D}}</td>
                  <td>{{$usd->fechaCreacion}}</td>
                  <td>{{$usd->observacion}}</td>
                  <td>{{$usd->obj3D}}</td>
                  <td>{{$usd->tipoObj}}</td>
                  <td>
                    <a href="{{URL::action('pdfRepGraf3dController@verObj',$usd->id)}}"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-edit"></i>Obj. 3D</button></a>
                    
                  </td>
                </tr>
                @endforeach                
              </table>
            </div>
            {{$apg->render()}}
          </div>
        </div>
      </div>

@endsection