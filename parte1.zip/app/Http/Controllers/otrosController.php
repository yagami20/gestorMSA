<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Role;

use DB;

class otrosController extends Controller
{
    //
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('GestorMSA.index');
    }

    public function indexD()
    {
        return view('GestorDocente.index');
    }
    public function indexU()
    {
        return view('GestorUsuario.index');
    }

    public function indexCas()
    {
        return view('cas.protected.index');
    }
    public function HomeFIE()
    {
        return view('edifFieobj');
    }
    public function NotifFIE()
    {
        //notificacion
        $sliders=DB::table('notificacion_ps')           
            ->orderby('id','desc')
            ->paginate(6); 
            //dd($sliders);
        return view('Notificacion',['sliders'=>$sliders]);
    }



    public function DescargFIE()
    {
        //desc
        $sliders=DB::table('aplicacions')           
            ->orderby('id','desc')
            ->paginate(3);
        $sliders2=DB::table('tarjetas_p_ps')           
            ->orderby('id','desc')
            ->paginate(3);
        $sliders3=DB::table('arch_planos')           
            ->orderby('id','desc')
            ->paginate(3);
        $sliders4=DB::table('grafico3ds')           
            ->orderby('id','desc')
            ->paginate(6);
        $sliders5=DB::table('kit_steams as tbSI')
            ->join('contenido_kits as tbI', 'tbSI.idContenido','=','tbI.id')
            ->join('caja_contenidos as tbSC','tbI.id','=','tbSC.idContenido')
            ->join('cajas as tbC','tbSC.idCaja','=','tbC.id')
            ->select('tbSI.id','tbSC.id as idCajCont','tbSI.aplicabilidad as App','tbSI.AutorKit as Autor','tbSI.portadakit as Portada','tbSI.fechaKit as fecha',
                'tbSI.planos as plano', 
                'tbSI.email as correo','tbI.piezaArmar as pieza','tbI.instrucciones as instruc',
                'tbI.tutoDigital as tutorial','tbI.enlaceWeb as enlace',
                'tbI.tipoMateria as material','tbC.nombreC as nombreCaja',
                'tbC.informacion as info','tbC.codQR as QR')           
            ->orderby('id','desc')
            ->paginate(3);
        return view('descargas',['sliders'=>$sliders,'sliders5'=>$sliders5,'sliders2'=>$sliders2,'sliders4'=>$sliders4,'sliders3'=>$sliders3]);
    }
    
    public function indexGestor()
    {
        if (auth()->user()->hasRole('admin')) {
            return view('GestorMSA.index');
            
        }
        else{
            if(auth()->user()->hasRole('docent')){
                return view('GestorDocente.index');
            }
        }

        return view('GestorUsuario.index');
    }
}
