<?php $__env->startSection('content'); ?>
							<h3>QUIENES SOMOS</h3>
							
                              <center><img src="<?php echo e(asset('logo.png')); ?>"></center>
                              El Grupo de investigación Modelado Simulación y Animación 3D (MSA-3D) se inscribe prioritariamente, en lo relativo a la línea nacional de investigación  “Tecnologías de la Información, Comunicación y Procesos Industriales”. Específicamente el Grupo (MSA-3D) se concentra en diseñar y producir objetos y servicios tridimensionales o 3D para la educación superior e investigación productiva. <p></p>
                              <center><img src="<?php echo e(asset('i1.jpg')); ?>"></center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>