<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-foto-{{$publicacion->id}}">
{{Form::Open(array('action'=>array('notificacionesG@destroy',$publicacion->id),'method'=>'delete'))}}
<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">X</span>
			
		</button>
		<h4 class="modal-title">Ver Archivo</h4>
	</div>
	<div class="modal-body">
		
		
				<!--  -->
				<div class="box-body box-profile">
                      <p class="text-muted text-center">Notificaciones:</p>
                      <iframe src="/documentos/docNotif/<?=  $publicacion->docNotif;   ?>" height="480px" width="450px" > archivo</iframe>
                      <a href="{{URL::action('notificacionesG@Download',$publicacion->docNotif)}}"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Descargar</button></a>
                  </div>
				<!--  -->
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
		
	</div>

	</div>
</div>
{{Form::Close()}}	

</div>