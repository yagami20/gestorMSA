@extends ('layouts.docente')
@section ('content')
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="{{asset('GestorDocente/Almacen')}}">Almacen</a>/
                <a href="{{asset('GestorDocente/tarjetasPopUp')}}">Tarjetas</a>/Editar
            </h5>
			<h3>Editar Tarjeta Pop Up: {{$tarjetaspp->NombTarj}}</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>

	
			


<form method="POST" action="/GestorDocente/tarjetasPopUp/{{$tarjetaspp->id}}" enctype="multipart/form-data">
    @method('PUT') 
    @csrf
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="{{ route('register') }}" aria-label="{{ __('Register') }}"> -->
                       

                        <div class="form-group row">
                            <label for="NombTarj" class="col-md-4 col-form-label text-md-right">{{ __('Nombre de la Tarjeta') }}</label>

                            <div class="col-md-6">
                                <input id="NombTarj" type="text" placeholder="Nombre Apellido" class="form-control{{ $errors->has('NombTarj') ? ' is-invalid' : '' }}" name="NombTarj" value="{{$tarjetaspp->NombTarj}}" required autofocus>

                                @if ($errors->has('NombTarj'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('NombTarj') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="DesTarjet" class="col-md-4 col-form-label text-md-right">{{ __('Descripción de la Tarjeta') }}</label>

                            <div class="col-md-6">
                                <input id="DesTarjet" type="text" placeholder="Descripción" class="form-control{{ $errors->has('DesTarjet') ? ' is-invalid' : '' }}" name="DesTarjet" value="{{$tarjetaspp->DesTarjet}}" required autofocus>

                                @if ($errors->has('DesTarjet'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('DesTarjet') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="AutorTarj" class="col-md-4 col-form-label text-md-right">{{ __('Autor/es de la Tarjeta') }}</label>

                            <div class="col-md-6">
                                <input id="AutorTarj" type="text" placeholder="Descripción" class="form-control{{ $errors->has('AutorTarj') ? ' is-invalid' : '' }}" name="AutorTarj" value="{{$tarjetaspp->AutorTarj}}" required autofocus>

                                @if ($errors->has('AutorTarj'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('AutorTarj') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaCreacT" class="col-md-4 col-form-label text-md-right">{{ __('Fecha creación S.W.') }}</label>

                            <div class="col-md-6">
                                <input id="fechaCreacT" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('fechaCreacT') ? ' is-invalid' : '' }}" name="fechaCreacT" value="{{$tarjetaspp->fechaCreacT}}" required autofocus>

                                @if ($errors->has('fechaCreacT'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fechaCreacT') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right">{{ __('Cargar Foto (extensión: jpeg,bmp,jpg,png):') }}</label>

                            <div class="col-md-6">
                                <input id="fotoApp" type="file" title="Formato de archivo:jpeg,bmp,jpg,png" name="fotoApp" value="{{ old('fotoApp') }}" required autofocus>

                                @if ($errors->has('fotoApp'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fotoApp') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="QRTarjet" class="col-md-4 col-form-label text-md-right">{{ __('Cargar codigo QR (extensión: jpeg,bmp,jpg,png):') }}</label>

                            <div class="col-md-6">
                                <input id="QRTarjet" type="file" title="QR de realidad aumentada" name="QRTarjet" value="{{ old('QRTarjet') }}" required autofocus>

                                @if ($errors->has('QRTarjet'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('QRTarjet') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        
                        <div class="form-group row">
                            <label for="examinar" class="col-md-4 col-form-label text-md-right">{{ __('Importar Documentación (extensión: pdf o zip):') }}</label>

                            <div class="col-md-6">
                                <input id="examinar" type="file" title="Archivo formato zip o pdf" name="examinar" value="{{ old('examinar') }}" required autofocus>

                                @if ($errors->has('examinar'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('examinar') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <!--  -->
                        <div class="form-group row">
                            <div class="col-md-6">
                                <input type="hidden" name="idProducto" value="{{$prod->id}}">
                            </div>
                        </div>
                        <!--  -->
                        {{-- <div class="form-group row">
                            <label for="idProducto" class="col-md-4 col-form-label text-md-right">{{ __('Nombre de la Tarjeta') }}</label>

                            <div class="col-md-6">
                                <input id="idProducto" type="text" placeholder="Nombre Apellido" class="form-control{{ $errors->has('idProducto') ? ' is-invalid' : '' }}" name="idProducto" value="{{$prod->id}}" required autofocus>

                                @if ($errors->has('idProducto'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('idProducto') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div> --}}
                        
                        

                        <!--fin ndatos  -->
                        <!--new datos  -->
                        <!--estado  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    {{ __('Enviar') }}
                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
@endsection