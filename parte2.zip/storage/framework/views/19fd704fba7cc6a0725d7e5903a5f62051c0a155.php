<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h5><a href="<?php echo e(asset('GestorMSA/Almacen')); ?>">Almacen</a>/
                <a href="<?php echo e(asset('GestorMSA/Aplicaciones')); ?>">Aplicaciones</a>/Crear
            </h5>
			<h3>Nueva Aplicacion:</h3><br>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>
			<?php echo Form::open(array('url'=>'GestorMSA/Aplicaciones','method'=>'POST','autocomplete'=>'off','files'=>'true')); ?>

			<?php echo e(Form::token()); ?> 

		<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>"> -->
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="tipoSW" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre del S.W.')); ?></label>

                            <div class="col-md-6">
                                <input id="tipoSW" type="text" placeholder="Simulador #..." class="form-control<?php echo e($errors->has('tipoSW') ? ' is-invalid' : ''); ?>" name="tipoSW" value="<?php echo e(old('tipoSW')); ?>" required autofocus>

                                <?php if($errors->has('tipoSW')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('tipoSW')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Descripción:')); ?></label>

                            <div class="col-md-6">
                                <input id="DesApp" type="text" placeholder="Descripción #..." class="form-control<?php echo e($errors->has('DesApp') ? ' is-invalid' : ''); ?>" name="DesApp" value="<?php echo e(old('DesApp')); ?>" required autofocus>

                                <?php if($errors->has('DesApp')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('DesApp')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Autor/es:')); ?></label>

                            <div class="col-md-6">
                                <input id="AutorApp" type="text" placeholder="Persona1, Persona2 #..." class="form-control<?php echo e($errors->has('AutorApp') ? ' is-invalid' : ''); ?>" name="AutorApp" value="<?php echo e(old('AutorApp')); ?>" required autofocus>

                                <?php if($errors->has('AutorApp')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('AutorApp')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaReproduc" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha creación S.W.')); ?></label>

                            <div class="col-md-6">
                                <input id="fechaReproduc" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control<?php echo e($errors->has('fechaReproduc') ? ' is-invalid' : ''); ?>" name="fechaReproduc" value="<?php echo e(old('fechaReproduc')); ?>" required autofocus>

                                <?php if($errors->has('fechaReproduc')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fechaReproduc')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="fotoApp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cargar Foto:')); ?></label>

                            <div class="col-md-6">
                                <input id="fotoApp" type="file" name="fotoApp" value="<?php echo e(old('fotoApp')); ?>" required autofocus>

                                <?php if($errors->has('fotoApp')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fotoApp')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        <div class="form-group row">
                            <label for="examinar" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Importar:')); ?></label>

                            <div class="col-md-6">
                                <input id="examinar" type="file" name="examinar" value="<?php echo e(old('examinar')); ?>" required autofocus>

                                <?php if($errors->has('examinar')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('examinar')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        

                        <!--fin ndatos  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Ingresar')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
			
			


			<?php echo Form::close(); ?>


		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>