<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class producto extends Model
{
    //
    protected $table='productos';

    protected $primaryKey='id';
  
    public $timestamps=false;//indica columnas con modificaciones de propiedades

    
    protected $fillable =[  //creacion campos recibn valor
    	
        'nombreP',

        'idGraf3D', 
    	
        'idarchPlano',
    	
        'idApp',
        
        'idKit',// 

        'idUser',

        'idTarj',

        'idPatent',

        'idAutor'
    
];

    
    protected  $guarded =[
 //atributos tipo warded

    
];

protected $hidden = [
        
    ];
}
